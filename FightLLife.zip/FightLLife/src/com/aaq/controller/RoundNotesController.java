// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   RoundNotesController.java

package com.aaq.controller;

import com.aaqa.pojo.CommonSearchPojo;
import com.aaqa.pojo.RoundNotesPopupPojo;
import org.springframework.web.servlet.ModelAndView;

public class RoundNotesController
{

    public RoundNotesController()
    {
    }

    public ModelAndView displayPatientDetails(CommonSearchPojo pojo)
    {
        return new ModelAndView("roundNotesDetails", "commonsearchpojo", new CommonSearchPojo());
    }

    public ModelAndView roundNotesPopup(RoundNotesPopupPojo roundNotesPopupPojo)
    {
        return new ModelAndView("roundNotesPopup", "roundNotesPopupPojo", new RoundNotesPopupPojo());
    }

    public String roundNotesPopup_ExternalMedicationTab()
    {
        return "roundNotesPopup_ExternalMedicationTab";
    }
}
