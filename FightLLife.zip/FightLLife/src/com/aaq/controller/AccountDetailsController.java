// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AccountDetailsController.java

package com.aaq.controller;

import com.aaqa.pojo.*;
import com.aaqa.service.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;

public class AccountDetailsController
{

    public AccountDetailsController()
    {
    }

    public String bedStatusDetails()
    {
        return "accountsMenu";
    }

    public ModelAndView displayBillingDetails(AccountBillDetailsPojo accountBillDetailsPojo, HttpServletRequest request)
    {
        java.util.List billingList = accountDetailsService.getAccountBillingDetails();
        request.getSession().setAttribute("bigApptSearchList", billingList);
        paginationService.defaultPage(request);
        java.util.List doctorsList = accountDetailsService.displayDoctorsList();
        request.getSession().setAttribute("doctorsList", doctorsList);
        return new ModelAndView("accountbilldetails", "accountBillDetailsPojo", new AccountBillDetailsPojo());
    }

    public ModelAndView displayBillingPopup(String id, AccountBillingDetailsPojo accountBillingDetailsPojo)
    {
        if(id != null)
        {
            Integer id1 = Integer.valueOf(id);
            AccountBillingDetailsPojo pojo = patientsearchsevice.getPatientSearchDetailsById(id1);
            if(pojo != null)
                return new ModelAndView("accountbillingdetails", "accountBillingDetailsPojo", pojo);
            else
                return new ModelAndView("accountbillingdetails", "accountBillingDetailsPojo", new AccountBillingDetailsPojo());
        } else
        {
            return new ModelAndView("accountbillingdetails", "accountBillingDetailsPojo", new AccountBillingDetailsPojo());
        }
    }

    public ModelAndView saveAccountBillingDetails(AccountBillingDetailsPojo accountBillingDetailsPojo, HttpServletRequest request)
    {
        String data = request.getParameter("data");
        accountDetailsService.saveAccountBillingDetails(accountBillingDetailsPojo, data);
        return new ModelAndView("accountbillingdetails", "accountBillingDetailsPojo", new AccountBillingDetailsPojo());
    }

    public String selectPatientForAccount(HttpServletRequest request)
    {
        java.util.List plist = accountDetailsService.getPatientDetailForTest();
        request.setAttribute("plist", plist);
        return "selectPatientForAccountDetails";
    }

    public ModelAndView selectPatientForAccountsToDisplay(HttpServletRequest request, SelectPatientPojo selectPatientPojo)
    {
        java.util.List plist = accountDetailsService.getPatientDetailForTest();
        request.setAttribute("plist", plist);
        return new ModelAndView("selectPatientForAccountDetails", "personEntity", new SelectPatientPojo());
    }

    public ModelAndView paginationNext(HttpServletRequest request)
    {
        paginationService.paginationNext(request);
        return new ModelAndView("accountbilldetails", "accountBillDetailsPojo", new AccountBillDetailsPojo());
    }

    public ModelAndView paginationPrivious(HttpServletRequest request)
    {
        paginationService.paginationPrivious(request);
        return new ModelAndView("accountbilldetails", "accountBillDetailsPojo", new AccountBillDetailsPojo());
    }

    public ModelAndView firstPage(HttpServletRequest request)
    {
        paginationService.firstPage(request);
        return new ModelAndView("accountbilldetails", "accountBillDetailsPojo", new AccountBillDetailsPojo());
    }

    public ModelAndView lastPage(HttpServletRequest request)
    {
        paginationService.lastPage(request);
        return new ModelAndView("accountbilldetails", "accountBillDetailsPojo", new AccountBillDetailsPojo());
    }

    private PatientSearchService patientsearchsevice;
    private PaginationService paginationService;
    private AccountDetailsService accountDetailsService;
}
