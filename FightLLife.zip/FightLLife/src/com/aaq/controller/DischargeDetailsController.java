// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DischargeDetailsController.java

package com.aaq.controller;

import com.aaqa.pojo.*;
import com.aaqa.service.*;
import java.io.PrintStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

public class DischargeDetailsController
{

    public DischargeDetailsController()
    {
        logger = Logger.getLogger("com/aaq/controller/DischargeDetailsController");
    }

    public void setDischargeDetailsService(DischargeDetailsService dischargeDetailsService)
    {
        this.dischargeDetailsService = dischargeDetailsService;
    }

    public ModelAndView displayPatientDetails(CommonSearchPojo pojo, DischargeSearchPojo dischargeSearchPojo, HttpServletRequest request)
    {
        java.util.List periodList = appointmentService.displayPeriodDeatials();
        request.getSession().setAttribute("periodList", periodList);
        java.util.List dischargeValueList = dischargeDetailsService.dischargeValuesdisplay();
        request.setAttribute("dischargeValueList", dischargeValueList);
        java.util.List dischargedetailslist = dischargeDetailsService.dischargeSearchdisplayValues();
        request.getSession().setAttribute("bigApptSearchList", dischargedetailslist);
        paginationService.defaultPage(request);
        return new ModelAndView("discharge", "commonsearchpojo", new CommonSearchPojo());
    }

    public String displayDischargeDetailsPopoup(DischargeDetailsPopupPojo dischargeDetailsPopupPojo, HttpServletRequest request)
    {
        java.util.List doctorsList = appointmentService.displayDoctorsList();
        request.getSession().setAttribute("doctorsList", doctorsList);
        request.setAttribute("dischargeDetailsPopupPojo", new DischargeDetailsPopupPojo());
        return "dischargeDetailsPopoup";
    }

    public String displayOperativeNotesPopoup(OperativeNotesPojo operativeNotesPojo, HttpServletRequest request)
    {
        return "operativeNotesPopoup";
    }

    public String displayInternalMedicationPopoup(DischargeDetailsPopupHeaderPojo dischargeDetailsPopupHeaderPojo, HttpServletRequest request)
    {
        request.setAttribute("internalmedication", new InternalMedicationPojo());
        return "internalMedicationPopoup";
    }

    public String displayExternalMedicationPopoup(DischargeDetailsPopupHeaderPojo dischargeDetailsPopupHeaderPojo, HttpServletRequest request)
    {
        request.setAttribute("externalmedication", new ExternalMedicationPojo());
        return "externalMedicationPopoup";
    }

    public String displaySelectPatientForDischarge()
    {
        return "selectPatientForDischargeDetails";
    }

    public ModelAndView saveDischargeDetailsPopoup(DischargeDetailsPopupPojo dischargeDetailsPopupPojo, BindingResult result, HttpServletRequest request)
    {
        if(result.hasErrors())
        {
            return new ModelAndView("dischargeDetailsPopoup", "DischargeDetailsPopupPojo", dischargeDetailsPopupPojo);
        } else
        {
            request.setAttribute("dischargeDetailsPopupHeaderPojo", new DischargeDetailsPopupHeaderPojo());
            request.setAttribute("externalmedication", new ExternalMedicationPojo());
            dischargeDetailsService.saveDischargeDetails(dischargeDetailsPopupPojo);
            return new ModelAndView("dischargeDetailsPopoup", "DischargeDetailsPopupPojo", new DischargeDetailsPopupPojo());
        }
    }

    public String getAllOperationsAtHospitals(HttpServletRequest request, OperativeNotesPojo operativeNotesPojo)
    {
        java.util.List operationatlist = dischargeDetailsService.getAllOperationsAtHospitals();
        java.util.List otnolist = dischargeDetailsService.getAllOtNos();
        request.setAttribute("operationatlist", operationatlist);
        request.setAttribute("otnolist", otnolist);
        request.setAttribute("OperativeNotesPojo", new OperativeNotesPojo());
        return "operativeNotesPopoup";
    }

    public ModelAndView selectPatientForDischargeToDisplay(HttpServletRequest request, SelectAdmitPatientPojo selectAdmitPatientPojo)
    {
        System.out.println();
        java.util.List plist = dischargeDetailsService.getPatientDetailForDischarge();
        System.out.println(plist);
        request.setAttribute("plist", plist);
        return new ModelAndView("selectPatientForDischargeDetails", "selectAdmitPatientPojo", new SelectAdmitPatientPojo());
    }

    public ModelAndView getDischargeDeatailsByFilter(CommonSearchPojo commonsearchpojo, HttpServletRequest request)
    {
        System.out.println("Hi this is getDischargeDetailsByFilter");
        System.out.println((new StringBuilder("Period is: ")).append(commonsearchpojo.getPeriod()).toString());
        System.out.println((new StringBuilder("name is: ")).append(commonsearchpojo.getSearch()).toString());
        System.out.println((new StringBuilder("value is: ")).append(commonsearchpojo.getValue()).toString());
        java.util.List dlist = dischargeDetailsService.getDischargeDeatailsByFilter(commonsearchpojo);
        java.util.List periodList = appointmentService.displayPeriodDeatials();
        request.getSession().setAttribute("periodList", periodList);
        java.util.List dischargeValueList = dischargeDetailsService.dischargeValuesdisplay();
        request.setAttribute("dischargeValueList", dischargeValueList);
        request.getSession().setAttribute("dlist", dlist);
        System.out.println(dlist);
        return new ModelAndView("discharge", "commonsearchpojo", commonsearchpojo);
    }

    public ModelAndView editDischargeDetails(DischargeDetailsPopupPojo dischargeDetailsPopupPojo, HttpServletRequest request)
    {
        Integer disId = Integer.valueOf(Integer.parseInt(request.getParameter("dischargeId")));
        System.out.println((new StringBuilder("disssssssssssssssssssssssssssssss Id: ")).append(disId).toString());
        DischargeDetailsPopupPojo pojo = dischargeDetailsService.editDischargeDetails(disId);
        return new ModelAndView("dischargeDetailsPopoup", "dischargeDetailsPopupPojo", pojo);
    }

    public ModelAndView paginationNext(HttpServletRequest request)
    {
        paginationService.paginationNext(request);
        return new ModelAndView("discharge", "commonsearchpojo", new CommonSearchPojo());
    }

    public ModelAndView paginationPrivious(HttpServletRequest request)
    {
        paginationService.paginationPrivious(request);
        return new ModelAndView("discharge", "commonsearchpojo", new CommonSearchPojo());
    }

    public ModelAndView firstPage(HttpServletRequest request)
    {
        paginationService.firstPage(request);
        return new ModelAndView("discharge", "commonsearchpojo", new CommonSearchPojo());
    }

    public ModelAndView lastPage(HttpServletRequest request)
    {
        paginationService.lastPage(request);
        return new ModelAndView("discharge", "commonsearchpojo", new CommonSearchPojo());
    }

    Logger logger;
    private PaginationService paginationService;
    private AppointmentService appointmentService;
    private DischargeDetailsService dischargeDetailsService;
}
