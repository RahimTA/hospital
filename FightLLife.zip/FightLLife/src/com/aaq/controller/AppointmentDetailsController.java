// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AppointmentDetailsController.java

package com.aaq.controller;

import com.aaqa.pojo.AppointmentPopupPojo;
import com.aaqa.pojo.CommonSearchPojo;
import com.aaqa.service.AppointmentService;
import com.aaqa.service.PaginationService;
import com.aqaa.com.entity.AppointmentEntity;
import com.aqaa.com.entity.PatientEntity;
import java.io.PrintStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

public class AppointmentDetailsController
{

    public AppointmentDetailsController()
    {
        logger = Logger.getLogger("com/aaq/controller/AppointmentDetailsController");
    }

    public ModelAndView displayAppointmentDetails(CommonSearchPojo commonsearchpojo, HttpServletRequest request)
    {
        java.util.List doctorsList = appointmentService.displayDoctorsList();
        java.util.List periodList = appointmentService.displayPeriodDeatials();
        java.util.List appmtStatusList = appointmentService.displayAppmtStatusDeatils();
        java.util.List bigApptSearchList = appointmentService.getAppointmentDetails(commonsearchpojo);
        request.getSession().setAttribute("bigApptSearchList", bigApptSearchList);
        paginationService.defaultPage(request);
        request.setAttribute("doctorsList", doctorsList);
        request.getSession().setAttribute("periodList", periodList);
        request.getSession().setAttribute("appmtStatusList", appmtStatusList);
        return new ModelAndView("homePage", "commonsearchpojo", new CommonSearchPojo());
    }

    public ModelAndView displayAppointmentDetailsPopUp(AppointmentPopupPojo apptPopuuPojo, HttpServletRequest request)
    {
        java.util.List doctorsList = appointmentService.displayDoctorsList();
        request.getSession().setAttribute("doctorsList", doctorsList);
        return new ModelAndView("appointmentDetailsPopUp", "apptPopuuPojo", new AppointmentPopupPojo());
    }

    public ModelAndView saveAppointmentDetails(AppointmentPopupPojo pojo, BindingResult result, HttpServletRequest request)
    {
        if(result.hasErrors())
            return new ModelAndView("appointmentDetailsPopUp", "apptPopuuPojo", pojo);
        System.out.println(pojo);
        if(pojo != null || pojo.getPatientEntity().getId().intValue() == 0 || pojo.getAppointmentEntity().getApptDateStr() == null)
        {
            System.out.println((new StringBuilder("getentity nd id")).append(pojo.getPatientEntity().getId()).toString());
            System.out.println((new StringBuilder("sasasa")).append(pojo.getAppointmentEntity().getApptDateStr()).toString());
            return new ModelAndView("appointmentDetailsPopUp", "apptPopuuPojo", new AppointmentPopupPojo());
        } else
        {
            appointmentService.saveAppointmentDetails(pojo);
            return new ModelAndView("appointmentDetailsPopUp", "apptPopuuPojo", new AppointmentPopupPojo());
        }
    }

    public ModelAndView getApptDeatailsByFilter(CommonSearchPojo commonsearchpojo, HttpServletRequest request)
    {
        java.util.List doctorsList = appointmentService.displayDoctorsList();
        java.util.List periodList = appointmentService.displayPeriodDeatials();
        java.util.List appmtStatusList = appointmentService.displayAppmtStatusDeatils();
        request.setAttribute("doctorsList", doctorsList);
        request.setAttribute("periodList", periodList);
        request.setAttribute("appmtStatusList", appmtStatusList);
        java.util.List apptSearchList = appointmentService.getApptDeatailsByFilter(commonsearchpojo);
        request.getSession().setAttribute("pagination", apptSearchList);
        return new ModelAndView("homePage", "commonsearchpojo", commonsearchpojo);
    }

    public ModelAndView editAppointmentDeatils(AppointmentPopupPojo apptPopuuPojo, HttpServletRequest request)
    {
        Integer id = Integer.valueOf(Integer.parseInt(request.getParameter("apptId")));
        AppointmentPopupPojo pojo = appointmentService.editAppointmentDetails(id);
        java.util.List doctorsList = appointmentService.displayDoctorsList();
        request.setAttribute("doctorsList", doctorsList);
        return new ModelAndView("appointmentDetailsPopUp", "apptPopuuPojo", pojo);
    }

    public ModelAndView paginationNext(HttpServletRequest request)
    {
        paginationService.paginationNext(request);
        return new ModelAndView("homePage", "commonsearchpojo", new CommonSearchPojo());
    }

    public ModelAndView paginationPrivious(HttpServletRequest request)
    {
        paginationService.paginationPrivious(request);
        return new ModelAndView("homePage", "commonsearchpojo", new CommonSearchPojo());
    }

    public ModelAndView firstPage(HttpServletRequest request)
    {
        paginationService.firstPage(request);
        return new ModelAndView("homePage", "commonsearchpojo", new CommonSearchPojo());
    }

    public ModelAndView lastPage(HttpServletRequest request)
    {
        paginationService.lastPage(request);
        return new ModelAndView("homePage", "commonsearchpojo", new CommonSearchPojo());
    }

    Logger logger;
    private AppointmentService appointmentService;
    private PaginationService paginationService;
}
