// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AdmissionDetailsController.java

package com.aaq.controller;

import com.aaqa.pojo.AdmissionDetailsPopUpPojo;
import com.aaqa.pojo.CommonSearchPojo;
import com.aaqa.service.AdmissionDetailsService;
import com.aaqa.service.PaginationService;
import java.io.PrintStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

public class AdmissionDetailsController
{

    public AdmissionDetailsController()
    {
    }

    public ModelAndView displayAdmissionDetails(HttpServletRequest request, CommonSearchPojo commonsearchpojo)
    {
        java.util.List admissionList = admissionDetailsService.displayAdmissionList();
        request.getSession().setAttribute("admissionList", admissionList);
        java.util.List list = admissionDetailsService.admissionDetails(commonsearchpojo);
        request.getSession().setAttribute("bigApptSearchList", list);
        paginationService.defaultPage(request);
        return new ModelAndView("admissiondetails", "commonsearchpojo", new CommonSearchPojo());
    }

    public ModelAndView displayAdmissionDetailsPopUp()
    {
        return new ModelAndView("admissionDetailsPopUp", "admissionDetailsPopUpPojo", new AdmissionDetailsPopUpPojo());
    }

    public ModelAndView saveAdmissionDetails(AdmissionDetailsPopUpPojo admissionDetailsPopUpPojo, BindingResult result, ModelMap model, HttpServletRequest request)
    {
        if(result.hasErrors())
        {
            System.out.println("admissioncontrollr");
            return new ModelAndView("admissionDetailsPopUp", "admissionDetailsPopUpPojo", admissionDetailsPopUpPojo);
        } else
        {
            admissionDetailsService.saveDetails(admissionDetailsPopUpPojo);
            return new ModelAndView("admissionDetailsPopUp", "admissionDetailsPopUpPojo", admissionDetailsPopUpPojo);
        }
    }

    public ModelAndView selectPatient(HttpServletRequest request, CommonSearchPojo commonsearchpojo)
    {
        request.setAttribute("pojo", new CommonSearchPojo());
        java.util.List plist = admissionDetailsService.searchPatient(commonsearchpojo);
        request.getSession().setAttribute("plist", plist);
        java.util.List patienteValueList = admissionDetailsService.patientValuesdisplay();
        request.getSession().setAttribute("patienteValueList", patienteValueList);
        return new ModelAndView("patient", "admitPojo", commonsearchpojo);
    }

    public String displayBillDetailsForAdmission(AdmissionDetailsPopUpPojo apojo)
    {
        return "displayBillForAdmin";
    }

    public ModelAndView listOfAdmission(CommonSearchPojo commonsearchpojo, HttpServletRequest request)
    {
        java.util.List list = admissionDetailsService.listOfAdmission(commonsearchpojo);
        request.getSession().setAttribute("list", list);
        return new ModelAndView("admissiondetails", "commonsearchpojo", commonsearchpojo);
    }

    public ModelAndView editAdmissionDetails(AdmissionDetailsPopUpPojo adminpojo, HttpServletRequest request)
    {
        Integer id = Integer.valueOf(Integer.parseInt(request.getParameter("id")));
        AdmissionDetailsPopUpPojo pojo = admissionDetailsService.editAdmissionDetails(id);
        return new ModelAndView("admissionDetailsPopUp", "admissionDetailsPopUpPojo", pojo);
    }

    public ModelAndView selectPatientDeatails(HttpServletRequest request, CommonSearchPojo commonsearchpojo)
    {
        request.setAttribute("pojo", new CommonSearchPojo());
        java.util.List plist = admissionDetailsService.searchPatients(commonsearchpojo);
        request.getSession().setAttribute("plist", plist);
        return new ModelAndView("patient", "admitPojo", commonsearchpojo);
    }

    public ModelAndView paginationNext(HttpServletRequest request)
    {
        paginationService.paginationNext(request);
        return new ModelAndView("admissiondetails", "commonsearchpojo", new CommonSearchPojo());
    }

    public ModelAndView paginationPrivious(HttpServletRequest request)
    {
        paginationService.paginationPrivious(request);
        return new ModelAndView("admissiondetails", "commonsearchpojo", new CommonSearchPojo());
    }

    public ModelAndView firstPage(HttpServletRequest request)
    {
        paginationService.firstPage(request);
        return new ModelAndView("admissiondetails", "commonsearchpojo", new CommonSearchPojo());
    }

    public ModelAndView lastPage(HttpServletRequest request)
    {
        paginationService.lastPage(request);
        return new ModelAndView("admissiondetails", "commonsearchpojo", new CommonSearchPojo());
    }

    private PaginationService paginationService;
    private AdmissionDetailsService admissionDetailsService;
}
