// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   MainController.java

package com.aaq.controller;

import com.aaqa.pojo.CommonSearchPojo;
import com.aaqa.service.AppointmentService;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;

public class MainController
{

    public MainController()
    {
    }

    public ModelAndView mainLetmenuDisplay(CommonSearchPojo commonsearchpojo, HttpServletRequest request)
    {
        java.util.List doctorsList = appointmentService.displayDoctorsList();
        java.util.List periodList = appointmentService.displayPeriodDeatials();
        java.util.List appmtStatusList = appointmentService.displayAppmtStatusDeatils();
        java.util.List apptSearchList = appointmentService.getAppointmentDetails(commonsearchpojo);
        request.getSession().setAttribute("doctorsList", doctorsList);
        request.getSession().setAttribute("periodList", periodList);
        request.getSession().setAttribute("appmtStatusList", appmtStatusList);
        request.setAttribute("apptSearchList", apptSearchList);
        return new ModelAndView("homePage", "commonsearchpojo", new CommonSearchPojo());
    }

    private AppointmentService appointmentService;
}
