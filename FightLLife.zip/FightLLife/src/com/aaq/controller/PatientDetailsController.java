// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PatientDetailsController.java

package com.aaq.controller;

import com.aaqa.pojo.*;
import com.aaqa.service.*;
import java.io.PrintStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

public class PatientDetailsController
{

    public PatientDetailsController()
    {
        logger = Logger.getLogger("com/aaq/controller/PatientDetailsController");
    }

    public void setPatientSearchService(PatientSearchService patientSearchService)
    {
        this.patientSearchService = patientSearchService;
    }

    public ModelAndView displayPatientDetails(PatientSearchPojo patientSearchPojo, HttpServletRequest request)
    {
        java.util.List periodList = appointmentService.displayPeriodDeatials();
        request.getSession().setAttribute("periodList", periodList);
        java.util.List plist = patientService.getPatientName();
        request.getSession().setAttribute("list", plist);
        java.util.List patienteValueList = patientService.patientValuesdisplay();
        request.setAttribute("patienteValueList", patienteValueList);
        request.setAttribute("pojo", new CommonSearchPojo());
        java.util.List list = patientSearchService.patientSearchService();
        request.getSession().setAttribute("bigApptSearchList", list);
        paginationService.defaultPage(request);
        return new ModelAndView("patientDetails", "patientSearchPojo", new PatientSearchPojo());
    }

    public ModelAndView course(PatientInfoPojo patientInfoPojo, HttpServletRequest request)
    {
        System.out.println((new StringBuilder("Patient DAO obj is ")).append(patientService).toString());
        java.util.List tiltleList = patientService.getMetaDetails("TitleMetaEntity");
        java.util.List genderList = patientService.getMetaDetails("GenderMetaEntity");
        java.util.List bloodGroupList = patientService.getMetaDetails("BloodGroupMetaEntity");
        java.util.List finStatusList = patientService.getMetaDetails("FinstatusMetaEntity");
        java.util.List castList = patientService.getMetaDetails("CastcatMeta");
        java.util.List occupationList = patientService.getMetaDetails("OcupationMeta");
        java.util.List mstatusList = patientService.getMetaDetails("MstatusMetaEntity");
        java.util.List allergyList = patientService.getMetaDetails("AlergyMetaEntity");
        java.util.List cityList = patientService.getMetaDetails("CityMetaEntity");
        java.util.List countryList = patientService.getMetaDetails("CountryMetaEntity");
        java.util.List districtList = patientService.getMetaDetails("DistrictMetaEntity");
        java.util.List stateList = patientService.getMetaDetails("StateMetaEntity");
        request.setAttribute("tiltleList", tiltleList);
        request.setAttribute("genderList", genderList);
        request.setAttribute("bloodGroupList", bloodGroupList);
        request.setAttribute("finStatusList", finStatusList);
        request.setAttribute("castList", castList);
        request.setAttribute("occupationList", occupationList);
        request.setAttribute("mstatusList", mstatusList);
        request.getSession().setAttribute("allergyList", allergyList);
        request.setAttribute("cityList", cityList);
        request.setAttribute("countryList", countryList);
        request.setAttribute("districtList", districtList);
        request.setAttribute("stateList", stateList);
        request.setAttribute("PatientInfoPojo", new PatientInfoPojo());
        return new ModelAndView("patientDetailsPopUp", "patientInfoPojo", new PatientInfoPojo());
    }

    public ModelAndView admissiondetails(PatientInfoPojo patientInfoPojo, HttpServletRequest request)
    {
        request.setAttribute("PatientInfoPojo", new PatientInfoPojo());
        return new ModelAndView("patientDetailsPopUp", "PatientInfoPojo", new PatientInfoPojo());
    }

    public ModelAndView familydetails(PatientInfoPojo patientInfoPojo, HttpServletRequest request)
    {
        request.setAttribute("PatientInfoPojo", new PatientInfoPojo());
        return new ModelAndView("patientDetailsPopUp", "PatientInfoPojo", new PatientInfoPojo());
    }

    public ModelAndView savedetails(PatientInfoPojo patientInfoPojo, BindingResult result, ModelMap model, HttpServletRequest request)
    {
        if(result.hasErrors())
        {
            return new ModelAndView("patientDetailsPopUp", "PatientInfoPojo", patientInfoPojo);
        } else
        {
            patientService.saveDetails(patientInfoPojo);
            return new ModelAndView("patientDetailsPopUp", "PatientInfoPojo", patientInfoPojo);
        }
    }

    public ModelAndView searchPatient(CommonSearchPojo commonsearchpojo, HttpServletRequest request)
    {
        System.out.println("Hi this is getDischargeDetailsByFilter");
        System.out.println((new StringBuilder("Period is: ")).append(commonsearchpojo.getPeriod()).toString());
        System.out.println((new StringBuilder("name is: ")).append(commonsearchpojo.getSearch()).toString());
        System.out.println((new StringBuilder("value is: ")).append(commonsearchpojo.getValue()).toString());
        request.setAttribute("pojo", new CommonSearchPojo());
        java.util.List plist = patientService.searchPatient(commonsearchpojo);
        request.getSession().setAttribute("plist", plist);
        java.util.List patienteValueList = patientService.patientValuesdisplay();
        request.setAttribute("patienteValueList", patienteValueList);
        return new ModelAndView("patientDetails", "commonsearchpojo", commonsearchpojo);
    }

    public ModelAndView displayPatientsForSelect(CommonSearchPojo commonsearchpojo, HttpServletRequest request)
    {
        request.setAttribute("pojo", new CommonSearchPojo());
        java.util.List plist = patientService.searchPatient(commonsearchpojo);
        request.getSession().setAttribute("plist", plist);
        return new ModelAndView("SelectPatientForAppointment");
    }

    public ModelAndView editPatientDetails(PatientInfoPojo patientInfoPojo, HttpServletRequest request)
    {
        Integer id = Integer.valueOf(Integer.parseInt(request.getParameter("patientId")));
        patientInfoPojo = patientService.editPatientDetails(id);
        return new ModelAndView("patientDetailsPopUp", "patientInfoPojo", patientInfoPojo);
    }

    public ModelAndView paginationNext(HttpServletRequest request)
    {
        paginationService.paginationNext(request);
        request.setAttribute("pojo", new CommonSearchPojo());
        return new ModelAndView("patientDetails", "patientSearchPojo", new PatientSearchPojo());
    }

    public ModelAndView paginationPrivious(HttpServletRequest request)
    {
        paginationService.paginationPrivious(request);
        request.setAttribute("pojo", new CommonSearchPojo());
        return new ModelAndView("patientDetails", "patientSearchPojo", new PatientSearchPojo());
    }

    public ModelAndView firstPage(HttpServletRequest request)
    {
        paginationService.firstPage(request);
        request.setAttribute("pojo", new CommonSearchPojo());
        return new ModelAndView("patientDetails", "patientSearchPojo", new PatientSearchPojo());
    }

    public ModelAndView lastPage(HttpServletRequest request)
    {
        paginationService.lastPage(request);
        request.setAttribute("pojo", new CommonSearchPojo());
        return new ModelAndView("patientDetails", "patientSearchPojo", new PatientSearchPojo());
    }

    private PaginationService paginationService;
    private AppointmentService appointmentService;
    private TestDetailsService testDetailsService;
    private PatientSearchService patientSearchService;
    private PatientDetailsService patientService;
    Logger logger;
}
