// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TestDetailsService.java

package com.aaqa.service;

import com.aaqa.dao.TestDAO;
import com.aaqa.pojo.CommonSearchPojo;
import com.aaqa.pojo.Test_TestDetails_Pojo;
import java.util.List;
import org.apache.log4j.Logger;

public class TestDetailsService
{

    public TestDetailsService()
    {
        logger = Logger.getLogger("com/aaqa/service/TestDetailsService");
    }

    public void saveTestDetails(Test_TestDetails_Pojo testdetailsPojo)
    {
        testDao.saveTestDetails(testdetailsPojo);
    }

    public List getPatientDetailForTest()
    {
        List list = testDao.getPatientDetailForTest();
        return list;
    }

    public List getTestDetails()
    {
        List list = testDao.getTestDetails();
        return list;
    }

    public List getPatientName()
    {
        List plist = testDao.getPatientName();
        return plist;
    }

    public List getTestName()
    {
        List testList = testDao.getTestName();
        return testList;
    }

    public List searchPatientTest(CommonSearchPojo commonSearchPojo)
    {
        List searchlist = testDao.searchPatientTest(commonSearchPojo);
        return searchlist;
    }

    public Test_TestDetails_Pojo getTestDetailsForUpdate(Integer id1)
    {
        Test_TestDetails_Pojo testDetailsPojo = testDao.getTestDetailsForUpdate(id1);
        logger.fatal((new StringBuilder("From TestService... Date is::")).append(testDetailsPojo.getDate()).toString());
        return testDetailsPojo;
    }

    Logger logger;
    public TestDAO testDao;
}
