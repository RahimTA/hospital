// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ConsentService.java

package com.aaqa.service;

import com.aaqa.dao.ConsentDAO;
import com.aaqa.pojo.ConsentFormPopupPojo;
import com.aaqa.pojo.ConsentMasterPopupPojo;
import java.util.List;

public class ConsentService
{

    public ConsentService()
    {
    }

    public void saveDetails(ConsentMasterPopupPojo cmpojo)
    {
        consentdao.saveDetails(cmpojo);
    }

    public void saveformDetails(ConsentFormPopupPojo cfpojo)
    {
        consentdao.saveformDetails(cfpojo);
    }

    public List getConsantMaster(ConsentMasterPopupPojo consentmaster)
    {
        return consentdao.getConsantMaster(consentmaster);
    }

    public List getConsantMasters()
    {
        return consentdao.getConsantMasters();
    }

    public List getAllConsents(ConsentFormPopupPojo consentform)
    {
        return consentdao.getAllConsents(consentform);
    }

    public List getConsantMasterDetails(ConsentMasterPopupPojo pojo)
    {
        return consentdao.getConsantMasterDetails(pojo);
    }

    public List getAllConsent(ConsentFormPopupPojo pojo)
    {
        return consentdao.getAllConsent(pojo);
    }

    public ConsentMasterPopupPojo editConsentMasterDetails(Integer id)
    {
        return consentdao.editConsentMasterDetails(id);
    }

    public ConsentFormPopupPojo editConsenDetails(Integer id)
    {
        return consentdao.editConsenDetails(id);
    }

    public List consentMastersDetails()
    {
        return consentdao.getconsentMastersDetails();
    }

    private ConsentDAO consentdao;
}
