// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AccountDetailsService.java

package com.aaqa.service;

import com.aaqa.dao.AccountDetailsDao;
import com.aaqa.pojo.AccountBillingDetailsPojo;
import java.util.Arrays;
import java.util.List;

public class AccountDetailsService
{

    public AccountDetailsService()
    {
    }

    public void saveAccountBillingDetails(AccountBillingDetailsPojo accountBillingDetailsPojo, String data)
    {
        List list = null;
        int length = data.length() - 1;
        for(int i = 0; i <= length - 1; i++)
        {
            String result[] = data.split(";");
            int length1 = result.length;
            for(int j = 0; j <= length1 - 1; j++)
            {
                String fres[] = result[j].split(",");
                list = Arrays.asList(fres);
            }

        }

        accountDAO.saveAccountBillingDetails(accountBillingDetailsPojo);
    }

    public List getPatientDetailForTest()
    {
        List plist = accountDAO.getPatientDetailForTest();
        return plist;
    }

    public List displayDoctorsList()
    {
        List doctorsList = accountDAO.displayDoctorsList();
        return doctorsList;
    }

    public List getAccountBillingDetails()
    {
        List billList = accountDAO.getAccountBillingDetails();
        return billList;
    }

    private AccountDetailsDao accountDAO;
}
