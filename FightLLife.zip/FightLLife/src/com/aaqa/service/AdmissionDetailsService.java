// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AdmissionDetailsService.java

package com.aaqa.service;

import com.aaqa.dao.AdmissionDAO;
import com.aaqa.pojo.AdmissionDetailsPopUpPojo;
import com.aaqa.pojo.CommonSearchPojo;
import java.util.List;

public class AdmissionDetailsService
{

    public AdmissionDetailsService()
    {
    }

    public void saveDetails(AdmissionDetailsPopUpPojo admissionDetailsPopUpPojo)
    {
        admissionDAO.saveDetails(admissionDetailsPopUpPojo);
    }

    public List displayAdmissionList()
    {
        return admissionDAO.displayAdmissionList();
    }

    public List listOfAdmission(CommonSearchPojo commonsearchpojo)
    {
        return admissionDAO.listOfAdmission(commonsearchpojo);
    }

    public AdmissionDetailsPopUpPojo editAdmissionDetails(Integer id)
    {
        return admissionDAO.editAdmissionDetails(id);
    }

    public List admissionDetails(CommonSearchPojo commonsearchpojo)
    {
        return admissionDAO.admissionDetails(commonsearchpojo);
    }

    public List searchPatient(CommonSearchPojo commonsearchpojo)
    {
        List searchlist = admissionDAO.searchPatient(commonsearchpojo);
        return searchlist;
    }

    public List patientValuesdisplay()
    {
        List patienteValueList = admissionDAO.patientValuesdisplay();
        return patienteValueList;
    }

    public List searchPatients(CommonSearchPojo commonsearchpojo)
    {
        List searchlist = admissionDAO.searchPatients(commonsearchpojo);
        return searchlist;
    }

    public AdmissionDAO admissionDAO;
}
