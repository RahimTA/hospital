// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AppointmentService.java

package com.aaqa.service;

import com.aaqa.dao.AppointmentDAO;
import com.aaqa.pojo.AppointmentPopupPojo;
import com.aaqa.pojo.CommonSearchPojo;
import java.util.List;

public class AppointmentService
{

    public AppointmentService()
    {
    }

    public List displayDoctorsList()
    {
        return appointmentDAO.displayDoctorsList();
    }

    public List displayPeriodDeatials()
    {
        return appointmentDAO.displayPeriodDeatials();
    }

    public List displayAppmtStatusDeatils()
    {
        return appointmentDAO.displayAppmtStatusDeatils();
    }

    public void saveAppointmentDetails(AppointmentPopupPojo pojo)
    {
        appointmentDAO.saveAppointmentDetails(pojo);
    }

    public List getAppointmentDetails(CommonSearchPojo pojo)
    {
        return appointmentDAO.getAppointmentDetails(pojo);
    }

    public List getApptDeatailsByFilter(CommonSearchPojo pojo)
    {
        return appointmentDAO.getApptDeatailsByFilter(pojo);
    }

    public AppointmentPopupPojo editAppointmentDetails(Integer id)
    {
        return appointmentDAO.editAppointmentDetails(id);
    }

    private AppointmentDAO appointmentDAO;
}
