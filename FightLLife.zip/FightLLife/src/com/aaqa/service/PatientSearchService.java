// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PatientSearchService.java

package com.aaqa.service;

import com.aaqa.dao.PatientSearchDao;
import com.aaqa.pojo.AccountBillingDetailsPojo;
import com.aaqa.pojo.PatientSearchPojo;
import com.aqaa.com.entity.AccountBillingDetailsEntity;
import java.util.List;

public class PatientSearchService
{

    public PatientSearchService()
    {
    }

    public void setPatientSearchDao(PatientSearchDao patientSearchDao)
    {
        this.patientSearchDao = patientSearchDao;
    }

    public List patientSearchService()
    {
        List list = patientSearchDao.getPatientSearchDetails();
        return list;
    }

    public AccountBillingDetailsPojo getPatientSearchDetailsById(Integer id)
    {
        PatientSearchPojo pojo = patientSearchDao.getPatientSearchDetailsById(id);
        AccountBillingDetailsEntity pojo1 = new AccountBillingDetailsEntity();
        pojo1.setPatientId((new StringBuilder()).append(pojo.getPatientId()).toString());
        pojo1.setPatientName(pojo.getPatientName());
        AccountBillingDetailsPojo pojo2 = new AccountBillingDetailsPojo();
        pojo2.setAbde(pojo1);
        return pojo2;
    }

    public PatientSearchDao patientSearchDao;
}
