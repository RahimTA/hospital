// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CommonClass.java

package com.aaqa.customtag;

import com.aaqa.dao.PatientDAO;
import java.io.PrintStream;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class CommonClass
    implements ApplicationContextAware
{

    public CommonClass()
    {
    }

    public static ApplicationContext getContainer()
    {
        return container;
    }

    public void setContainer(ApplicationContext container)
    {
        container = container;
    }

    public PatientDAO createBean()
    {
        PatientDAO patientDAO = (PatientDAO)container.getBean("patientDAO");
        System.out.println((new StringBuilder("Container  is ")).append(container).toString());
        System.out.println((new StringBuilder("PatientDao is ")).append(patientDAO).toString());
        return patientDAO;
    }

    public void setApplicationContext(ApplicationContext arg0)
        throws BeansException
    {
        container = arg0;
    }

    private static ApplicationContext container = null;

}
