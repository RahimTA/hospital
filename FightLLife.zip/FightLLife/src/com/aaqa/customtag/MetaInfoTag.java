// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   MetaInfoTag.java

package com.aaqa.customtag;

import com.aaqa.dao.PatientDAO;
import com.aqaa.interfaces.intr.MetaDataInterfaces;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.TagSupport;
import org.springframework.context.ApplicationContext;

// Referenced classes of package com.aaqa.customtag:
//            CommonClass

public class MetaInfoTag extends TagSupport
{

    public MetaInfoTag()
    {
    }

    public Integer getSelVal()
    {
        return selVal;
    }

    public void setSelVal(Integer selVal)
    {
        this.selVal = selVal;
    }

    public String getMetaName()
    {
        return metaName;
    }

    public void setMetaName(String metaName)
    {
        this.metaName = metaName;
    }

    public int doStartTag()
        throws JspException
    {
        JspWriter out = pageContext.getOut();
        PatientDAO patientDAO = (PatientDAO)CommonClass.getContainer().getBean("patientDAO");
        List list = patientDAO.getMetaDetails(metaName);
        for(Iterator iterator = list.iterator(); iterator.hasNext();)
        {
            MetaDataInterfaces bgl = (MetaDataInterfaces)iterator.next();
            try
            {
                if(bgl.getCode().equals(selVal))
                    out.println((new StringBuilder("<option value=")).append(bgl.getCode()).append(" selected='selected' >").append(bgl.getDesc()).append("</option>").toString());
                else
                    out.println((new StringBuilder("<option value=")).append(bgl.getCode()).append(" >").append(bgl.getDesc()).append("</option>").toString());
            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
        }

        return 6;
    }

    public int doEndTag()
        throws JspException
    {
        return super.doEndTag();
    }

    private static final long serialVersionUID = 1L;
    private String metaName;
    private Integer selVal;
}
