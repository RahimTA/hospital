// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   RoundNotesPopupPojo.java

package com.aaqa.pojo;

import java.util.Date;
import java.util.List;

public class RoundNotesPopupPojo
{

    public RoundNotesPopupPojo()
    {
    }

    public String getPatientId()
    {
        return patientId;
    }

    public void setPatientId(String patientId)
    {
        this.patientId = patientId;
    }

    public Date getDate()
    {
        return date;
    }

    public void setDate(Date date)
    {
        this.date = date;
    }

    public String getTime()
    {
        return time;
    }

    public void setTime(String time)
    {
        this.time = time;
    }

    public String getPostOperativeDay()
    {
        return postOperativeDay;
    }

    public void setPostOperativeDay(String postOperativeDay)
    {
        this.postOperativeDay = postOperativeDay;
    }

    public List getDoctor()
    {
        return doctor;
    }

    public void setDocter(List doctor)
    {
        this.doctor = doctor;
    }

    public String getSymptoms()
    {
        return symptoms;
    }

    public void setSymptoms(String symptoms)
    {
        this.symptoms = symptoms;
    }

    public String getExaminations()
    {
        return examinations;
    }

    public void setExaminations(String examinations)
    {
        this.examinations = examinations;
    }

    public String getGeneralNursingAdvice()
    {
        return generalNursingAdvice;
    }

    public void setGeneralNursingAdvice(String generalNursingAdvice)
    {
        this.generalNursingAdvice = generalNursingAdvice;
    }

    public String getAssessment()
    {
        return assessment;
    }

    public void setAssessment(String assessment)
    {
        this.assessment = assessment;
    }

    public String getPlan()
    {
        return plan;
    }

    public void setPlan(String plan)
    {
        this.plan = plan;
    }

    private String patientId;
    private Date date;
    private String time;
    private String postOperativeDay;
    private List doctor;
    private String symptoms;
    private String examinations;
    private String generalNursingAdvice;
    private String assessment;
    private String plan;
}
