// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DischargeDetailsPopupHeaderPojo.java

package com.aaqa.pojo;


public class DischargeDetailsPopupHeaderPojo
{

    public DischargeDetailsPopupHeaderPojo()
    {
    }

    public String getDischargeDate()
    {
        return dischargeDate;
    }

    public void setDischargeDate(String dischargeDate)
    {
        this.dischargeDate = dischargeDate;
    }

    public String getDischargeTime()
    {
        return dischargeTime;
    }

    public void setDischargeTime(String dischargeTime)
    {
        this.dischargeTime = dischargeTime;
    }

    public String getDoctor()
    {
        return doctor;
    }

    public void setDoctor(String doctor)
    {
        this.doctor = doctor;
    }

    private String dischargeDate;
    private String dischargeTime;
    private String doctor;
}
