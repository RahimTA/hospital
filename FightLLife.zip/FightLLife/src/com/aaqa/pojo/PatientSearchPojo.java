// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PatientSearchPojo.java

package com.aaqa.pojo;

import com.ibm.icu.text.SimpleDateFormat;
import java.text.Format;
import java.text.ParseException;
import java.util.Date;

public class PatientSearchPojo
{

    public PatientSearchPojo()
    {
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Integer getPid()
    {
        return pid;
    }

    public void setPid(Integer pid)
    {
        this.pid = pid;
    }

    public Integer getPatientId()
    {
        return patientId;
    }

    public void setPatientId(Integer patientId)
    {
        this.patientId = patientId;
    }

    public String getPatientName()
    {
        return patientName;
    }

    public void setPatientName(String patientName)
    {
        this.patientName = patientName;
    }

    public int getAge()
    {
        return age;
    }

    public void setAge(int age)
    {
        this.age = age;
    }

    public String getGender()
    {
        return gender;
    }

    public void setGender(String gender)
    {
        this.gender = gender;
    }

    public Date getRegistrationDate()
    {
        return registrationDate;
    }

    public void setRegistrationDate(Date registrationDate)
    {
        this.registrationDate = registrationDate;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    public String getOccupation()
    {
        return occupation;
    }

    public void setOccupation(String occupation)
    {
        this.occupation = occupation;
    }

    public String getRegistrationDateStr()
    {
        Format formatter = new SimpleDateFormat("yyyy/mm/dd");
        if(registrationDate == null || registrationDate.equals(""))
        {
            return this.registrationDateStr;
        } else
        {
            String registrationDateStr = formatter.format(registrationDate);
            return registrationDateStr;
        }
    }

    public void setRegistrationDateStr(String registrationDateStr)
    {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/mm/dd");
        try
        {
            registrationDate = formatter.parse(registrationDateStr);
        }
        catch(ParseException e)
        {
            e.printStackTrace();
        }
        this.registrationDateStr = registrationDateStr;
    }

    private Integer id;
    private Integer pid;
    private Integer patientId;
    private String patientName;
    private int age;
    private String ageStr;
    private String gender;
    private Date registrationDate;
    private String registrationDateStr;
    private String city;
    private String occupation;
}
