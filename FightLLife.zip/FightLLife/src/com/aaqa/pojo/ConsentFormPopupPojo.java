// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ConsentFormPopupPojo.java

package com.aaqa.pojo;

import java.text.*;
import java.util.Date;

public class ConsentFormPopupPojo
{

    public ConsentFormPopupPojo()
    {
    }

    public Integer getCmid()
    {
        return cmid;
    }

    public void setCmid(Integer cmid)
    {
        this.cmid = cmid;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public Integer getPatientid()
    {
        return patientid;
    }

    public void setPatientid(Integer patientid)
    {
        this.patientid = patientid;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Date getDate()
    {
        return date;
    }

    public void setDate(Date date)
    {
        this.date = date;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public String getSignature()
    {
        return signature;
    }

    public void setSignature(String signature)
    {
        this.signature = signature;
    }

    public String getConsentname()
    {
        return consentname;
    }

    public void setConsentname(String consentname)
    {
        this.consentname = consentname;
    }

    public String getApptDateStr()
    {
        Format formatter = new SimpleDateFormat("yyyy/mm/dd");
        if(date == null || date.equals(""))
        {
            return this.apptDateStr;
        } else
        {
            String apptDateStr = formatter.format(date);
            return apptDateStr;
        }
    }

    public void setApptDateStr(String admitDateStr)
    {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/mm/dd");
        try
        {
            date = formatter.parse(admitDateStr);
        }
        catch(ParseException e)
        {
            e.printStackTrace();
        }
        apptDateStr = apptDateStr;
    }

    private Date date;
    private String description;
    private String signature;
    private String name;
    private Integer id;
    private Integer patientid;
    private String consentname;
    private Integer cmid;
    private String apptDateStr;
}
