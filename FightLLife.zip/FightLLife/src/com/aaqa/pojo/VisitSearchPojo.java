// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   VisitSearchPojo.java

package com.aaqa.pojo;

import java.util.Date;

public class VisitSearchPojo
{

    public VisitSearchPojo()
    {
    }

    public Integer getVisitId()
    {
        return visitId;
    }

    public void setVisitId(Integer visitId)
    {
        this.visitId = visitId;
    }

    public Date getVisitDate()
    {
        return visitDate;
    }

    public void setVisitDate(Date visitDate)
    {
        this.visitDate = visitDate;
    }

    public String getPatientName()
    {
        return patientName;
    }

    public void setPatientName(String patientName)
    {
        this.patientName = patientName;
    }

    public String getDob()
    {
        return dob;
    }

    public void setDob(String dob)
    {
        this.dob = dob;
    }

    public String getGender()
    {
        return gender;
    }

    public void setGender(String gender)
    {
        this.gender = gender;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    public String getVisitTime()
    {
        return visitTime;
    }

    public void setVisitTime(String visitTime)
    {
        this.visitTime = visitTime;
    }

    public String toString()
    {
        return (new StringBuilder("VisitSearchPojo [visitId=")).append(visitId).append(", visitDate=").append(visitDate).append(", visitTime=").append(visitTime).append(", patientName=").append(patientName).append(", dob=").append(dob).append(", gender=").append(gender).append(", city=").append(city).append("]").toString();
    }

    private Integer visitId;
    private Date visitDate;
    private String visitTime;
    private String patientName;
    private String dob;
    private String gender;
    private String city;
}
