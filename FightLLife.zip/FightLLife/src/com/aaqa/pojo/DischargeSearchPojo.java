// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DischargeSearchPojo.java

package com.aaqa.pojo;

import java.util.Date;

public class DischargeSearchPojo
{

    public DischargeSearchPojo()
    {
    }

    public String getPatientName()
    {
        return patientName;
    }

    public void setPatientName(String patientName)
    {
        this.patientName = patientName;
    }

    public Date getAdmissionDate()
    {
        return admissionDate;
    }

    public void setAdmissionDate(Date admissionDate)
    {
        this.admissionDate = admissionDate;
    }

    public Date getDischargeDate()
    {
        return dischargeDate;
    }

    public void setDischargeDate(Date dischargeDate)
    {
        this.dischargeDate = dischargeDate;
    }

    public Date getFollowupDate()
    {
        return followupDate;
    }

    public void setFollowupDate(Date followupDate)
    {
        this.followupDate = followupDate;
    }

    public String getDoctorName()
    {
        return doctorName;
    }

    public void setDoctorName(String doctorName)
    {
        this.doctorName = doctorName;
    }

    public Integer getDisId()
    {
        return disId;
    }

    public void setDisId(Integer disId)
    {
        this.disId = disId;
    }

    private Integer disId;
    private String patientName;
    private String doctorName;
    private Date admissionDate;
    private Date dischargeDate;
    private Date followupDate;
}
