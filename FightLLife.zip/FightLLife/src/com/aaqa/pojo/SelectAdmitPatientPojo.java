// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SelectAdmitPatientPojo.java

package com.aaqa.pojo;

import com.ibm.icu.text.SimpleDateFormat;
import java.text.Format;
import java.text.ParseException;
import java.util.Date;

public class SelectAdmitPatientPojo
{

    public SelectAdmitPatientPojo()
    {
    }

    public Date getAdmitDate()
    {
        return admitDate;
    }

    public void setAdmitDate(Date admitDate)
    {
        this.admitDate = admitDate;
    }

    public String getPname()
    {
        return pname;
    }

    public void setPname(String pname)
    {
        this.pname = pname;
    }

    public String getAdmissioncode()
    {
        return admissioncode;
    }

    public void setAdmissioncode(String admissioncode)
    {
        this.admissioncode = admissioncode;
    }

    public String getPid()
    {
        return pid;
    }

    public void setPid(String pid2)
    {
        pid = pid2;
    }

    public String getAdmitDateStr()
    {
        Format formatter = new SimpleDateFormat("yyyy/mm/dd");
        String stringDate = null;
        if(admitDate == null || admitDate.equals(""))
        {
            return stringDate;
        } else
        {
            stringDate = formatter.format(admitDate);
            return stringDate;
        }
    }

    public void setAdmitDateStr(String admitDateStr)
    {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/mm/dd");
        try
        {
            admitDate = formatter.parse(admitDateStr);
        }
        catch(ParseException e)
        {
            e.printStackTrace();
        }
        this.admitDateStr = admitDateStr;
    }

    private String pid;
    private String pname;
    private String admissioncode;
    private Date admitDate;
    private String admitDateStr;
}
