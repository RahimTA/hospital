// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ExternalMedicationPojo.java

package com.aaqa.pojo;

import com.aqaa.com.entity.*;

public class ExternalMedicationPojo
{

    public ExternalMedicationPojo()
    {
        visitId = new VisitEntity();
        followupAfter = new FollowUpAfterMetaEntity();
        type = new MedicationTypeMetaEntity();
        category = new MedicationCategoryMetaEntity();
        medicineDrug = new MedicineMetaEntity();
        strength = new MedicationStrengthMetaEntity();
        dosage = new DosageMetaEntity();
        duration = new MedicationDurationMetaEntity();
        doseMarks = new DoseRemarksMetaEntity();
        remarks = new MedicationRemarksMetaEntity();
    }

    public VisitEntity getVisitId()
    {
        return visitId;
    }

    public void setVisitId(VisitEntity visitId)
    {
        this.visitId = visitId;
    }

    public String getLoad()
    {
        return load;
    }

    public void setLoad(String load)
    {
        this.load = load;
    }

    public FollowUpAfterMetaEntity getFollowupAfter()
    {
        return followupAfter;
    }

    public void setFollowupAfter(FollowUpAfterMetaEntity followupAfter)
    {
        this.followupAfter = followupAfter;
    }

    public String getLanguage()
    {
        return language;
    }

    public void setLanguage(String language)
    {
        this.language = language;
    }

    public MedicationTypeMetaEntity getType()
    {
        return type;
    }

    public void setType(MedicationTypeMetaEntity type)
    {
        this.type = type;
    }

    public MedicationCategoryMetaEntity getCategory()
    {
        return category;
    }

    public void setCategory(MedicationCategoryMetaEntity category)
    {
        this.category = category;
    }

    public MedicineMetaEntity getMedicineDrug()
    {
        return medicineDrug;
    }

    public void setMedicineDrug(MedicineMetaEntity medicineDrug)
    {
        this.medicineDrug = medicineDrug;
    }

    public MedicationStrengthMetaEntity getStrength()
    {
        return strength;
    }

    public void setStrength(MedicationStrengthMetaEntity strength)
    {
        this.strength = strength;
    }

    public DosageMetaEntity getDosage()
    {
        return dosage;
    }

    public void setDosage(DosageMetaEntity dosage)
    {
        this.dosage = dosage;
    }

    public MedicationDurationMetaEntity getDuration()
    {
        return duration;
    }

    public void setDuration(MedicationDurationMetaEntity duration)
    {
        this.duration = duration;
    }

    public String getTotal()
    {
        return total;
    }

    public void setTotal(String total)
    {
        this.total = total;
    }

    public DoseRemarksMetaEntity getDoseMarks()
    {
        return doseMarks;
    }

    public void setDoseMarks(DoseRemarksMetaEntity doseMarks)
    {
        this.doseMarks = doseMarks;
    }

    public MedicationRemarksMetaEntity getRemarks()
    {
        return remarks;
    }

    public void setRemarks(MedicationRemarksMetaEntity remarks)
    {
        this.remarks = remarks;
    }

    public String getSpecialLang()
    {
        return specialLang;
    }

    public void setSpecialLang(String specialLang)
    {
        this.specialLang = specialLang;
    }

    public String getPlus()
    {
        return plus;
    }

    public void setPlus(String plus)
    {
        this.plus = plus;
    }

    public String getBlank1()
    {
        return blank1;
    }

    public void setBlank1(String blank1)
    {
        this.blank1 = blank1;
    }

    public String getBlank2()
    {
        return blank2;
    }

    public void setBlank2(String blank2)
    {
        this.blank2 = blank2;
    }

    private String load;
    private String language;
    private String total;
    private String specialLang;
    private String plus;
    private String blank1;
    private String blank2;
    private VisitEntity visitId;
    private FollowUpAfterMetaEntity followupAfter;
    private MedicationTypeMetaEntity type;
    private MedicationCategoryMetaEntity category;
    private MedicineMetaEntity medicineDrug;
    private MedicationStrengthMetaEntity strength;
    private DosageMetaEntity dosage;
    private MedicationDurationMetaEntity duration;
    private DoseRemarksMetaEntity doseMarks;
    private MedicationRemarksMetaEntity remarks;
}
