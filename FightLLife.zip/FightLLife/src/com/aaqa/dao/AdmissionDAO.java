// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AdmissionDAO.java

package com.aaqa.dao;

import com.aaqa.pojo.AdmissionDetailsPopUpPojo;
import com.aaqa.pojo.AdmissionPatientSearchPojo;
import com.aaqa.pojo.AdmissionSearchPojo;
import com.aaqa.pojo.CommonSearchPojo;
import com.aaqa.pojo.PatientSearchPojo;
import com.aqaa.com.entity.AdmissionEntity;
import com.aqaa.com.entity.AdmittingConsultantMetaEntity;
import com.aqaa.com.entity.BedEntity;
import com.aqaa.com.entity.BedMetaEntity;
import com.aqaa.com.entity.ClassMetaEntity;
import com.aqaa.com.entity.OperationTypeMetaEntity;
import com.aqaa.com.entity.PatientEntity;
import com.aqaa.com.entity.StatusMetaEntity;
import com.aqaa.com.entity.WardMetaEntity;
import com.aqaa.util.AgeCalculation;
import com.aqaa.util.PeriodCommonLogic;
import com.ibm.icu.text.SimpleDateFormat;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class AdmissionDAO
{

    public AdmissionDAO()
    {
    }

    public void setHibernatetemplate(HibernateTemplate hibernatetemplate)
    {
        this.hibernatetemplate = hibernatetemplate;
    }

    public void saveDetails(AdmissionDetailsPopUpPojo admissionDetailsPopUpPojo)
    {
        AdmissionEntity admission = admissionDetailsPopUpPojo.getAdmission();
        BedEntity bed = admissionDetailsPopUpPojo.getBed();
        admission.setBedEntity(bed);
        bed.setAdmissionEntity(admission);
        hibernatetemplate.saveOrUpdate(admission);
    }

    public List displayAdmissionList()
    {
        return hibernatetemplate.find("from AdmissionSearchEntity");
    }

    public List listOfAdmission(CommonSearchPojo pojo)
    {
        Session session = hibernatetemplate.getSessionFactory().openSession();
        Criteria criteria = session.createCriteria("com/aqaa/com/entity/AdmissionEntity", "adm");
        criteria.createAlias("adm.status", "st");
        criteria.createAlias("adm.type", "ty");
        criteria.createAlias("adm.admissionClass", "ac");
        criteria.createAlias("adm.admittingConsultant", "acon");
        if(pojo.getPeriod() != null && !pojo.getPeriod().equals(""))
        {
            List dateList = PeriodCommonLogic.getPeriodDeatils(pojo.getPeriod());
            if(dateList.size() == 2)
                criteria.add(Restrictions.between("adm.admissionDate", dateList.get(0), dateList.get(1)));
            else
                criteria.add(Restrictions.eq("adm.admissionDate", dateList.get(0)));
        }
        if(pojo.getSearch().intValue() == 2)
            criteria.add(Restrictions.like("adm.name", (new StringBuilder("%")).append(pojo.getSearch3()).append("%").toString()));
        else
        if(pojo.getSearch().intValue() == 3)
            criteria.add(Restrictions.eq("adm.pid", pojo.getSearch3()));
        else
        if(pojo.getSearch().intValue() == 4)
            criteria.add(Restrictions.eq("adm.admissionCode", pojo.getSearch3()));
        else
        if(pojo.getSearch().intValue() == 5)
            criteria.add(Restrictions.eq("adm.age", pojo.getSearch3()));
        else
        if(pojo.getSearch().intValue() == 6)
            criteria.add(Restrictions.eq("ty.desc", pojo.getSearch3()));
        else
        if(pojo.getSearch().intValue() == 7)
            criteria.add(Restrictions.eq("st.desc", pojo.getSearch3()));
        else
        if(pojo.getSearch().intValue() == 8)
            criteria.add(Restrictions.eq("ac.desc", pojo.getSearch3()));
        else
        if(pojo.getSearch().intValue() == 9)
            criteria.add(Restrictions.eq("acon.desc", pojo.getSearch3()));
        else
            pojo.getSearch().intValue();
        ProjectionList proList = Projections.projectionList();
        proList.add(Projections.property("adm.name"));
        proList.add(Projections.property("adm.pid"));
        proList.add(Projections.property("adm.admissionCode"));
        proList.add(Projections.property("adm.admissionDate"));
        proList.add(Projections.property("adm.age"));
        proList.add(Projections.property("ty.desc"));
        proList.add(Projections.property("st.desc"));
        proList.add(Projections.property("ac.desc"));
        proList.add(Projections.property("acon.desc"));
        criteria.setProjection(proList);
        List list = criteria.list();
        List admList = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            String name = (String)((Object[])list.get(i))[0];
            String pid = (String)((Object[])list.get(i))[1];
            String code = (String)((Object[])list.get(i))[2];
            Date date = (Date)((Object[])list.get(i))[3];
            String age = (String)((Object[])list.get(i))[4];
            String otype = (String)((Object[])list.get(i))[5];
            String status = (String)((Object[])list.get(i))[6];
            String aclass = (String)((Object[])list.get(i))[7];
            String doctor = (String)((Object[])list.get(i))[8];
            AdmissionSearchPojo apojo = new AdmissionSearchPojo();
            apojo.setPatientName(name);
            apojo.setPatientId(pid);
            apojo.setAdmissionCode(code);
            apojo.setAdmissionDate(date);
            apojo.setYears(age);
            apojo.setStatus(status);
            apojo.setDoctorName(doctor);
            apojo.setType(otype);
            apojo.setClasstype(aclass);
            admList.add(apojo);
        }

        session.close();
        return admList;
    }

    public AdmissionDetailsPopUpPojo editAdmissionDetails(Integer id)
    {
        AdmissionDetailsPopUpPojo admPojo = null;
        List list = hibernatetemplate.find("select adm.admissionCode,adm.admissionDate,adm.admissionTime,adm.age,adm.status,adm.type,adm.admittingConsultant,adm.ward,adm.admissionClass,adm.admissionDiagnosis,adm.suggestedTreatment,adm.suggestedOpr,adm.specialNotesOrRemarks,adm.pid,adm.name,adm.id,bed.patientId,bed.startDate,bed.bedNo from AdmissionEntity adm join adm.bedEntity bed where adm.id=?", id);
        BedEntity bedEntity;
        for(Iterator iterator = list.iterator(); iterator.hasNext(); admPojo.setBed(bedEntity))
        {
            Object objects[] = (Object[])iterator.next();
            String acode = (String)objects[0];
            Date admDate = (Date)objects[1];
            String atime = (String)objects[2];
            String age = (String)objects[3];
            StatusMetaEntity status = (StatusMetaEntity)objects[4];
            OperationTypeMetaEntity type = (OperationTypeMetaEntity)objects[5];
            AdmittingConsultantMetaEntity acon = (AdmittingConsultantMetaEntity)objects[6];
            WardMetaEntity ward = (WardMetaEntity)objects[7];
            ClassMetaEntity aclass = (ClassMetaEntity)objects[8];
            String adig = (String)objects[9];
            String sugtrea = (String)objects[10];
            String sugopr = (String)objects[11];
            String snorre = (String)objects[12];
            String pid = (String)objects[13];
            String name = (String)objects[14];
            Integer aid = (Integer)objects[15];
            String bpaid = (String)objects[16];
            Date bedsDate = (Date)objects[17];
            BedMetaEntity bid = (BedMetaEntity)objects[18];
            admPojo = new AdmissionDetailsPopUpPojo();
            AdmissionEntity admEntity = new AdmissionEntity();
            admEntity.setAdmissionCode(acode);
            admEntity.setAdmissionDate(admDate);
            admEntity.setAdmissionTime(atime);
            admEntity.setAge(age);
            admEntity.setStatus(status);
            admEntity.setType(type);
            admEntity.setAdmittingConsultant(acon);
            admEntity.setWard(ward);
            admEntity.setAdmissionClass(aclass);
            admEntity.setAdmissionDiagnosis(adig);
            admEntity.setSuggestedTreatment(sugtrea);
            admEntity.setSuggestedOpr(sugopr);
            admEntity.setSpecialNotesOrRemarks(snorre);
            admEntity.setPid(pid);
            admEntity.setName(name);
            admEntity.setId(aid);
            bedEntity = new BedEntity();
            bedEntity.setPatientId(bpaid);
            bedEntity.setStartDate(bedsDate);
            bedEntity.setBedNo(bid);
            admPojo.setAdmission(admEntity);
        }

        return admPojo;
    }

    public List admissionDetails(CommonSearchPojo commonsearchpojo)
    {
        List list = hibernatetemplate.find("select adm.admissionCode,adm.admissionDate,adm.age,s.desc,o.desc,ac.desc,c.desc,adm.pid,adm.name,adm.id from AdmissionEntity adm join adm.status s join adm.type o join adm.admittingConsultant ac join adm.admissionClass c ");
        List admPojoList = new ArrayList();
        AdmissionSearchPojo admPojo;
        for(Iterator iterator = list.iterator(); iterator.hasNext(); admPojoList.add(admPojo))
        {
            Object objects[] = (Object[])iterator.next();
            String acode = (String)objects[0];
            Date admDate = (Date)objects[1];
            String age = (String)objects[2];
            String status = (String)objects[3];
            String type = (String)objects[4];
            String acon = (String)objects[5];
            String aclass = (String)objects[6];
            String pid = (String)objects[7];
            String name = (String)objects[8];
            Integer aid = (Integer)objects[9];
            admPojo = new AdmissionSearchPojo();
            admPojo.setAdmissionCode(acode);
            admPojo.setAdmissionDate(admDate);
            admPojo.setYears(age);
            admPojo.setStatus(status);
            admPojo.setType(type);
            admPojo.setDoctorName(acon);
            admPojo.setClasstype(aclass);
            admPojo.setPatientId(pid);
            admPojo.setPatientName(name);
            admPojo.setClasstype(aclass);
            admPojo.setId(aid);
        }

        return admPojoList;
    }

    public List searchPatient(CommonSearchPojo commonSearchPojo)
    {
        List list = hibernatetemplate.find("select pt.id, pe.fname,pe.dob,ge.desc,pt.regisdate,ct.desc,oc.desc from PatientEntity pt join pt.personEntity pe join pe.gender ge join pe.addressEntity ad join ad.city ct join pt.occupation oc");
        List plist = new ArrayList();
        AdmissionPatientSearchPojo apatientSearchPojo;
        for(Iterator iterator = list.iterator(); iterator.hasNext(); plist.add(apatientSearchPojo))
        {
            Object objects[] = (Object[])iterator.next();
            Integer id = (Integer)objects[0];
            String pname = (String)objects[1];
            Date age = (Date)objects[2];
            String gender = (String)objects[3];
            Date registrationDate = (Date)objects[4];
            String city = (String)objects[5];
            String occupation = (String)objects[6];
            apatientSearchPojo = new AdmissionPatientSearchPojo();
            apatientSearchPojo.setId(id);
            apatientSearchPojo.setPatientName(pname);
            apatientSearchPojo.setAge(age);
            apatientSearchPojo.setGender(gender);
            apatientSearchPojo.setRegistrationDate(registrationDate);
            apatientSearchPojo.setCity(city);
            apatientSearchPojo.setOccupation(occupation);
        }

        return plist;
    }

    public List searchPatients(CommonSearchPojo commonSearchPojo)
    {
        SessionFactory sf = hibernatetemplate.getSessionFactory();
        Session s = sf.openSession();
        Criteria ctr = s.createCriteria("com/aqaa/com/entity/PatientEntity", "pt");
        ctr.createAlias("pt.personEntity", "pe");
        ctr.createAlias("pe.gender", "ge");
        ctr.createAlias("pe.addressEntity", "ad");
        ctr.createAlias("ad.city", "ct");
        ctr.createAlias("pt.occupation", "oc");
        if(commonSearchPojo.getPeriod() != null && !commonSearchPojo.getPeriod().equals(""))
        {
            List dateList = PeriodCommonLogic.getPeriodDeatils(commonSearchPojo.getPeriod());
            if(dateList.size() == 2)
                ctr.add(Restrictions.between("pt.regisdate", dateList.get(0), dateList.get(1)));
            else
                ctr.add(Restrictions.eq("pt.regisdat", dateList.get(0)));
        }
        if(commonSearchPojo.getSearch() != null && !commonSearchPojo.getSearch().equals(""))
            if(commonSearchPojo.getSearch().intValue() == 1)
                ctr.add(Restrictions.eq("pe.fname", commonSearchPojo.getValue()));
            else
            if(commonSearchPojo.getSearch().intValue() == 2)
                ctr.add(Restrictions.eq("pe.dob", commonSearchPojo.getValue()));
            else
            if(commonSearchPojo.getSearch().intValue() == 3)
            {
                System.out.println((new StringBuilder("The admit date is::::::::::::::::::::: ")).append(commonSearchPojo.getValue()).toString());
                ctr.add(Restrictions.eq("ge.desc", commonSearchPojo.getValue()));
            } else
            if(commonSearchPojo.getSearch().intValue() == 4)
                ctr.add(Restrictions.eq("pt.regisdate", commonSearchPojo.getValue()));
            else
            if(commonSearchPojo.getSearch().intValue() == 5)
                ctr.add(Restrictions.eq("ct.desc", commonSearchPojo.getValue()));
            else
            if(commonSearchPojo.getSearch().intValue() == 5)
                ctr.add(Restrictions.eq("oc.desc", commonSearchPojo.getValue()));
        ProjectionList prlist = Projections.projectionList();
        prlist.add(Projections.property("pt.id"));
        prlist.add(Projections.property("pe.fname"));
        prlist.add(Projections.property("pe.dob"));
        prlist.add(Projections.property("ge.desc"));
        prlist.add(Projections.property("pt.regisdate"));
        prlist.add(Projections.property("ct.desc"));
        prlist.add(Projections.property("oc.desc"));
        ctr.setProjection(prlist);
        List list = ctr.list();
        List plist = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            PatientSearchPojo patientSearchPojo = new PatientSearchPojo();
            Integer id = (Integer)((Object[])list.get(i))[0];
            String pname = (String)((Object[])list.get(i))[1];
            Date dob = (Date)((Object[])list.get(i))[2];
            int age = AgeCalculation.getPersonAge(dob);
            String gender = (String)((Object[])list.get(i))[3];
            String registrationDate = (String)((Object[])list.get(i))[4];
            java.sql.Date sql = null;
            try
            {
                SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
                Date parsed = format.parse(registrationDate);
                sql = new java.sql.Date(parsed.getTime());
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            String city = (String)((Object[])list.get(i))[5];
            String occupation = (String)((Object[])list.get(i))[6];
            patientSearchPojo.setId(id);
            patientSearchPojo.setPatientName(pname);
            patientSearchPojo.setAge(age);
            patientSearchPojo.setGender(gender);
            patientSearchPojo.setRegistrationDate(sql);
            patientSearchPojo.setCity(city);
            patientSearchPojo.setOccupation(occupation);
            plist.add(patientSearchPojo);
        }

        s.close();
        return plist;
    }

    public List patientValuesdisplay()
    {
        return hibernatetemplate.find("from PatientSearchMetaEntity");
    }

    private HibernateTemplate hibernatetemplate;
}
