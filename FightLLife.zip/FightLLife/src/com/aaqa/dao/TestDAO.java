// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TestDAO.java

package com.aaqa.dao;

import com.aaqa.pojo.*;
import com.aqaa.com.entity.*;
import com.aqaa.util.AgeCalculation;
import com.aqaa.util.PeriodCommonLogic;
import java.io.PrintStream;
import java.util.*;
import org.apache.log4j.Logger;
import org.hibernate.*;
import org.hibernate.criterion.*;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class TestDAO
{

    public TestDAO()
    {
        logger = Logger.getLogger("com/aaqa/dao/TestDAO");
    }

    public void setHibernatetemplate(HibernateTemplate hibernatetemplate)
    {
        this.hibernatetemplate = hibernatetemplate;
    }

    public void saveTestDetails(Test_TestDetails_Pojo testdetailspojo)
    {
        hibernatetemplate.saveOrUpdate(testdetailspojo);
    }

    public List getPatientDetailForTest()
    {
        String hql = "select pt.id, pe.fname, ct.phoneNo from PatientEntity pt join pt.personEntity pe join pe.contactEntities ct";
        List list = hibernatetemplate.find(hql);
        List plist = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            SelectPatientPojo selectPatientPojo = new SelectPatientPojo();
            Integer id = (Integer)((Object[])list.get(i))[0];
            String name = (String)((Object[])list.get(i))[1];
            String phoneNo = (String)((Object[])list.get(i))[2];
            selectPatientPojo.setId(id);
            selectPatientPojo.setName(name);
            selectPatientPojo.setPhoneNo(phoneNo);
            plist.add(selectPatientPojo);
        }

        return plist;
    }

    public List getTestDetails()
    {
        String hql = "select te.date, pe.fname, te.testEntity, pe.gender, pe.dob, te.id from PatientEntity pt join pt.personEntity pe join pt.testDetailsPojo te";
        List list = hibernatetemplate.find(hql);
        List tlist = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            TestSearchPojo testSearchPojo = new TestSearchPojo();
            Date date = (Date)((Object[])list.get(i))[0];
            String pname = (String)((Object[])list.get(i))[1];
            TestEntity tname = (TestEntity)((Object[])list.get(i))[2];
            GenderMetaEntity gender = (GenderMetaEntity)((Object[])list.get(i))[3];
            Date dateob = (Date)((Object[])list.get(i))[4];
            String pAge = (new StringBuilder(String.valueOf(AgeCalculation.getPersonAge(dateob)))).toString();
            logger.debug((new StringBuilder("The timestamp value in DAO is::")).append(((Object[])list.get(i))[4]).toString());
            Integer id = (Integer)((Object[])list.get(i))[5];
            testSearchPojo.setTestDate(date);
            testSearchPojo.setPatientName(pname);
            testSearchPojo.setTestName(tname.getDesc());
            testSearchPojo.setGender(gender.getDesc());
            testSearchPojo.setAge(pAge);
            testSearchPojo.setId(id);
            tlist.add(testSearchPojo);
        }

        return tlist;
    }

    public List getPatientName()
    {
        String hql = "select pt.id, pe.fname from PatientEntity pt join pt.personEntity pe join pt.testDetailsPojo te";
        List list = hibernatetemplate.find(hql);
        List plist = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            PersonEntity personEntity = new PersonEntity();
            Integer id = (Integer)((Object[])list.get(i))[0];
            String name = (String)((Object[])list.get(i))[1];
            personEntity.setId(id);
            personEntity.setFname(name);
            plist.add(personEntity);
        }

        return plist;
    }

    public List getTestName()
    {
        String hql = "from TestEntity";
        List testList = hibernatetemplate.find(hql);
        return testList;
    }

    public List searchPatientTest(CommonSearchPojo commonSearchPojo)
    {
        SessionFactory sf = hibernatetemplate.getSessionFactory();
        Session s = sf.openSession();
        Criteria ctr = s.createCriteria("com/aqaa/com/entity/PatientEntity", "pt");
        System.out.println("dao test");
        ctr.createAlias("pt.personEntity", "pe");
        ctr.createAlias("pt.testDetailsPojo", "tp");
        ctr.createAlias("tp.testEntity", "te");
        ctr.createAlias("pe.gender", "g");
        if(commonSearchPojo.getPeriod() != null && !commonSearchPojo.getPeriod().equals(""))
        {
            List dateList = PeriodCommonLogic.getPeriodDeatils(commonSearchPojo.getPeriod());
            if(dateList.size() == 2)
                ctr.add(Restrictions.between("tp.date", dateList.get(0), dateList.get(1)));
            else
                ctr.add(Restrictions.eq("tp.date", dateList.get(0)));
        }
        if(commonSearchPojo.getSearch() != null && !commonSearchPojo.getSearch().equals(""))
            ctr.add(Restrictions.eq("pt.id", commonSearchPojo.getSearch()));
        if(commonSearchPojo.getSearch1() != null && !commonSearchPojo.getSearch1().equals(""))
            ctr.add(Restrictions.eq("te.id", commonSearchPojo.getSearch1()));
        ProjectionList plist = Projections.projectionList();
        plist.add(Projections.property("tp.date"));
        plist.add(Projections.property("pe.fname"));
        plist.add(Projections.property("te.desc"));
        plist.add(Projections.property("g.desc"));
        plist.add(Projections.property("pe.dob"));
        plist.add(Projections.property("te.id"));
        ctr.setProjection(plist);
        List list = ctr.list();
        List tlist = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            TestSearchPojo testSearchPojo = new TestSearchPojo();
            Date date = (Date)((Object[])list.get(i))[0];
            String pname = (String)((Object[])list.get(i))[1];
            String tname = (String)((Object[])list.get(i))[2];
            String gender = (String)((Object[])list.get(i))[3];
            Date dateob = (Date)((Object[])list.get(i))[4];
            String dob = (new StringBuilder(String.valueOf(AgeCalculation.getPersonAge(dateob)))).toString();
            Integer id = (Integer)((Object[])list.get(i))[5];
            testSearchPojo.setTestDate(date);
            testSearchPojo.setPatientName(pname);
            testSearchPojo.setTestName(tname);
            testSearchPojo.setGender(gender);
            testSearchPojo.setAge(dob);
            testSearchPojo.setId(id);
            tlist.add(testSearchPojo);
        }

        System.out.println(tlist);
        s.close();
        return tlist;
    }

    public Test_TestDetails_Pojo getTestDetailsForUpdate(Integer id1)
    {
        logger.fatal("From DAO getTestDetailsForUpdate");
        Test_TestDetails_Pojo testDetailsPojo = new Test_TestDetails_Pojo();
        String hql = "select pt.id, pe.fname, te.date,te.observations,te.title, te.conclusion, te.remarks, t  from Test_TestDetails_Pojo te join te.patientEntity pt join pt.personEntity pe join te.testEntity t where te.id=?";
        List list = hibernatetemplate.find(hql, id1);
        for(int i = 0; i < list.size(); i++)
        {
            Integer id = (Integer)((Object[])list.get(i))[0];
            String pname = (String)((Object[])list.get(i))[1];
            Date date = (Date)((Object[])list.get(i))[2];
            String observations = (String)((Object[])list.get(i))[3];
            String title = (String)((Object[])list.get(i))[4];
            String conclusion = (String)((Object[])list.get(i))[5];
            String remarks = (String)((Object[])list.get(i))[6];
            TestEntity testEntity = (TestEntity)((Object[])list.get(i))[7];
            PatientEntity patientEntity = new PatientEntity();
            patientEntity.setId(id);
            testDetailsPojo.setPatientEntity(patientEntity);
            testDetailsPojo.setFname(pname);
            logger.fatal((new StringBuilder("From DAO getTestDetailsForUpdate the Date is::")).append(date).toString());
            testDetailsPojo.setDate(date);
            testDetailsPojo.setObservations(observations);
            testDetailsPojo.setTitle(title);
            testDetailsPojo.setConclusion(conclusion);
            testDetailsPojo.setRemarks(remarks);
            testDetailsPojo.setTestEntity(testEntity);
            System.out.println(testEntity.getId());
            testDetailsPojo.setTestid(id1);
        }

        return testDetailsPojo;
    }

    Logger logger;
    private HibernateTemplate hibernatetemplate;
}
