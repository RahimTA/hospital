// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PatientDAO.java

package com.aaqa.dao;

import com.aaqa.pojo.*;
import com.aqaa.com.entity.*;
import com.aqaa.util.AgeCalculation;
import com.aqaa.util.PeriodCommonLogic;
import java.io.PrintStream;
import java.util.*;
import org.apache.log4j.Logger;
import org.hibernate.*;
import org.hibernate.criterion.*;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class PatientDAO
{

    public PatientDAO()
    {
        logger = Logger.getLogger("com/aaqa/dao/PatientDAO");
    }

    public void setHibernatetemplate(HibernateTemplate hibernatetemplate)
    {
        this.hibernatetemplate = hibernatetemplate;
    }

    public List getMetaDetails(String metaName)
    {
        System.out.println((new StringBuilder("Hibernate Template obj is: ")).append(hibernatetemplate).toString());
        List list = hibernatetemplate.find((new StringBuilder("from ")).append(metaName).toString());
        return list;
    }

    public void saveDetails(PatientInfoPojo patientInfoPojo)
    {
        AddressEntity addressEntity = patientInfoPojo.getAddress();
        PatientEntity patientEntity = patientInfoPojo.getPatient();
        PersonEntity personEntity = patientInfoPojo.getPerson();
        ContactEntity contactEntity = patientInfoPojo.getContact();
        List alergiesList = new ArrayList();
        String alergies[] = patientInfoPojo.getAlergies();
        for(int i = 0; i < alergies.length; i++)
        {
            AlergyMetaEntity ame = new AlergyMetaEntity();
            ame.setId(Integer.valueOf(Integer.parseInt(alergies[i])));
            alergiesList.add(ame);
        }

        patientEntity.setAllergyMeta(alergiesList);
        List alist = new ArrayList();
        alist.add(addressEntity);
        personEntity.setAddressEntity(alist);
        personEntity.setContact(contactEntity);
        personEntity.setPatientEntity(patientEntity);
        patientEntity.setPersonEntity(personEntity);
        addressEntity.setPersonEntity(personEntity);
        contactEntity.setPersonEntity(personEntity);
        hibernatetemplate.saveOrUpdate(patientEntity);
    }

    public List getPatientName()
    {
        String hql = "select pt.id, pe.fname from PatientEntity pt join pt.personEntity pe ";
        List list = hibernatetemplate.find(hql);
        List plist = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            PersonEntity personEntity = new PersonEntity();
            Integer id = (Integer)((Object[])list.get(i))[0];
            String name = (String)((Object[])list.get(i))[1];
            personEntity.setId(id);
            personEntity.setFname(name);
            plist.add(personEntity);
        }

        return plist;
    }

    public List patientValuesdisplay()
    {
        return hibernatetemplate.find("from PatientSearchMetaEntity");
    }

    public List searchPatient(CommonSearchPojo commonSearchPojo)
    {
        System.out.println("********************************** Filter controleer  **********************************");
        SessionFactory sf = hibernatetemplate.getSessionFactory();
        Session s = sf.openSession();
        Criteria ctr = s.createCriteria("com/aqaa/com/entity/PatientEntity", "pt");
        System.out.println("dao test");
        ctr.createAlias("pt.personEntity", "pe");
        ctr.createAlias("pe.gender", "ge");
        ctr.createAlias("pe.addressEntity", "ad");
        ctr.createAlias("ad.city", "ct");
        ctr.createAlias("pt.occupation", "oc");
        if(commonSearchPojo.getPeriod() != null && !commonSearchPojo.getPeriod().equals(""))
        {
            List dateList = PeriodCommonLogic.getPeriodDeatils(commonSearchPojo.getPeriod());
            if(dateList.size() == 2)
                ctr.add(Restrictions.between("pt.regisdate", dateList.get(0), dateList.get(1)));
            else
                ctr.add(Restrictions.eq("pt.regisdate", dateList.get(0)));
        }
        if(commonSearchPojo.getSearch() != null && !commonSearchPojo.getSearch().equals(""))
            if(commonSearchPojo.getSearch().intValue() == 1)
                ctr.add(Restrictions.eq("pe.fname", commonSearchPojo.getValue()));
            else
            if(commonSearchPojo.getSearch().intValue() == 2)
                ctr.add(Restrictions.eq("pe.dob", commonSearchPojo.getValue()));
            else
            if(commonSearchPojo.getSearch().intValue() == 3)
                ctr.add(Restrictions.eq("ge.desc", commonSearchPojo.getValue()));
            else
            if(commonSearchPojo.getSearch().intValue() == 4)
                ctr.add(Restrictions.eq("pt.regisdate", commonSearchPojo.getValue()));
            else
            if(commonSearchPojo.getSearch().intValue() == 5)
                ctr.add(Restrictions.eq("ct.desc", commonSearchPojo.getValue()));
            else
            if(commonSearchPojo.getSearch().intValue() == 5)
                ctr.add(Restrictions.eq("oc.desc", commonSearchPojo.getValue()));
        ProjectionList prlist = Projections.projectionList();
        prlist.add(Projections.property("pt.id"));
        prlist.add(Projections.property("pe.fname"));
        prlist.add(Projections.property("pe.dob"));
        prlist.add(Projections.property("ge.desc"));
        prlist.add(Projections.property("pt.regisdate"));
        prlist.add(Projections.property("ct.desc"));
        prlist.add(Projections.property("oc.desc"));
        ctr.setProjection(prlist);
        List list = ctr.list();
        List plist = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            PatientSearchPojo patientSearchPojo = new PatientSearchPojo();
            Integer id = (Integer)((Object[])list.get(i))[0];
            String pname = (String)((Object[])list.get(i))[1];
            Date dob = (Date)((Object[])list.get(i))[2];
            int age = AgeCalculation.getPersonAge(dob);
            String gender = (String)((Object[])list.get(i))[3];
            Date registrationDate = (Date)((Object[])list.get(i))[4];
            String city = (String)((Object[])list.get(i))[5];
            String occupation = (String)((Object[])list.get(i))[6];
            patientSearchPojo.setId(id);
            patientSearchPojo.setPatientName(pname);
            patientSearchPojo.setAge(age);
            patientSearchPojo.setGender(gender);
            patientSearchPojo.setRegistrationDate(registrationDate);
            patientSearchPojo.setCity(city);
            patientSearchPojo.setOccupation(occupation);
            plist.add(patientSearchPojo);
        }

        s.close();
        return plist;
    }

    public PatientInfoPojo editPatientDetails(Integer id)
    {
        PatientInfoPojo ppojo = null;
        List list = hibernatetemplate.find("select pt.id,pt.code,pt.regisdate,pe.fname,pe.sname,pe.lname,pe.dob,t,bl,ms,ge,fis,cas,oc,ad.add1,ad.add2,ad.add3,city,st,cou,dis,ct.phoneNo,ct.altPhoneNo,ct.landLine,ct.email,ct.fax,ct.website from PatientEntity pt join pt.personEntity pe join  pe.bloodGroup bl  join pe.mstatus ms join pe.gender ge  join  pe.contactEntities ct  join pe.addressEntity ad  join pe.title t  join pt.allergyMeta am  join pt.finstatus fis  join pt.castcat cas  join pt.occupation oc join ad.city city join ad.state st  join ad.country cou  join ad.district dis where pt.id=?", id);
        ContactEntity contactEntity;
        for(Iterator iterator = list.iterator(); iterator.hasNext(); ppojo.setContact(contactEntity))
        {
            Object objects[] = (Object[])iterator.next();
            Integer ptId = (Integer)objects[0];
            String code = (String)objects[1];
            Date regisdate = (Date)objects[2];
            String fname = (String)objects[3];
            String sname = (String)objects[4];
            String lname = (String)objects[5];
            Date dob = (Date)objects[6];
            TitleMetaEntity title = (TitleMetaEntity)objects[7];
            BloodGroupMetaEntity bgroup = (BloodGroupMetaEntity)objects[8];
            MstatusMetaEntity mstatus = (MstatusMetaEntity)objects[9];
            GenderMetaEntity gender = (GenderMetaEntity)objects[10];
            FinstatusMetaEntity fstatus = (FinstatusMetaEntity)objects[11];
            CastcatMeta cast = (CastcatMeta)objects[12];
            OcupationMeta ocupation = (OcupationMeta)objects[13];
            String add1 = (String)objects[14];
            String add2 = (String)objects[15];
            String add3 = (String)objects[16];
            CityMetaEntity city = (CityMetaEntity)objects[17];
            StateMetaEntity state = (StateMetaEntity)objects[18];
            CountryMetaEntity country = (CountryMetaEntity)objects[19];
            DistrictMetaEntity district = (DistrictMetaEntity)objects[20];
            String phoneNo = (String)objects[21];
            String altPhoneNo = (String)objects[22];
            String landLine = (String)objects[23];
            String email = (String)objects[24];
            String fax = (String)objects[25];
            String website = (String)objects[26];
            ppojo = new PatientInfoPojo();
            PatientEntity patient = new PatientEntity();
            patient.setId(ptId);
            patient.setCode(code);
            patient.setRegisdate(regisdate);
            patient.setFinstatus(fstatus);
            patient.setCastcat(cast);
            patient.setOccupation(ocupation);
            PersonEntity person = new PersonEntity();
            person.setDob(dob);
            person.setFname(fname);
            person.setLname(lname);
            person.setSname(sname);
            person.setTitle(title);
            person.setBloodGroup(bgroup);
            person.setMstatus(mstatus);
            person.setGender(gender);
            AddressEntity addressEntity = new AddressEntity();
            addressEntity.setAdd1(add1);
            addressEntity.setAdd2(add2);
            addressEntity.setAdd3(add3);
            addressEntity.setCity(city);
            addressEntity.setState(state);
            addressEntity.setCountry(country);
            addressEntity.setDistrict(district);
            contactEntity = new ContactEntity();
            contactEntity.setPhoneNo(phoneNo);
            contactEntity.setAltPhoneNo(altPhoneNo);
            contactEntity.setLandLine(landLine);
            contactEntity.setFax(fax);
            contactEntity.setEmail(email);
            contactEntity.setWebsite(website);
            List contactEntities = new ArrayList();
            contactEntities.add(contactEntity);
            contactEntity.setAltPhoneNo(altPhoneNo);
            contactEntity.setLandLine(landLine);
            contactEntity.setFax(fax);
            contactEntity.setEmail(email);
            contactEntity.setWebsite(website);
            System.out.println((new StringBuilder("C:")).append(contactEntity.getEmail()).toString());
            System.out.println((new StringBuilder("C")).append(contactEntity.getAltPhoneNo()).toString());
            person.setContactEntities(contactEntity);
            ppojo.setPatient(patient);
            ppojo.setPerson(person);
            ppojo.setAddress(addressEntity);
        }

        return ppojo;
    }

    Logger logger;
    private HibernateTemplate hibernatetemplate;
}
