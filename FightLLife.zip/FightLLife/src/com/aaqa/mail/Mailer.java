// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Mailer.java

package com.aaqa.mail;

import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;

public class Mailer
{

    public Mailer()
    {
    }

    public void setMailSender(MailSender mailSender)
    {
        this.mailSender = mailSender;
    }

    public void send(String from, String to, String sub, String message)
    {
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setFrom(from);
        msg.setTo(to);
        msg.setSubject(sub);
        msg.setText(message);
        mailSender.send(msg);
    }

    private MailSender mailSender;
}
