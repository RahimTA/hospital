// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AgeCalculation.java

package com.aqaa.util;

import java.util.Calendar;
import java.util.Date;
import org.apache.log4j.Logger;

public class AgeCalculation
{

    public AgeCalculation()
    {
    }

    public static int getPersonAge(Date dateob)
    {
        Calendar now = Calendar.getInstance();
        Calendar dob = Calendar.getInstance();
        dob.setTime(dateob);
        int year1 = now.get(1);
        int year2 = dob.get(1);
        int age = year1 - year2;
        logger.info((new StringBuilder("After comparing Years the Age is::")).append(age).toString());
        int month1 = now.get(2);
        int month2 = dob.get(2);
        if(month2 > month1)
            age--;
        else
        if(month1 == month2)
        {
            int day1 = now.get(5);
            int day2 = dob.get(5);
            if(day2 > day1)
                age--;
        }
        return age;
    }

    static Logger logger = Logger.getLogger("com/aqaa/util/AgeCalculation");

}
