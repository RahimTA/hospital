// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DoctorEntity.java

package com.aqaa.com.entity;

import com.aaqa.pojo.OperativeNotesPojo;
import java.util.List;

// Referenced classes of package com.aqaa.com.entity:
//            PersonEntity, ShiftMetaEntity

public class DoctorEntity
{

    public DoctorEntity()
    {
    }

    public List getPatientEntity()
    {
        return patientEntity;
    }

    public void setPatientEntity(List patientEntity)
    {
        this.patientEntity = patientEntity;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public PersonEntity getPerson()
    {
        return person;
    }

    public void setPerson(PersonEntity person)
    {
        this.person = person;
    }

    public ShiftMetaEntity getShiftMetaEntity()
    {
        return shiftMetaEntity;
    }

    public void setShiftMetaEntity(ShiftMetaEntity shiftMetaEntity)
    {
        this.shiftMetaEntity = shiftMetaEntity;
    }

    public List getAppointmentEntity()
    {
        return appointmentEntity;
    }

    public void setAppointmentEntity(List appointmentEntity)
    {
        this.appointmentEntity = appointmentEntity;
    }

    public OperativeNotesPojo getOperativeNotesPojo()
    {
        return operativeNotesPojo;
    }

    public void setOperativeNotesPojo(OperativeNotesPojo operativeNotesPojo)
    {
        this.operativeNotesPojo = operativeNotesPojo;
    }

    public List getVisitEntity()
    {
        return visitEntity;
    }

    public void setVisitEntity(List visitEntity)
    {
        this.visitEntity = visitEntity;
    }

    private Integer id;
    private PersonEntity person;
    private ShiftMetaEntity shiftMetaEntity;
    private List appointmentEntity;
    private List patientEntity;
    private OperativeNotesPojo operativeNotesPojo;
    private List visitEntity;
}
