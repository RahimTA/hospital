// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AlergyMetaEntity.java

package com.aqaa.com.entity;

import com.aqaa.interfaces.intr.MetaDataInterfaces;
import java.util.List;

public class AlergyMetaEntity
    implements MetaDataInterfaces
{

    public AlergyMetaEntity()
    {
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Integer getCode()
    {
        return code;
    }

    public void setCode(Integer code)
    {
        this.code = code;
    }

    public String getDesc()
    {
        return desc;
    }

    public void setDesc(String desc)
    {
        this.desc = desc;
    }

    public List getPatientEntity()
    {
        return patientEntity;
    }

    public void setPatientEntity(List patientEntity)
    {
        this.patientEntity = patientEntity;
    }

    private Integer id;
    private Integer code;
    private String desc;
    private List patientEntity;
}
