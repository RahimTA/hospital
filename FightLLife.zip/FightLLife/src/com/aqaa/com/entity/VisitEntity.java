// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   VisitEntity.java

package com.aqaa.com.entity;

import java.util.Date;

// Referenced classes of package com.aqaa.com.entity:
//            PatientEntity, MedicationEntity, VisitTypeMetaEntity, DoctorEntity

public class VisitEntity
{

    public VisitEntity()
    {
        patientId = new PatientEntity();
        medicationEntity = new MedicationEntity();
        visitType = new VisitTypeMetaEntity();
        dtrpeid = new DoctorEntity();
    }

    public MedicationEntity getMedicationEntity()
    {
        return medicationEntity;
    }

    public void setMedicationEntity(MedicationEntity medicationEntity)
    {
        this.medicationEntity = medicationEntity;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public String getPatientName()
    {
        return patientName;
    }

    public void setPatientName(String patientName)
    {
        this.patientName = patientName;
    }

    public PatientEntity getPatientId()
    {
        return patientId;
    }

    void setPatientId(PatientEntity patientId)
    {
        this.patientId = patientId;
    }

    public Date getDate()
    {
        return date;
    }

    public void setDate(Date date)
    {
        this.date = date;
    }

    public Date getTime()
    {
        return time;
    }

    public void setTime(Date time)
    {
        this.time = time;
    }

    public DoctorEntity getDtrpeid()
    {
        return dtrpeid;
    }

    public void setDtrpeid(DoctorEntity dtrpeid)
    {
        this.dtrpeid = dtrpeid;
    }

    public Integer getBp()
    {
        return bp;
    }

    public void setBp(Integer bp)
    {
        this.bp = bp;
    }

    public String getBpremarks()
    {
        return bpremarks;
    }

    public void setBpremarks(String bpremarks)
    {
        this.bpremarks = bpremarks;
    }

    public Integer getTemp()
    {
        return temp;
    }

    public void setTemp(Integer temp)
    {
        this.temp = temp;
    }

    public Integer getWeight()
    {
        return weight;
    }

    public void setWeight(Integer weight)
    {
        this.weight = weight;
    }

    public Integer getPulse()
    {
        return pulse;
    }

    public void setPulse(Integer pulse)
    {
        this.pulse = pulse;
    }

    public String getPulseRemarks()
    {
        return pulseRemarks;
    }

    public void setPulseRemarks(String pulseRemarks)
    {
        this.pulseRemarks = pulseRemarks;
    }

    public String getResp()
    {
        return resp;
    }

    public void setResp(String resp)
    {
        this.resp = resp;
    }

    public Integer getHeight()
    {
        return height;
    }

    public void setHeight(Integer height)
    {
        this.height = height;
    }

    public Integer getWaist()
    {
        return waist;
    }

    public void setWaist(Integer waist)
    {
        this.waist = waist;
    }

    public Integer getHip()
    {
        return hip;
    }

    public void setHip(Integer hip)
    {
        this.hip = hip;
    }

    public VisitTypeMetaEntity getVisitType()
    {
        return visitType;
    }

    public void setVisitType(VisitTypeMetaEntity visitType)
    {
        this.visitType = visitType;
    }

    private Integer id;
    private PatientEntity patientId;
    private MedicationEntity medicationEntity;
    private String patientName;
    private Date date;
    private Date time;
    private Integer bp;
    private String bpremarks;
    private Integer temp;
    private Integer weight;
    private Integer pulse;
    private String pulseRemarks;
    private String resp;
    private Integer height;
    private Integer waist;
    private Integer hip;
    private VisitTypeMetaEntity visitType;
    private DoctorEntity dtrpeid;
}
