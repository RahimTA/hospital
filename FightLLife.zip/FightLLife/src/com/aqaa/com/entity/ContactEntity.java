// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ContactEntity.java

package com.aqaa.com.entity;


// Referenced classes of package com.aqaa.com.entity:
//            PersonEntity

public class ContactEntity
{

    public ContactEntity()
    {
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public String getPhoneNo()
    {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo)
    {
        this.phoneNo = phoneNo;
    }

    public String getAltPhoneNo()
    {
        return altPhoneNo;
    }

    public void setAltPhoneNo(String altPhoneNo)
    {
        this.altPhoneNo = altPhoneNo;
    }

    public String getLandLine()
    {
        return landLine;
    }

    public void setLandLine(String landLine)
    {
        this.landLine = landLine;
    }

    public String getExt()
    {
        return ext;
    }

    public void setExt(String ext)
    {
        this.ext = ext;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getFax()
    {
        return fax;
    }

    public void setFax(String fax)
    {
        this.fax = fax;
    }

    public String getWebsite()
    {
        return website;
    }

    public void setWebsite(String website)
    {
        this.website = website;
    }

    public PersonEntity getPersonEntity()
    {
        return personEntity;
    }

    public void setPersonEntity(PersonEntity personEntity)
    {
        this.personEntity = personEntity;
    }

    private Integer id;
    private String phoneNo;
    private String altPhoneNo;
    private String landLine;
    private String ext;
    private String email;
    private String fax;
    private String website;
    private PersonEntity personEntity;
}
