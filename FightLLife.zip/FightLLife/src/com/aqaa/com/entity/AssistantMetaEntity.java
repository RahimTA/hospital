// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AssistantMetaEntity.java

package com.aqaa.com.entity;

import com.aqaa.interfaces.intr.MetaDataInterfaces;

public class AssistantMetaEntity
    implements MetaDataInterfaces
{

    public AssistantMetaEntity()
    {
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Integer getCode()
    {
        return code;
    }

    public void setCode(Integer code)
    {
        this.code = code;
    }

    public String getDesc()
    {
        return desc;
    }

    public void setDesc(String desc)
    {
        this.desc = desc;
    }

    private Integer id;
    private Integer code;
    private String desc;
}
