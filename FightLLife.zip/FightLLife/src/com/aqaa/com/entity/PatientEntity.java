// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PatientEntity.java

package com.aqaa.com.entity;

import com.aaqa.pojo.DischargeDetailsPopupPojo;
import com.ibm.icu.text.SimpleDateFormat;
import java.text.Format;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

// Referenced classes of package com.aqaa.com.entity:
//            FinstatusMetaEntity, CastcatMeta, OcupationMeta, PersonEntity, 
//            DoctorEntity, AppointmentEntity

public class PatientEntity
{

    public PatientEntity()
    {
    }

    public DoctorEntity getDoctorEntity()
    {
        return doctorEntity;
    }

    public void setDoctorEntity(DoctorEntity doctorEntity)
    {
        this.doctorEntity = doctorEntity;
    }

    public List getTestDetailsPojo()
    {
        return testDetailsPojo;
    }

    public void setTestDetailsPojo(List testDetailsPojo)
    {
        this.testDetailsPojo = testDetailsPojo;
    }

    public String getCode()
    {
        return code;
    }

    public void setCode(String code)
    {
        this.code = code;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public FinstatusMetaEntity getFinstatus()
    {
        return finstatus;
    }

    public void setFinstatus(FinstatusMetaEntity finstatus)
    {
        this.finstatus = finstatus;
    }

    public Date getRegisdate()
    {
        return regisdate;
    }

    public void setRegisdate(Date regisdate)
    {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/mm/dd");
        try
        {
            this.regisdate = formatter.parse(regisdatestr);
        }
        catch(ParseException e)
        {
            e.printStackTrace();
        }
        this.regisdate = regisdate;
    }

    public String getRegisdatestr()
    {
        Format formatter = new SimpleDateFormat("yyyy/mm/dd");
        if(regisdate == null || regisdate.equals(""))
        {
            return this.regisdatestr;
        } else
        {
            String regisdatestr = formatter.format(regisdate);
            return regisdatestr;
        }
    }

    public void setRegisdatestr(String regisdatestr)
    {
        this.regisdatestr = regisdatestr;
    }

    public CastcatMeta getCastcat()
    {
        return castcat;
    }

    public void setCastcat(CastcatMeta castcat)
    {
        this.castcat = castcat;
    }

    public OcupationMeta getOccupation()
    {
        return occupation;
    }

    public void setOccupation(OcupationMeta occupation)
    {
        this.occupation = occupation;
    }

    public List getAllergyMeta()
    {
        return allergyMeta;
    }

    public void setAllergyMeta(List allergyMeta)
    {
        this.allergyMeta = allergyMeta;
    }

    public PersonEntity getPersonEntity()
    {
        return personEntity;
    }

    public void setPersonEntity(PersonEntity personEntity)
    {
        this.personEntity = personEntity;
    }

    public DischargeDetailsPopupPojo getDischargeDetailsPopupPojo()
    {
        return dischargeDetailsPopupPojo;
    }

    public void setDischargeDetailsPopupPojo(DischargeDetailsPopupPojo dischargeDetailsPopupPojo)
    {
        this.dischargeDetailsPopupPojo = dischargeDetailsPopupPojo;
    }

    public AppointmentEntity getAppointmentEntity()
    {
        return appointmentEntity;
    }

    public void setAppointmentEntity(AppointmentEntity appointmentEntity)
    {
        this.appointmentEntity = appointmentEntity;
    }

    public List getVisitEntity()
    {
        return visitEntity;
    }

    void setVisitEntity(List visitEntity)
    {
        this.visitEntity = visitEntity;
    }

    private Integer id;
    private String code;
    private Date regisdate;
    private String regisdatestr;
    private FinstatusMetaEntity finstatus;
    private CastcatMeta castcat;
    private OcupationMeta occupation;
    private PersonEntity personEntity;
    private List allergyMeta;
    private DoctorEntity doctorEntity;
    private List testDetailsPojo;
    private AppointmentEntity appointmentEntity;
    private List visitEntity;
    private DischargeDetailsPopupPojo dischargeDetailsPopupPojo;
}
