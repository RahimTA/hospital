// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   VisitComplaintsEntity.java

package com.aqaa.com.entity;


public class VisitComplaintsEntity
{

    public VisitComplaintsEntity()
    {
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public String getPresentComplaints()
    {
        return presentComplaints;
    }

    public void setPresentComplaints(String presentComplaints)
    {
        this.presentComplaints = presentComplaints;
    }

    public String getPastMedicalHistory()
    {
        return pastMedicalHistory;
    }

    public void setPastMedicalHistory(String pastMedicalHistory)
    {
        this.pastMedicalHistory = pastMedicalHistory;
    }

    public String getTestAdvice()
    {
        return testAdvice;
    }

    public void setTestAdvice(String testAdvice)
    {
        this.testAdvice = testAdvice;
    }

    public String getLabInvestigation()
    {
        return labInvestigation;
    }

    public void setLabInvestigation(String labInvestigation)
    {
        this.labInvestigation = labInvestigation;
    }

    public String getFindingsExamonation()
    {
        return findingsExamonation;
    }

    public void setFindingsExamonation(String findingsExamonation)
    {
        this.findingsExamonation = findingsExamonation;
    }

    public String getTreatementAdvice()
    {
        return treatementAdvice;
    }

    public void setTreatementAdvice(String treatementAdvice)
    {
        this.treatementAdvice = treatementAdvice;
    }

    public String getDiagnosis()
    {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis)
    {
        this.diagnosis = diagnosis;
    }

    public String getOnTreatment()
    {
        return onTreatment;
    }

    public void setOnTreatment(String onTreatment)
    {
        this.onTreatment = onTreatment;
    }

    public String getRemarksSummary()
    {
        return remarksSummary;
    }

    public void setRemarksSummary(String remarksSummary)
    {
        this.remarksSummary = remarksSummary;
    }

    private Integer id;
    private String presentComplaints;
    private String pastMedicalHistory;
    private String testAdvice;
    private String labInvestigation;
    private String findingsExamonation;
    private String treatementAdvice;
    private String diagnosis;
    private String onTreatment;
    private String remarksSummary;
}
