 function forgotpassword(){
	   MM_openBrWindow("forgotpassword.html","ForgotPassword","status=yes,scrollbars=yes,resizable=yes,channelmode=yes,menubar=no,location=no");
 }
 function resetpassword(){
	var url="forgotpassword.html?result="+"reset";
	   MM_openBrWindow(url,"ResetPassword","status=yes,scrollbars=yes,resizable=yes,channelmode=yes,menubar=no,location=no");
 }
   function loginSDB()
   {
	   document.forms[0].action="login.html";
	   document.forms[0].submit();
   }
$(document).ready(function(){
	  $("#forgotpassword").click(function(){
		  forgotpassword();
	  });
	  $("#resetButton").click(function(){
		  resetpassword();
	  });
  $("#submit").click(function(){
	 
	  res=true;
	  var userInfo=$("#user").val();
	  var pwdInfo=$("#pwd").val();
	  var user= $("#user_error").val();
	   res= true;

	  if(userInfo==""||pwdInfo=="")
		  {
		  
		  $("#user_error").show();
		return res=false;
		  }
	  else if(userInfo!=""||pwdInfo!=""){
		  alert("ra"+userInfo);
		 $("#user_error").hide();
		 return res=true;
	  }
	 
  });
});