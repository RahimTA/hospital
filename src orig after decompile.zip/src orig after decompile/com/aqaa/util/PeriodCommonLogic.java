// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PeriodCommonLogic.java

package com.aqaa.util;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class PeriodCommonLogic
{

    public PeriodCommonLogic()
    {
    }

    public static List getPeriodDeatils(Integer periodId)
    {
        List dateList = new ArrayList();
        if(periodId.intValue() == 2 || periodId.intValue() == 5)
        {
            Date date = new Date();
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int i = c.get(7) - c.getFirstDayOfWeek();
            c.add(5, -i - 7);
            Date start = c.getTime();
            c.add(5, 6);
            Date end = c.getTime();
            c.add(5, 1);
            Date start1 = c.getTime();
            Date end1 = date;
            java.sql.Date sqlDate1 = new java.sql.Date(start.getTime());
            java.sql.Date sqlDate2 = new java.sql.Date(end.getTime());
            java.sql.Date sqlDate3 = new java.sql.Date(start1.getTime());
            java.sql.Date sqlDate4 = new java.sql.Date(end1.getTime());
            if(periodId.intValue() == 5)
            {
                dateList.add(sqlDate1);
                dateList.add(sqlDate2);
            } else
            if(periodId.intValue() == 2)
            {
                dateList.add(sqlDate3);
                dateList.add(sqlDate4);
            }
        } else
        if(periodId.intValue() == 3 || periodId.intValue() == 6)
        {
            Calendar cal = Calendar.getInstance();
            cal.add(2, -1);
            cal.set(5, 1);
            Date firstDateOfPreviousMonth = cal.getTime();
            cal.set(5, cal.getActualMaximum(5));
            Date lastDateOfPreviousMonth = cal.getTime();
            Calendar cal1 = Calendar.getInstance();
            cal1.add(2, 0);
            cal1.set(5, 1);
            Date firstDateOfPreviousMonth1 = cal1.getTime();
            cal1.set(5, cal1.getActualMaximum(5));
            Date lastDateOfPreviousMonth1 = cal1.getTime();
            java.sql.Date sqlDate1 = new java.sql.Date(firstDateOfPreviousMonth.getTime());
            java.sql.Date sqlDate2 = new java.sql.Date(lastDateOfPreviousMonth.getTime());
            java.sql.Date sqlDate3 = new java.sql.Date(firstDateOfPreviousMonth1.getTime());
            java.sql.Date sqlDate4 = new java.sql.Date(lastDateOfPreviousMonth1.getTime());
            if(periodId.intValue() == 6)
            {
                dateList.add(sqlDate1);
                dateList.add(sqlDate2);
            } else
            if(periodId.intValue() == 3)
            {
                dateList.add(sqlDate3);
                dateList.add(sqlDate4);
            }
        } else
        if(periodId.intValue() == 1)
        {
            Date date = new Date();
            java.sql.Date sqlDate1 = new java.sql.Date(date.getTime());
            dateList.add(sqlDate1);
        } else
        if(periodId.intValue() == 4)
        {
            Date date = new Date();
            java.sql.Date sqlDate2 = new java.sql.Date(date.getTime());
            Calendar cal = Calendar.getInstance();
            cal.set(2, 0);
            cal.set(5, 1);
            java.sql.Date sqlDate1 = new java.sql.Date(cal.getTime().getTime());
            dateList.add(sqlDate1);
            dateList.add(sqlDate2);
        }
        return dateList;
    }
}
