// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AppointmentEntity.java

package com.aqaa.com.entity;

import java.text.*;
import java.util.Date;

// Referenced classes of package com.aqaa.com.entity:
//            PatientEntity, DoctorEntity, AppointmentStatusMetaEntity, AppointmentForEntity

public class AppointmentEntity
{

    public AppointmentEntity()
    {
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public PatientEntity getPatientEntity()
    {
        return patientEntity;
    }

    public void setPatientEntity(PatientEntity patientEntity)
    {
        this.patientEntity = patientEntity;
    }

    public DoctorEntity getDoctorEntity()
    {
        return doctorEntity;
    }

    public void setDoctorEntity(DoctorEntity doctorEntity)
    {
        this.doctorEntity = doctorEntity;
    }

    public Date getDate()
    {
        return date;
    }

    public AppointmentStatusMetaEntity getAppointmentStatus()
    {
        return appointmentStatus;
    }

    public void setAppointmentStatus(AppointmentStatusMetaEntity appointmentStatus)
    {
        this.appointmentStatus = appointmentStatus;
    }

    public AppointmentForEntity getAppointmentForEntity()
    {
        return appointmentForEntity;
    }

    public void setAppointmentForEntity(AppointmentForEntity appointmentForEntity)
    {
        this.appointmentForEntity = appointmentForEntity;
    }

    public String getHours()
    {
        return hours;
    }

    public void setHours(String hours)
    {
        this.hours = hours;
    }

    public String getMinutes()
    {
        return minutes;
    }

    public void setMinutes(String minutes)
    {
        this.minutes = minutes;
    }

    public String getAmPm()
    {
        return amPm;
    }

    public void setAmPm(String amPm)
    {
        this.amPm = amPm;
    }

    public String getApptTime()
    {
        Format formatter = new SimpleDateFormat("HH:mm");
        if(date == null || date.equals(""))
        {
            return apptTime;
        } else
        {
            String appTime = formatter.format(date);
            return appTime;
        }
    }

    public void setApptTime(String apptTimeStr)
    {
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
        try
        {
            date = formatter.parse(apptTimeStr);
        }
        catch(ParseException e)
        {
            e.printStackTrace();
        }
        apptTime = apptTime;
    }

    public void setDate(Date date)
    {
        this.date = date;
    }

    public String getApptDateStr()
    {
        Format formatter = new SimpleDateFormat("yyyy/mm/dd");
        if(date == null || date.equals(""))
        {
            return this.apptDateStr;
        } else
        {
            String apptDateStr = formatter.format(date);
            return apptDateStr;
        }
    }

    public void setApptDateStr(String admitDateStr)
    {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/mm/dd");
        try
        {
            date = formatter.parse(admitDateStr);
        }
        catch(ParseException e)
        {
            e.printStackTrace();
        }
        apptDateStr = apptDateStr;
    }

    private Integer id;
    private PatientEntity patientEntity;
    private DoctorEntity doctorEntity;
    private Date date;
    private AppointmentStatusMetaEntity appointmentStatus;
    private AppointmentForEntity appointmentForEntity;
    private String hours;
    private String minutes;
    private String amPm;
    private String apptTime;
    private String apptDateStr;
}
