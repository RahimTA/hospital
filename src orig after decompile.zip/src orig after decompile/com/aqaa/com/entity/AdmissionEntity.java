// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AdmissionEntity.java

package com.aqaa.com.entity;

import java.text.*;
import java.util.Date;

// Referenced classes of package com.aqaa.com.entity:
//            StatusMetaEntity, OperationTypeMetaEntity, AdmittingConsultantMetaEntity, WardMetaEntity, 
//            ClassMetaEntity, BedEntity

public class AdmissionEntity
{

    public AdmissionEntity()
    {
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public BedEntity getBedEntity()
    {
        return bedEntity;
    }

    public void setBedEntity(BedEntity bedEntity)
    {
        this.bedEntity = bedEntity;
    }

    public String getPid()
    {
        return pid;
    }

    public void setPid(String pid)
    {
        this.pid = pid;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public String getAdmissionCode()
    {
        return admissionCode;
    }

    public void setAdmissionCode(String admissionCode)
    {
        this.admissionCode = admissionCode;
    }

    public Date getAdmissionDate()
    {
        return admissionDate;
    }

    public void setAdmissionDate(Date admissionDate)
    {
        this.admissionDate = admissionDate;
    }

    public String getAdmissionTime()
    {
        return admissionTime;
    }

    public void setAdmissionTime(String admissionTime)
    {
        this.admissionTime = admissionTime;
    }

    public String getAge()
    {
        return age;
    }

    public void setAge(String age)
    {
        this.age = age;
    }

    public StatusMetaEntity getStatus()
    {
        return status;
    }

    public void setStatus(StatusMetaEntity status)
    {
        this.status = status;
    }

    public OperationTypeMetaEntity getType()
    {
        return type;
    }

    public void setType(OperationTypeMetaEntity type)
    {
        this.type = type;
    }

    public AdmittingConsultantMetaEntity getAdmittingConsultant()
    {
        return admittingConsultant;
    }

    public void setAdmittingConsultant(AdmittingConsultantMetaEntity admittingConsultant)
    {
        this.admittingConsultant = admittingConsultant;
    }

    public WardMetaEntity getWard()
    {
        return ward;
    }

    public void setWard(WardMetaEntity ward)
    {
        this.ward = ward;
    }

    public ClassMetaEntity getAdmissionClass()
    {
        return admissionClass;
    }

    public void setAdmissionClass(ClassMetaEntity admissionClass)
    {
        this.admissionClass = admissionClass;
    }

    public String getAdmissionDiagnosis()
    {
        return admissionDiagnosis;
    }

    public void setAdmissionDiagnosis(String admissionDiagnosis)
    {
        this.admissionDiagnosis = admissionDiagnosis;
    }

    public String getSuggestedTreatment()
    {
        return suggestedTreatment;
    }

    public void setSuggestedTreatment(String suggestedTreatment)
    {
        this.suggestedTreatment = suggestedTreatment;
    }

    public String getSuggestedOpr()
    {
        return suggestedOpr;
    }

    public void setSuggestedOpr(String suggestedOpr)
    {
        this.suggestedOpr = suggestedOpr;
    }

    public String getSpecialNotesOrRemarks()
    {
        return specialNotesOrRemarks;
    }

    public void setSpecialNotesOrRemarks(String specialNotesOrRemarks)
    {
        this.specialNotesOrRemarks = specialNotesOrRemarks;
    }

    public String getApptDateStr()
    {
        Format formatter = new SimpleDateFormat("yyyy/mm/dd");
        if(admissionDate == null || admissionDate.equals(""))
        {
            return this.apptDateStr;
        } else
        {
            String apptDateStr = formatter.format(admissionDate);
            return apptDateStr;
        }
    }

    public void setApptDateStr(String admitDateStr)
    {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/mm/dd");
        try
        {
            admissionDate = formatter.parse(admitDateStr);
        }
        catch(ParseException e)
        {
            e.printStackTrace();
        }
        apptDateStr = apptDateStr;
    }

    private String admissionCode;
    private Date admissionDate;
    private String admissionTime;
    private String age;
    private StatusMetaEntity status;
    private OperationTypeMetaEntity type;
    private AdmittingConsultantMetaEntity admittingConsultant;
    private WardMetaEntity ward;
    private ClassMetaEntity admissionClass;
    private String admissionDiagnosis;
    private String suggestedTreatment;
    private String suggestedOpr;
    private String specialNotesOrRemarks;
    private String pid;
    private String name;
    private Integer id;
    private String apptDateStr;
    private BedEntity bedEntity;
}
