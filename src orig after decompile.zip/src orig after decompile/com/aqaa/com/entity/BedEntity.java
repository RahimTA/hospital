// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BedEntity.java

package com.aqaa.com.entity;

import java.text.*;
import java.util.Date;

// Referenced classes of package com.aqaa.com.entity:
//            BedMetaEntity, AdmissionEntity

public class BedEntity
{

    public BedEntity()
    {
    }

    public AdmissionEntity getAdmissionEntity()
    {
        return admissionEntity;
    }

    public void setAdmissionEntity(AdmissionEntity admissionEntity)
    {
        this.admissionEntity = admissionEntity;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public String getPatientId()
    {
        return patientId;
    }

    public void setPatientId(String patientId)
    {
        this.patientId = patientId;
    }

    public Date getStartDate()
    {
        return startDate;
    }

    public void setStartDate(Date startDate)
    {
        this.startDate = startDate;
    }

    public BedMetaEntity getBedNo()
    {
        return bedNo;
    }

    public void setBedNo(BedMetaEntity bedNo)
    {
        this.bedNo = bedNo;
    }

    public Date getEndDate()
    {
        return endDate;
    }

    public void setEndDate(Date endDate)
    {
        this.endDate = endDate;
    }

    public String getApptDateStr()
    {
        Format formatter = new SimpleDateFormat("yyyy/mm/dd");
        if(startDate == null || startDate.equals(""))
        {
            return this.apptDateStr;
        } else
        {
            String apptDateStr = formatter.format(startDate);
            return apptDateStr;
        }
    }

    public void setApptDateStr(String admitDateStr)
    {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/mm/dd");
        try
        {
            startDate = formatter.parse(admitDateStr);
        }
        catch(ParseException e)
        {
            e.printStackTrace();
        }
        apptDateStr = apptDateStr;
    }

    private Integer id;
    private String patientId;
    private Date startDate;
    private BedMetaEntity bedNo;
    private Date endDate;
    private String apptDateStr;
    private AdmissionEntity admissionEntity;
}
