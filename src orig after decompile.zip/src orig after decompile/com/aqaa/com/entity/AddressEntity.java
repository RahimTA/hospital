// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AddressEntity.java

package com.aqaa.com.entity;


// Referenced classes of package com.aqaa.com.entity:
//            CityMetaEntity, StateMetaEntity, CountryMetaEntity, DistrictMetaEntity, 
//            PersonEntity

public class AddressEntity
{

    public AddressEntity()
    {
    }

    public PersonEntity getPersonEntity()
    {
        return personEntity;
    }

    public void setPersonEntity(PersonEntity personEntity)
    {
        this.personEntity = personEntity;
    }

    public String getAdd2()
    {
        return add2;
    }

    public void setAdd2(String add2)
    {
        this.add2 = add2;
    }

    public String getAdd3()
    {
        return add3;
    }

    public void setAdd3(String add3)
    {
        this.add3 = add3;
    }

    public String getPin()
    {
        return pin;
    }

    public void setPin(String pin)
    {
        this.pin = pin;
    }

    public CityMetaEntity getCity()
    {
        return city;
    }

    public void setCity(CityMetaEntity city)
    {
        this.city = city;
    }

    public String getArea()
    {
        return area;
    }

    public void setArea(String area)
    {
        this.area = area;
    }

    public StateMetaEntity getState()
    {
        return state;
    }

    public void setState(StateMetaEntity state)
    {
        this.state = state;
    }

    public CountryMetaEntity getCountry()
    {
        return country;
    }

    public void setCountry(CountryMetaEntity country)
    {
        this.country = country;
    }

    public DistrictMetaEntity getDistrict()
    {
        return district;
    }

    public void setDistrict(DistrictMetaEntity district)
    {
        this.district = district;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public String getAdd1()
    {
        return add1;
    }

    public void setAdd1(String add1)
    {
        this.add1 = add1;
    }

    private Integer id;
    private String add1;
    private String add2;
    private String add3;
    private String pin;
    private CityMetaEntity city;
    private String area;
    private StateMetaEntity state;
    private CountryMetaEntity country;
    private DistrictMetaEntity district;
    private PersonEntity personEntity;
}
