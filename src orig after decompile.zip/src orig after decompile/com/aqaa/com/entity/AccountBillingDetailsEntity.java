// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AccountBillingDetailsEntity.java

package com.aqaa.com.entity;


// Referenced classes of package com.aqaa.com.entity:
//            CaseTypeMetaEntity, BillTypeMetaEntity, PaymentByMetaEntity, TypeofMetaEntity, 
//            BillingChargesEntity

public class AccountBillingDetailsEntity
{

    public AccountBillingDetailsEntity()
    {
    }

    public int getId()
    {
        return id;
    }

    public String getPerticularsOfCharges()
    {
        return perticularsOfCharges;
    }

    public void setPerticularsOfCharges(String perticularsOfCharges)
    {
        this.perticularsOfCharges = perticularsOfCharges;
    }

    public String getDetails()
    {
        return details;
    }

    public void setDetails(String details)
    {
        this.details = details;
    }

    public String getRate()
    {
        return rate;
    }

    public void setRate(String rate)
    {
        this.rate = rate;
    }

    public String getQty()
    {
        return qty;
    }

    public void setQty(String qty)
    {
        this.qty = qty;
    }

    public String getAmt()
    {
        return amt;
    }

    public void setAmt(String amt)
    {
        this.amt = amt;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getPatientId()
    {
        return patientId;
    }

    public void setPatientId(String patientId)
    {
        this.patientId = patientId;
    }

    public String getPatientName()
    {
        return patientName;
    }

    public void setPatientName(String patientName)
    {
        this.patientName = patientName;
    }

    public String getBillNo()
    {
        return billNo;
    }

    public void setBillNo(String billNo)
    {
        this.billNo = billNo;
    }

    public String getBillCode()
    {
        return billCode;
    }

    public void setBillCode(String billCode)
    {
        this.billCode = billCode;
    }

    public CaseTypeMetaEntity getCaseType()
    {
        return caseType;
    }

    public void setCaseType(CaseTypeMetaEntity caseType)
    {
        this.caseType = caseType;
    }

    public String getDate()
    {
        return date;
    }

    public void setDate(String date)
    {
        this.date = date;
    }

    public BillTypeMetaEntity getBillType()
    {
        return billType;
    }

    public void setBillType(BillTypeMetaEntity billType)
    {
        this.billType = billType;
    }

    public PaymentByMetaEntity getPaymentBy()
    {
        return paymentBy;
    }

    public void setPaymentBy(PaymentByMetaEntity paymentBy)
    {
        this.paymentBy = paymentBy;
    }

    public TypeofMetaEntity getTypeOfPayment()
    {
        return typeOfPayment;
    }

    public void setTypeOfPayment(TypeofMetaEntity typeOfPayment)
    {
        this.typeOfPayment = typeOfPayment;
    }

    public String getGrossTotal()
    {
        return grossTotal;
    }

    public void setGrossTotal(String grossTotal)
    {
        this.grossTotal = grossTotal;
    }

    public String getDiscount()
    {
        return discount;
    }

    public void setDiscount(String discount)
    {
        this.discount = discount;
    }

    public String getServiceTax()
    {
        return serviceTax;
    }

    public void setServiceTax(String serviceTax)
    {
        this.serviceTax = serviceTax;
    }

    public String getNetAmount()
    {
        return netAmount;
    }

    public void setNetAmount(String netAmount)
    {
        this.netAmount = netAmount;
    }

    public String getDoctorIncharge()
    {
        return doctorIncharge;
    }

    public void setDoctorIncharge(String doctorIncharge)
    {
        this.doctorIncharge = doctorIncharge;
    }

    public BillingChargesEntity getBcEntity()
    {
        return bcEntity;
    }

    public void setBcEntity(BillingChargesEntity bcEntity)
    {
        this.bcEntity = bcEntity;
    }

    private int id;
    private String doctorIncharge;
    private String patientId;
    private String patientName;
    private String billNo;
    private String billCode;
    private CaseTypeMetaEntity caseType;
    private String date;
    private BillTypeMetaEntity billType;
    private PaymentByMetaEntity paymentBy;
    private TypeofMetaEntity typeOfPayment;
    private String grossTotal;
    private String discount;
    private String serviceTax;
    private String netAmount;
    private String perticularsOfCharges;
    private String details;
    private String rate;
    private String qty;
    private String amt;
    private BillingChargesEntity bcEntity;
}
