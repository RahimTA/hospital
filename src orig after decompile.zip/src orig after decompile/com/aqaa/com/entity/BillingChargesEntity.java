// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BillingChargesEntity.java

package com.aqaa.com.entity;


// Referenced classes of package com.aqaa.com.entity:
//            AccountBillingDetailsEntity

public class BillingChargesEntity
{

    public BillingChargesEntity()
    {
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getPerticularsOfCharges()
    {
        return perticularsOfCharges;
    }

    public void setPerticularsOfCharges(String perticularsOfCharges)
    {
        this.perticularsOfCharges = perticularsOfCharges;
    }

    public String getDetails()
    {
        return details;
    }

    public void setDetails(String details)
    {
        this.details = details;
    }

    public String getRate()
    {
        return rate;
    }

    public void setRate(String rate)
    {
        this.rate = rate;
    }

    public String getQty()
    {
        return qty;
    }

    public void setQty(String qty)
    {
        this.qty = qty;
    }

    public String getAmt()
    {
        return amt;
    }

    public void setAmt(String amt)
    {
        this.amt = amt;
    }

    public AccountBillingDetailsEntity getAbEntity()
    {
        return abEntity;
    }

    public void setAbEntity(AccountBillingDetailsEntity abEntity)
    {
        this.abEntity = abEntity;
    }

    private int id;
    private String perticularsOfCharges;
    private String details;
    private String rate;
    private String qty;
    private String amt;
    private AccountBillingDetailsEntity abEntity;
}
