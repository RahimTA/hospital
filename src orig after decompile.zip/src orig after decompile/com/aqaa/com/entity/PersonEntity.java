// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PersonEntity.java

package com.aqaa.com.entity;

import com.ibm.icu.text.SimpleDateFormat;
import java.text.Format;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

// Referenced classes of package com.aqaa.com.entity:
//            ContactEntity, GenderMetaEntity, MstatusMetaEntity, TitleMetaEntity, 
//            BloodGroupMetaEntity, TypeMetaEntity, PatientEntity, DoctorEntity

public class PersonEntity
{

    public PersonEntity()
    {
        contact = new ContactEntity();
    }

    public ContactEntity getContact()
    {
        return contact;
    }

    public void setContact(ContactEntity contact)
    {
        this.contact = contact;
    }

    public ContactEntity getContactEntities()
    {
        return contactEntities;
    }

    public void setContactEntities(ContactEntity contactEntities)
    {
        this.contactEntities = contactEntities;
    }

    public List getAddressEntity()
    {
        return addressEntity;
    }

    public void setAddressEntity(List addressEntity)
    {
        this.addressEntity = addressEntity;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public String getFname()
    {
        return fname;
    }

    public void setFname(String fname)
    {
        this.fname = fname;
    }

    public String getLname()
    {
        return lname;
    }

    public void setLname(String lname)
    {
        this.lname = lname;
    }

    public String getSname()
    {
        return sname;
    }

    public void setSname(String sname)
    {
        this.sname = sname;
    }

    public String getDobstr()
    {
        Format formatter = new SimpleDateFormat("yyyy/mm/dd");
        if(dob == null || dob.equals(""))
        {
            return this.dobstr;
        } else
        {
            String dobstr = formatter.format(dob);
            return dobstr;
        }
    }

    public void setDobstr(String dobstr)
    {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/mm/dd");
        try
        {
            dob = formatter.parse(dobstr);
        }
        catch(ParseException e)
        {
            e.printStackTrace();
        }
        this.dobstr = dobstr;
    }

    public Date getDob()
    {
        return dob;
    }

    public void setDob(Date dob)
    {
        this.dob = dob;
    }

    public GenderMetaEntity getGender()
    {
        return gender;
    }

    public void setGender(GenderMetaEntity gender)
    {
        this.gender = gender;
    }

    public MstatusMetaEntity getMstatus()
    {
        return mstatus;
    }

    public void setMstatus(MstatusMetaEntity mstatus)
    {
        this.mstatus = mstatus;
    }

    public TitleMetaEntity getTitle()
    {
        return title;
    }

    public void setTitle(TitleMetaEntity title)
    {
        this.title = title;
    }

    public BloodGroupMetaEntity getBloodGroup()
    {
        return bloodGroup;
    }

    public void setBloodGroup(BloodGroupMetaEntity bloodGroup)
    {
        this.bloodGroup = bloodGroup;
    }

    public PatientEntity getPatientEntity()
    {
        return patientEntity;
    }

    public void setPatientEntity(PatientEntity patientEntity)
    {
        this.patientEntity = patientEntity;
    }

    public TypeMetaEntity getTypeEntity()
    {
        return typeEntity;
    }

    public void setTypeEntity(TypeMetaEntity typeEntity)
    {
        this.typeEntity = typeEntity;
    }

    public DoctorEntity getDoctor()
    {
        return doctor;
    }

    public void setDoctor(DoctorEntity doctor)
    {
        this.doctor = doctor;
    }

    private Integer id;
    private String fname;
    private String lname;
    private String sname;
    private Date dob;
    private String dobstr;
    private GenderMetaEntity gender;
    private MstatusMetaEntity mstatus;
    private TitleMetaEntity title;
    private BloodGroupMetaEntity bloodGroup;
    private TypeMetaEntity typeEntity;
    private PatientEntity patientEntity;
    private DoctorEntity doctor;
    private ContactEntity contact;
    private List addressEntity;
    private ContactEntity contactEntities;
}
