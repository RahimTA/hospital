// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Otp.java

package com.core.practie;

import java.io.PrintStream;
import java.util.Random;

public class Otp
{

    public Otp()
    {
    }

    public static void main(String args[])
    {
        Random random = new Random();
        int otp = random.nextInt();
        System.out.println((new StringBuilder("opt:")).append(otp).toString());
    }
}
