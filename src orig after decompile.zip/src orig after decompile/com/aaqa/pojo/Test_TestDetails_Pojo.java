// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Test_TestDetails_Pojo.java

package com.aaqa.pojo;

import com.aqaa.com.entity.*;
import java.text.*;
import java.util.Date;
import org.apache.log4j.Logger;

public class Test_TestDetails_Pojo
{

    public Test_TestDetails_Pojo()
    {
        logger = Logger.getLogger(com/aaqa/pojo/Test_TestDetails_Pojo);
    }

    public String getTime()
    {
        return time;
    }

    public void setTime(String time)
    {
        this.time = time;
    }

    public String getFname()
    {
        return fname;
    }

    public void setFname(String fname)
    {
        this.fname = fname;
    }

    public PatientEntity getPatientEntity()
    {
        return patientEntity;
    }

    public void setPatientEntity(PatientEntity patientEntity)
    {
        this.patientEntity = patientEntity;
    }

    public DoneByEntity getDoneByEntity()
    {
        return doneByEntity;
    }

    public void setDoneByEntity(DoneByEntity doneByEntity)
    {
        this.doneByEntity = doneByEntity;
    }

    public DocDesignationEntity getDocDesignationEntity()
    {
        return docDesignationEntity;
    }

    public void setDocDesignationEntity(DocDesignationEntity docDesignationEntity)
    {
        this.docDesignationEntity = docDesignationEntity;
    }

    public TestEntity getTestEntity()
    {
        return testEntity;
    }

    public void setTestEntity(TestEntity testEntity)
    {
        this.testEntity = testEntity;
    }

    public Integer getTestid()
    {
        return testid;
    }

    public void setTestid(Integer testid)
    {
        this.testid = testid;
    }

    public String getObservations()
    {
        return observations;
    }

    public void setObservations(String observations)
    {
        this.observations = observations;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getConclusion()
    {
        return conclusion;
    }

    public void setConclusion(String conclusion)
    {
        this.conclusion = conclusion;
    }

    public String getRemarks()
    {
        return remarks;
    }

    public void setRemarks(String remarks)
    {
        this.remarks = remarks;
    }

    public Date getDate()
    {
        return date;
    }

    public void setDate(Date date)
    {
        this.date = date;
    }

    public String getApptTime()
    {
        Format formatter = new SimpleDateFormat("HH:mm");
        if(date == null || date.equals(""))
        {
            return apptTime;
        } else
        {
            String appTime = formatter.format(date);
            return appTime;
        }
    }

    public void setApptTime(String apptTimeStr)
    {
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
        try
        {
            date = formatter.parse(apptTimeStr);
        }
        catch(ParseException e)
        {
            e.printStackTrace();
        }
        this.apptTimeStr = apptTimeStr;
    }

    public String getApptTimeStr()
    {
        return apptTimeStr;
    }

    public void setApptTimeStr(String apptTimeStr)
    {
        this.apptTimeStr = apptTimeStr;
    }

    public String getDateStr()
    {
        Format formatter = new SimpleDateFormat("yyyy/mm/dd");
        logger.fatal((new StringBuilder("Date in getDateStr is ::")).append(date).toString());
        if(date == null || date.equals(""))
        {
            return this.dateStr;
        } else
        {
            String dateStr = formatter.format(date);
            return dateStr;
        }
    }

    public void setDateStr(String dateStr)
    {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/mm/dd");
        try
        {
            date = formatter.parse(dateStr);
            logger.fatal((new StringBuilder("inside setDateStr the date..:")).append(date).toString());
        }
        catch(ParseException e)
        {
            e.printStackTrace();
        }
        this.dateStr = dateStr;
    }

    Logger logger;
    private Integer testid;
    private Date date;
    private String apptTime;
    private String dateStr;
    private String time;
    private String observations;
    private String title;
    private String conclusion;
    private String remarks;
    private String fname;
    private TestEntity testEntity;
    private DoneByEntity doneByEntity;
    private DocDesignationEntity docDesignationEntity;
    private PatientEntity patientEntity;
    private String apptTimeStr;
}
