// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AppointmentPopupPojo.java

package com.aaqa.pojo;

import com.aqaa.com.entity.*;

public class AppointmentPopupPojo
{

    public AppointmentPopupPojo()
    {
        patientEntity = new PatientEntity();
        appointmentEntity = new AppointmentEntity();
        doctorEntity = new DoctorEntity();
        appointmentEntity.setAppointmentForEntity(new AppointmentForEntity());
        appointmentEntity.setAppointmentStatus(new AppointmentStatusMetaEntity());
    }

    public PatientEntity getPatientEntity()
    {
        return patientEntity;
    }

    public void setPatientEntity(PatientEntity patientEntity)
    {
        this.patientEntity = patientEntity;
    }

    public AppointmentEntity getAppointmentEntity()
    {
        return appointmentEntity;
    }

    public void setAppointmentEntity(AppointmentEntity appointmentEntity)
    {
        this.appointmentEntity = appointmentEntity;
    }

    public DoctorEntity getDoctorEntity()
    {
        return doctorEntity;
    }

    public void setDoctorEntity(DoctorEntity doctorEntity)
    {
        this.doctorEntity = doctorEntity;
    }

    private PatientEntity patientEntity;
    private AppointmentEntity appointmentEntity;
    private DoctorEntity doctorEntity;
}
