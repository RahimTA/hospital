// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AdmissionDetailsPopUpPojo.java

package com.aaqa.pojo;

import com.aqaa.com.entity.*;

public class AdmissionDetailsPopUpPojo
{

    public AdmissionDetailsPopUpPojo()
    {
        admission = new AdmissionEntity();
        bed = new BedEntity();
        admission.setStatus(new StatusMetaEntity());
        admission.setType(new OperationTypeMetaEntity());
        admission.setAdmissionClass(new ClassMetaEntity());
        admission.setAdmittingConsultant(new AdmittingConsultantMetaEntity());
        admission.setWard(new WardMetaEntity());
        bed.setBedNo(new BedMetaEntity());
    }

    public AdmissionEntity getAdmission()
    {
        return admission;
    }

    public void setAdmission(AdmissionEntity admission)
    {
        this.admission = admission;
    }

    public BedEntity getBed()
    {
        return bed;
    }

    public void setBed(BedEntity bed)
    {
        this.bed = bed;
    }

    private AdmissionEntity admission;
    private BedEntity bed;
}
