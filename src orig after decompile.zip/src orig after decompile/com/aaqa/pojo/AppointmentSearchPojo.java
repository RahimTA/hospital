// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AppointmentSearchPojo.java

package com.aaqa.pojo;

import java.util.Date;

public class AppointmentSearchPojo
{

    public AppointmentSearchPojo()
    {
    }

    public Integer getAppId()
    {
        return appId;
    }

    public void setAppId(Integer appId)
    {
        this.appId = appId;
    }

    public Date getAppointmentDate()
    {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate)
    {
        this.appointmentDate = appointmentDate;
    }

    public String getPatientName()
    {
        return patientName;
    }

    public void setPatientName(String patientName)
    {
        this.patientName = patientName;
    }

    public String getAppStatus()
    {
        return appStatus;
    }

    public void setAppStatus(String appStatus)
    {
        this.appStatus = appStatus;
    }

    public String getDoctorName()
    {
        return doctorName;
    }

    public void setDoctorName(String doctorName)
    {
        this.doctorName = doctorName;
    }

    private Integer appId;
    private Date appointmentDate;
    private String patientName;
    private String appStatus;
    private String doctorName;
}
