// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PatientInfoPojo.java

package com.aaqa.pojo;

import com.aqaa.com.entity.*;
import java.util.ArrayList;

public class PatientInfoPojo
{

    public ContactEntity getContact()
    {
        return contact;
    }

    public void setContact(ContactEntity contact)
    {
        this.contact = contact;
    }

    public PatientInfoPojo()
    {
        person = new PersonEntity();
        patient = new PatientEntity();
        address = new AddressEntity();
        contact = person.getContact();
        person.setGender(new GenderMetaEntity());
        person.setMstatus(new MstatusMetaEntity());
        person.setTitle(new TitleMetaEntity());
        person.setBloodGroup(new BloodGroupMetaEntity());
        patient.setFinstatus(new FinstatusMetaEntity());
        patient.setCastcat(new CastcatMeta());
        patient.setOccupation(new OcupationMeta());
        patient.setPersonEntity(new PersonEntity());
        patient.setAllergyMeta(new ArrayList());
        address.setCity(new CityMetaEntity());
        address.setCountry(new CountryMetaEntity());
        address.setDistrict(new DistrictMetaEntity());
        address.setState(new StateMetaEntity());
    }

    public PersonEntity getPerson()
    {
        return person;
    }

    public void setPerson(PersonEntity person)
    {
        this.person = person;
    }

    public PatientEntity getPatient()
    {
        return patient;
    }

    public void setPatient(PatientEntity patient)
    {
        this.patient = patient;
    }

    public AddressEntity getAddress()
    {
        return address;
    }

    public void setAddress(AddressEntity address)
    {
        this.address = address;
    }

    public String[] getAlergies()
    {
        return alergies;
    }

    public void setAlergies(String alergies[])
    {
        this.alergies = alergies;
    }

    private PersonEntity person;
    private PatientEntity patient;
    private AddressEntity address;
    private String alergies[];
    private ContactEntity contact;
}
