// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AccountBillingDetailsPojo.java

package com.aaqa.pojo;

import com.aqaa.com.entity.*;

public class AccountBillingDetailsPojo
{

    public AccountBillingDetailsPojo()
    {
        abde = new AccountBillingDetailsEntity();
        abde.setCaseType(new CaseTypeMetaEntity());
        abde.setTypeOfPayment(new TypeofMetaEntity());
        abde.setPaymentBy(new PaymentByMetaEntity());
        abde.setBillType(new BillTypeMetaEntity());
    }

    public AccountBillingDetailsEntity getAbde()
    {
        return abde;
    }

    public void setAbde(AccountBillingDetailsEntity abde)
    {
        this.abde = abde;
    }

    private AccountBillingDetailsEntity abde;
}
