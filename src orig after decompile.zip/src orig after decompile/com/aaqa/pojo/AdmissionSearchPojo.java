// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AdmissionSearchPojo.java

package com.aaqa.pojo;

import java.util.Date;

public class AdmissionSearchPojo
{

    public AdmissionSearchPojo()
    {
    }

    public String getAdmissionCode()
    {
        return admissionCode;
    }

    public void setAdmissionCode(String admissionCode)
    {
        this.admissionCode = admissionCode;
    }

    public String getPatientName()
    {
        return patientName;
    }

    public void setPatientName(String patientName)
    {
        this.patientName = patientName;
    }

    public Date getAdmissionDate()
    {
        return admissionDate;
    }

    public void setAdmissionDate(Date admissionDate)
    {
        this.admissionDate = admissionDate;
    }

    public String getYears()
    {
        return years;
    }

    public void setYears(String years)
    {
        this.years = years;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public String getClasstype()
    {
        return classtype;
    }

    public void setClasstype(String classtype)
    {
        this.classtype = classtype;
    }

    public String getDoctorName()
    {
        return doctorName;
    }

    public void setDoctorName(String doctorName)
    {
        this.doctorName = doctorName;
    }

    public String getPatientId()
    {
        return patientId;
    }

    public void setPatientId(String patientId)
    {
        this.patientId = patientId;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    private String admissionCode;
    private String patientName;
    private Date admissionDate;
    private String years;
    private String city;
    private String status;
    private String type;
    private String classtype;
    private String doctorName;
    private String patientId;
    private Integer id;
}
