// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CommonSearchPojo.java

package com.aaqa.pojo;


public class CommonSearchPojo
{

    public CommonSearchPojo()
    {
    }

    public String getSearch3()
    {
        return Search3;
    }

    public void setSearch3(String search3)
    {
        Search3 = search3;
    }

    public String getValue()
    {
        return value;
    }

    public void setValue(String value)
    {
        this.value = value;
    }

    public Integer getPeriod()
    {
        return period;
    }

    public void setPeriod(Integer period)
    {
        this.period = period;
    }

    public Integer getSearch()
    {
        return Search;
    }

    public void setSearch(Integer search)
    {
        Search = search;
    }

    public Integer getSearch1()
    {
        return Search1;
    }

    public void setSearch1(Integer search1)
    {
        Search1 = search1;
    }

    public Integer getSearch2()
    {
        return Search2;
    }

    public void setSearch2(Integer search2)
    {
        Search2 = search2;
    }

    private Integer period;
    private Integer Search;
    private Integer Search1;
    private Integer Search2;
    private String Search3;
    private String value;
}
