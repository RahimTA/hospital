// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DischargeDetailsPopupPojo.java

package com.aaqa.pojo;

import com.aqaa.com.entity.DoctorEntity;
import com.aqaa.com.entity.PatientEntity;
import java.text.*;
import java.util.Date;

public class DischargeDetailsPopupPojo
{

    public DischargeDetailsPopupPojo()
    {
    }

    public PatientEntity getPatientEntity()
    {
        return patientEntity;
    }

    public void setPatientEntity(PatientEntity patientEntity)
    {
        this.patientEntity = patientEntity;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public String getFinalDiagnosis()
    {
        return finalDiagnosis;
    }

    public void setFinalDiagnosis(String finalDiagnosis)
    {
        this.finalDiagnosis = finalDiagnosis;
    }

    public String getConditionOfPatientDischarge()
    {
        return conditionOfPatientDischarge;
    }

    public void setConditionOfPatientDischarge(String conditionOfPatientDischarge)
    {
        this.conditionOfPatientDischarge = conditionOfPatientDischarge;
    }

    public String getHospitalNotes()
    {
        return hospitalNotes;
    }

    public void setHospitalNotes(String hospitalNotes)
    {
        this.hospitalNotes = hospitalNotes;
    }

    public String getDischargeNotes()
    {
        return dischargeNotes;
    }

    public void setDischargeNotes(String dischargeNotes)
    {
        this.dischargeNotes = dischargeNotes;
    }

    public String getCriticalDetailsAtAdmission()
    {
        return criticalDetailsAtAdmission;
    }

    public void setCriticalDetailsAtAdmission(String criticalDetailsAtAdmission)
    {
        this.criticalDetailsAtAdmission = criticalDetailsAtAdmission;
    }

    public String getTreatementGiven()
    {
        return treatementGiven;
    }

    public void setTreatementGiven(String treatementGiven)
    {
        this.treatementGiven = treatementGiven;
    }

    public String getLab_investigation()
    {
        return lab_investigation;
    }

    public void setLab_investigation(String lab_investigation)
    {
        this.lab_investigation = lab_investigation;
    }

    public String getAdvice()
    {
        return advice;
    }

    public void setAdvice(String advice)
    {
        this.advice = advice;
    }

    public String getIssueToBeFollowed()
    {
        return issueToBeFollowed;
    }

    public void setIssueToBeFollowed(String issueToBeFollowed)
    {
        this.issueToBeFollowed = issueToBeFollowed;
    }

    public Date getDischargeDate()
    {
        return dischargeDate;
    }

    public void setDischargeDate(Date dischargeDate)
    {
        this.dischargeDate = dischargeDate;
    }

    public DoctorEntity getDoctor()
    {
        return doctor;
    }

    public void setDoctor(DoctorEntity doctor)
    {
        this.doctor = doctor;
    }

    public Date getFollowUpDate()
    {
        return followUpDate;
    }

    public void setFollowUpDate(Date followUpDate)
    {
        this.followUpDate = followUpDate;
    }

    public String getPname()
    {
        return pname;
    }

    public void setPname(String pname)
    {
        this.pname = pname;
    }

    public String getAdmitCode()
    {
        return admitCode;
    }

    public void setAdmitCode(String admitCode)
    {
        this.admitCode = admitCode;
    }

    public Date getAdmitDate()
    {
        return admitDate;
    }

    public void setAdmitDate(Date admitDate)
    {
        this.admitDate = admitDate;
    }

    public String getAdmitDateStr()
    {
        Format formatter = new SimpleDateFormat("yyyy/mm/dd");
        String stringDate = null;
        if(admitDate == null || admitDate.equals(""))
        {
            return stringDate;
        } else
        {
            stringDate = formatter.format(admitDate);
            return stringDate;
        }
    }

    public void setAdmitDateStr(String admitDateStr)
    {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/mm/dd");
        try
        {
            admitDate = formatter.parse(admitDateStr);
        }
        catch(ParseException e)
        {
            e.printStackTrace();
        }
        this.admitDateStr = admitDateStr;
    }

    public String getFollowUpDateStr()
    {
        Format formatter = new SimpleDateFormat("yyyy/mm/dd");
        String stringDate = null;
        if(followUpDate == null || followUpDate.equals(""))
        {
            return stringDate;
        } else
        {
            stringDate = formatter.format(followUpDate);
            return stringDate;
        }
    }

    public void setFollowUpDateStr(String followUpDateStr)
    {
        SimpleDateFormat format = new SimpleDateFormat("yyyy/mm/dd");
        try
        {
            followUpDate = format.parse(followUpDateStr);
        }
        catch(ParseException e)
        {
            e.printStackTrace();
        }
        this.followUpDateStr = followUpDateStr;
    }

    public String getDischargeDateStr()
    {
        Format formatter = new SimpleDateFormat("yyyy/mm/dd");
        String stringDate = null;
        if(dischargeDate == null || dischargeDate.equals(""))
        {
            return stringDate;
        } else
        {
            stringDate = formatter.format(dischargeDate);
            return stringDate;
        }
    }

    public void setDischargeDateStr(String dischargeDateStr)
    {
        SimpleDateFormat format = new SimpleDateFormat("yyyy/mm/dd");
        try
        {
            dischargeDate = format.parse(dischargeDateStr);
        }
        catch(ParseException e)
        {
            e.printStackTrace();
        }
        this.dischargeDateStr = dischargeDateStr;
    }

    private String pname;
    private Integer id;
    private String finalDiagnosis;
    private String conditionOfPatientDischarge;
    private String hospitalNotes;
    private String dischargeNotes;
    private String criticalDetailsAtAdmission;
    private String treatementGiven;
    private String lab_investigation;
    private String advice;
    private String issueToBeFollowed;
    private Date followUpDate;
    private Date dischargeDate;
    private DoctorEntity doctor;
    private String admitCode;
    private Date admitDate;
    private String admitDateStr;
    private String followUpDateStr;
    private String dischargeDateStr;
    private PatientEntity patientEntity;
}
