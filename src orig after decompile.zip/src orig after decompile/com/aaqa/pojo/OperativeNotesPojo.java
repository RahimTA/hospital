// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   OperativeNotesPojo.java

package com.aaqa.pojo;

import com.aqaa.com.entity.*;
import java.util.Date;

public class OperativeNotesPojo
{

    public OperativeNotesPojo()
    {
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Date getDate()
    {
        return date;
    }

    public void setDate(Date date)
    {
        this.date = date;
    }

    public Date getStartTime()
    {
        return startTime;
    }

    public void setStartTime(Date startTime)
    {
        this.startTime = startTime;
    }

    public Date getFinishTime()
    {
        return finishTime;
    }

    public void setFinishTime(Date finishTime)
    {
        this.finishTime = finishTime;
    }

    public OperationAtMetaEntity getOperateAt()
    {
        return operateAt;
    }

    public void setOperateAt(OperationAtMetaEntity operateAt)
    {
        this.operateAt = operateAt;
    }

    public OtNoMetaEntity getOtNo()
    {
        return otNo;
    }

    public void setOtNo(OtNoMetaEntity otNo)
    {
        this.otNo = otNo;
    }

    public SurgeonMetaEntity getSurgeon()
    {
        return surgeon;
    }

    public void setSurgeon(SurgeonMetaEntity surgeon)
    {
        this.surgeon = surgeon;
    }

    public AssistantMetaEntity getAssistant()
    {
        return assistant;
    }

    public void setAssistant(AssistantMetaEntity assistant)
    {
        this.assistant = assistant;
    }

    public AnaesthesiologistMetaEntity getAnaesthesiologist()
    {
        return anaesthesiologist;
    }

    public void setAnaesthesiologist(AnaesthesiologistMetaEntity anaesthesiologist)
    {
        this.anaesthesiologist = anaesthesiologist;
    }

    public AnasthesiaTechniqueMetaEntity getAnaesthesiaTechnique()
    {
        return anaesthesiaTechnique;
    }

    public void setAnaesthesiaTechnique(AnasthesiaTechniqueMetaEntity anaesthesiaTechnique)
    {
        this.anaesthesiaTechnique = anaesthesiaTechnique;
    }

    public PressureMetaEntity getPressure()
    {
        return pressure;
    }

    public void setPressure(PressureMetaEntity pressure)
    {
        this.pressure = pressure;
    }

    public PulseMetaEntity getPulse()
    {
        return pulse;
    }

    public void setPulse(PulseMetaEntity pulse)
    {
        this.pulse = pulse;
    }

    public Integer getWeight()
    {
        return weight;
    }

    public void setWeight(Integer weight)
    {
        this.weight = weight;
    }

    public OperationTypeMetaEntity getType()
    {
        return type;
    }

    public void setType(OperationTypeMetaEntity type)
    {
        this.type = type;
    }

    public NatureMetaEntity getNature()
    {
        return nature;
    }

    public void setNature(NatureMetaEntity nature)
    {
        this.nature = nature;
    }

    public String getExecutedOperations()
    {
        return executedOperations;
    }

    public void setExecutedOperations(String executedOperations)
    {
        this.executedOperations = executedOperations;
    }

    public String getRiskFactor()
    {
        return riskFactor;
    }

    public void setRiskFactor(String riskFactor)
    {
        this.riskFactor = riskFactor;
    }

    public String getOperrationNotes()
    {
        return operrationNotes;
    }

    public void setOperrationNotes(String operrationNotes)
    {
        this.operrationNotes = operrationNotes;
    }

    public DoctorEntity getDoctor()
    {
        return doctor;
    }

    public void setDoctor(DoctorEntity doctor)
    {
        this.doctor = doctor;
    }

    public Date getDischargeDate()
    {
        return dischargeDate;
    }

    public void setDischargeDate(Date dischargeDate)
    {
        this.dischargeDate = dischargeDate;
    }

    private Integer id;
    private Date date;
    private Date startTime;
    private Date finishTime;
    private OperationAtMetaEntity operateAt;
    private OtNoMetaEntity otNo;
    private SurgeonMetaEntity surgeon;
    private AssistantMetaEntity assistant;
    private AnaesthesiologistMetaEntity anaesthesiologist;
    private AnasthesiaTechniqueMetaEntity anaesthesiaTechnique;
    private PressureMetaEntity pressure;
    private PulseMetaEntity pulse;
    private Integer weight;
    private OperationTypeMetaEntity type;
    private NatureMetaEntity nature;
    private String executedOperations;
    private String riskFactor;
    private String operrationNotes;
    private DoctorEntity doctor;
    private Date dischargeDate;
}
