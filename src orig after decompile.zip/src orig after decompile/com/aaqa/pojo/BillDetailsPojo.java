// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BillDetailsPojo.java

package com.aaqa.pojo;


public class BillDetailsPojo
{

    public BillDetailsPojo()
    {
    }

    public String getPeriod()
    {
        return period;
    }

    public void setPeriod(String period)
    {
        this.period = period;
    }

    public String getSearch()
    {
        return search;
    }

    public void setSearch(String search)
    {
        this.search = search;
    }

    public String getSearch1()
    {
        return search1;
    }

    public void setSearch1(String search1)
    {
        this.search1 = search1;
    }

    public String getSearch2()
    {
        return search2;
    }

    public void setSearch2(String search2)
    {
        this.search2 = search2;
    }

    public String getBillNo()
    {
        return billNo;
    }

    public void setBillNo(String billNo)
    {
        this.billNo = billNo;
    }

    public String getBillName()
    {
        return billName;
    }

    public void setBillName(String billName)
    {
        this.billName = billName;
    }

    public String getPatientName()
    {
        return patientName;
    }

    public void setPatientName(String patientName)
    {
        this.patientName = patientName;
    }

    public String getDoctorName()
    {
        return doctorName;
    }

    public void setDoctorName(String doctorName)
    {
        this.doctorName = doctorName;
    }

    public String getCaseType()
    {
        return caseType;
    }

    public void setCaseType(String caseType)
    {
        this.caseType = caseType;
    }

    public String getBillType()
    {
        return billType;
    }

    public void setBillType(String billType)
    {
        this.billType = billType;
    }

    public String getTotalCharges()
    {
        return totalCharges;
    }

    public void setTotalCharges(String totalCharges)
    {
        this.totalCharges = totalCharges;
    }

    public String getTaxCharges()
    {
        return taxCharges;
    }

    public void setTaxCharges(String taxCharges)
    {
        this.taxCharges = taxCharges;
    }

    public String getDiscount()
    {
        return discount;
    }

    public void setDiscount(String discount)
    {
        this.discount = discount;
    }

    public String getNetAmounts()
    {
        return netAmounts;
    }

    public void setNetAmounts(String netAmounts)
    {
        this.netAmounts = netAmounts;
    }

    private String period;
    private String search;
    private String search1;
    private String search2;
    private String billNo;
    private String billName;
    private String patientName;
    private String doctorName;
    private String caseType;
    private String billType;
    private String totalCharges;
    private String taxCharges;
    private String discount;
    private String netAmounts;
}
