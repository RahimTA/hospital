// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BedService.java

package com.aaqa.service;

import com.aaqa.dao.BedDAO;
import java.util.List;

public class BedService
{

    public BedService()
    {
    }

    public List getBedDetails()
    {
        List list = beddao.getAllBedDetails();
        return list;
    }

    public List getAvailableBedDetails()
    {
        List list = beddao.displayAvailableBeds();
        return list;
    }

    private BedDAO beddao;
}
