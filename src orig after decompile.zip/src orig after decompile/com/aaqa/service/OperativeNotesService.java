// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   OperativeNotesService.java

package com.aaqa.service;

import com.aaqa.dao.OperatvieNotesDao;
import com.aaqa.pojo.OperativeNotesPojo;

public class OperativeNotesService
{

    public OperativeNotesService()
    {
    }

    public void saveOperativeNotesDetails(OperativeNotesPojo operativeNotesPojo)
    {
        operatvieNotesDao.saveOperativeNotesDetails(operativeNotesPojo);
    }

    private OperatvieNotesDao operatvieNotesDao;
}
