// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   VisitDetailsService.java

package com.aaqa.service;

import com.aaqa.dao.AppointmentDAO;
import com.aaqa.dao.VisitDao;
import com.aaqa.pojo.CommonSearchPojo;
import com.aqaa.com.entity.*;
import java.util.List;

public class VisitDetailsService
{

    public VisitDetailsService()
    {
    }

    public List getDoctor()
    {
        List doctor = appointmentDAO.displayDoctorsList();
        return doctor;
    }

    public void savevisitcomplaints(VisitComplaintsEntity visitComplaints)
    {
        visitDao.savevisitcomplaints(visitComplaints);
    }

    public void saveVisitDetails(VisitEntity visit)
    {
        visitDao.saveVisitDetails(visit);
    }

    public void saveExternalMedication(MedicationEntity medicationEntity)
    {
        visitDao.saveExternalMedication(medicationEntity);
    }

    public void saveInternalMedication(MedicationEntity medicationEntity)
    {
        visitDao.saveInternalMedication(medicationEntity);
    }

    public List selectVisitPatientDetails()
    {
        List visitsearchlist = visitDao.selectVisitPatientDetails();
        return visitsearchlist;
    }

    public List selectVisitDetailsFilter(CommonSearchPojo pojo)
    {
        List visitList = visitDao.selectVisitDetailsFilter(pojo);
        return visitList;
    }

    private AppointmentDAO appointmentDAO;
    private VisitDao visitDao;
}
