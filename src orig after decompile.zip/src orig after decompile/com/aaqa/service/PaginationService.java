// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PaginationService.java

package com.aaqa.service;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class PaginationService
{

    public PaginationService()
    {
    }

    public void defaultPage(HttpServletRequest request)
    {
        List bigApptSearchList = (List)request.getSession().getAttribute("bigApptSearchList");
        List subApptSearchList = bigApptSearchList.subList(0, 5);
        String nextText = "1 TO 5>>";
        request.setAttribute("nextText", nextText);
        String preText = "FirstPage";
        request.setAttribute("preText", preText);
        request.setAttribute("firstPage", "yes");
        request.getSession().setAttribute("pagination", subApptSearchList);
        request.getSession().setAttribute("bigApptSearchList", bigApptSearchList);
        request.getSession().setAttribute("pageNo", Integer.valueOf(1));
    }

    public void paginationNext(HttpServletRequest request)
    {
        int pageNo = ((Integer)request.getSession().getAttribute("pageNo")).intValue();
        List bigApptSearchList = (List)request.getSession().getAttribute("bigApptSearchList");
        int startNo = (++pageNo - 1) * 5;
        int endNo = pageNo * 5;
        if(endNo > bigApptSearchList.size())
        {
            endNo = bigApptSearchList.size();
            request.setAttribute("lastPage", "yes");
        }
        List subApptSearchList = bigApptSearchList.subList(startNo, endNo);
        String preText = "<<Previous 5";
        request.setAttribute("preText", preText);
        String nextText = (new StringBuilder(String.valueOf(startNo))).append(" TO ").append(endNo).append(">>").toString();
        if(endNo == bigApptSearchList.size() && bigApptSearchList.size() % 5 == 0)
        {
            request.setAttribute("lastPage", "yes");
            nextText = "No More Records";
        }
        request.setAttribute("nextText", nextText);
        request.getSession().setAttribute("pageNo", Integer.valueOf(pageNo));
        request.getSession().setAttribute("pagination", subApptSearchList);
    }

    public void paginationPrivious(HttpServletRequest request)
    {
        int pageNo = ((Integer)request.getSession().getAttribute("pageNo")).intValue();
        pageNo--;
        List bigApptSearchList = (List)request.getSession().getAttribute("bigApptSearchList");
        int startNo = pageNo * 5;
        int endNo = (pageNo - 1) * 5;
        if(endNo < 1)
        {
            request.setAttribute("firstPage", "yes");
            endNo = 0;
        }
        if(endNo > bigApptSearchList.size())
        {
            endNo = bigApptSearchList.size();
            request.setAttribute("lastPage", "yes");
        }
        List subApptSearchList = bigApptSearchList.subList(endNo, startNo);
        if(endNo == 0)
            endNo = 1;
        String preText = (new StringBuilder("<<")).append(endNo).append(" TO ").append(startNo).toString();
        request.setAttribute("preText", preText);
        String nextText = ">>next 5";
        request.setAttribute("nextText", nextText);
        request.getSession().setAttribute("startNo", Integer.valueOf(startNo));
        request.getSession().setAttribute("endNo", Integer.valueOf(endNo));
        request.getSession().setAttribute("pageNo", Integer.valueOf(pageNo));
        request.getSession().setAttribute("pagination", subApptSearchList);
    }

    public void firstPage(HttpServletRequest request)
    {
        String nextText = "1 TO 5>>";
        request.setAttribute("nextText", nextText);
        String preText = "FirstPage";
        request.setAttribute("preText", preText);
        List bigApptSearchList = (List)request.getSession().getAttribute("bigApptSearchList");
        request.setAttribute("firstPage", "yes");
        List subApptSearchList = bigApptSearchList.subList(0, 5);
        request.getSession().setAttribute("pagination", subApptSearchList);
        request.getSession().setAttribute("pageNo", Integer.valueOf(1));
    }

    public void lastPage(HttpServletRequest request)
    {
        List bigApptSearchList = (List)request.getSession().getAttribute("bigApptSearchList");
        int startNo = bigApptSearchList.size() - 5;
        int endNo = bigApptSearchList.size();
        int remainder = endNo % 5;
        startNo = endNo - remainder;
        List subApptSearchList = bigApptSearchList.subList(startNo, endNo);
        int pageNo = endNo / 5;
        pageNo++;
        if(remainder == 0)
        {
            startNo = bigApptSearchList.size() - 5;
            subApptSearchList = bigApptSearchList.subList(startNo, endNo);
            pageNo--;
        }
        String nextText = "LastRecord";
        request.setAttribute("nextText", nextText);
        String preText = (new StringBuilder("<<")).append(startNo).append(" TO ").append(endNo).toString();
        request.setAttribute("preText", preText);
        request.setAttribute("lastPage", "yes");
        request.getSession().setAttribute("pagination", subApptSearchList);
        request.getSession().setAttribute("pageNo", Integer.valueOf(pageNo));
    }
}
