// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DischargeDetailsService.java

package com.aaqa.service;

import com.aaqa.dao.DischargeDetailsDao;
import com.aaqa.pojo.CommonSearchPojo;
import com.aaqa.pojo.DischargeDetailsPopupPojo;
import java.util.List;

public class DischargeDetailsService
{

    public DischargeDetailsService()
    {
    }

    public void setDischargeDetailsDao(DischargeDetailsDao dischargeDetailsDao)
    {
        this.dischargeDetailsDao = dischargeDetailsDao;
    }

    public void saveDischargeDetails(DischargeDetailsPopupPojo dischargeDetailsPopupPojo)
    {
        dischargeDetailsDao.saveDischargeDetails(dischargeDetailsPopupPojo);
    }

    public List dischargeSearchdisplayValues()
    {
        List list = dischargeDetailsDao.dischargeSearchdisplayValues();
        return list;
    }

    public List getAllOperationsAtHospitals()
    {
        List list = dischargeDetailsDao.getAllOperationsAtHospitals();
        return list;
    }

    public List getPatientName()
    {
        List plist = dischargeDetailsDao.getPatientName();
        return plist;
    }

    public List getAdmissionDate()
    {
        List testList = dischargeDetailsDao.getAdmissionDate();
        return testList;
    }

    public List getAllOtNos()
    {
        List otnolist = dischargeDetailsDao.getAllOtNos();
        return otnolist;
    }

    public List dischargeValuesdisplay()
    {
        List dischargeValueList = dischargeDetailsDao.dischargeValuesdisplay();
        return dischargeValueList;
    }

    public List getPatientDetailForDischarge()
    {
        List list = dischargeDetailsDao.getPatientDetailForDischarge();
        return list;
    }

    public List getDischargeDeatailsByFilter(CommonSearchPojo commonsearchpojo)
    {
        List searchlist = dischargeDetailsDao.getDischargeDeatailsByFilter(commonsearchpojo);
        return searchlist;
    }

    public DischargeDetailsPopupPojo editDischargeDetails(Integer disId)
    {
        DischargeDetailsPopupPojo pojo = dischargeDetailsDao.editDischargeDetails(disId);
        return pojo;
    }

    private DischargeDetailsDao dischargeDetailsDao;
}
