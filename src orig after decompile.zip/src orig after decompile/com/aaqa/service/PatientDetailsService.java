// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PatientDetailsService.java

package com.aaqa.service;

import com.aaqa.dao.PatientDAO;
import com.aaqa.pojo.*;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.List;

public class PatientDetailsService
{

    public PatientDetailsService()
    {
    }

    public List getMetaDetails(String metaName)
    {
        List list = patientDAO.getMetaDetails(metaName);
        return list;
    }

    public void saveDetails(PatientInfoPojo patientInfoPojo)
    {
        patientDAO.saveDetails(patientInfoPojo);
    }

    public List patientValuesdisplay()
    {
        List patienteValueList = patientDAO.patientValuesdisplay();
        return patienteValueList;
    }

    public List searchPatient(CommonSearchPojo commonSearchPojo)
    {
        List searchlist = patientDAO.searchPatient(commonSearchPojo);
        PatientSearchPojo patientSearchPojo;
        for(Iterator iterator = searchlist.iterator(); iterator.hasNext(); System.out.println((new StringBuilder("In service searchPatient..DEV....::")).append(patientSearchPojo.getPatientName()).toString()))
            patientSearchPojo = (PatientSearchPojo)iterator.next();

        return searchlist;
    }

    public List getPatientName()
    {
        List plist = patientDAO.getPatientName();
        return plist;
    }

    public PatientInfoPojo editPatientDetails(Integer id)
    {
        return patientDAO.editPatientDetails(id);
    }

    public PatientDAO patientDAO;
}
