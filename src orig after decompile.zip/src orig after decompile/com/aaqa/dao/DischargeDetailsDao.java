// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DischargeDetailsDao.java

package com.aaqa.dao;

import com.aaqa.pojo.*;
import com.aqaa.com.entity.PatientEntity;
import com.aqaa.com.entity.PersonEntity;
import com.aqaa.util.PeriodCommonLogic;
import java.io.PrintStream;
import java.util.*;
import org.hibernate.*;
import org.hibernate.criterion.*;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class DischargeDetailsDao
{

    public DischargeDetailsDao()
    {
    }

    public void setHibernatetemplate(HibernateTemplate hibernatetemplate)
    {
        hibernateTemplate = hibernatetemplate;
    }

    public void saveDischargeDetails(DischargeDetailsPopupPojo dischargeDetailsPopupPojo)
    {
        hibernateTemplate.saveOrUpdate(dischargeDetailsPopupPojo);
    }

    public List dischargeSearchdisplayValues()
    {
        String hql = "select ddpp.id, ddpp.pname, p.fname, ddpp.admitDate, ddpp.dischargeDate, ddpp.followUpDate from DischargeDetailsPopupPojo ddpp join ddpp.patientEntity pa join pa.personEntity pe join pa.doctorEntity dc join dc.person p";
        List list = hibernateTemplate.find(hql);
        List dischargeDetailslist = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            DischargeSearchPojo dischargeSearchPojo = new DischargeSearchPojo();
            Integer id = (Integer)((Object[])list.get(i))[0];
            String name = (String)((Object[])list.get(i))[1];
            String doctorname = (String)((Object[])list.get(i))[2];
            Date admissionDate = (Date)((Object[])list.get(i))[3];
            Date dischargedate = (Date)((Object[])list.get(i))[4];
            Date followupDate = (Date)((Object[])list.get(i))[5];
            dischargeSearchPojo.setDisId(id);
            dischargeSearchPojo.setPatientName(name);
            dischargeSearchPojo.setDoctorName(doctorname);
            dischargeSearchPojo.setAdmissionDate(admissionDate);
            dischargeSearchPojo.setDischargeDate(dischargedate);
            dischargeSearchPojo.setFollowupDate(followupDate);
            dischargeDetailslist.add(dischargeSearchPojo);
        }

        return dischargeDetailslist;
    }

    public List getAllOperationsAtHospitals()
    {
        return hibernateTemplate.find("from OperationAtMetaEntity");
    }

    public List getAllOtNos()
    {
        return hibernateTemplate.find("from OtNoMetaEntity");
    }

    public List getPatientName()
    {
        String hql = "select pt.id, pe.fname from PatientEntity pt join pt.personEntity pe join pt.dischargeDetailsPopupPojo ddsp";
        List list = hibernateTemplate.find(hql);
        List plist = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            PersonEntity personEntity = new PersonEntity();
            Integer id = (Integer)((Object[])list.get(i))[0];
            String name = (String)((Object[])list.get(i))[1];
            personEntity.setId(id);
            personEntity.setFname(name);
            plist.add(personEntity);
        }

        return plist;
    }

    public List getAdmissionDate()
    {
        String hql = "from AdmissionEntity";
        List testList = hibernateTemplate.find(hql);
        return testList;
    }

    public List dischargeValuesdisplay()
    {
        return hibernateTemplate.find("from DischargeSearchMetaEntity");
    }

    public List getPatientDetailForDischarge()
    {
        String hql = "select a.pid, a.name, a.admissionCode, a.admissionDate from AdmissionEntity a";
        List list = hibernateTemplate.find(hql);
        List plist = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            SelectAdmitPatientPojo selectAdmitPatientPojo = new SelectAdmitPatientPojo();
            String pid = (String)((Object[])list.get(i))[0];
            String name = (String)((Object[])list.get(i))[1];
            String code = (String)((Object[])list.get(i))[2];
            Date aDate = (Date)((Object[])list.get(i))[3];
            selectAdmitPatientPojo.setPid(pid);
            selectAdmitPatientPojo.setPname(name);
            selectAdmitPatientPojo.setAdmissioncode(code);
            selectAdmitPatientPojo.setAdmitDate(aDate);
            plist.add(selectAdmitPatientPojo);
        }

        return plist;
    }

    public List getDischargeDeatailsByFilter(CommonSearchPojo commonSearchPojo)
    {
        System.out.println("********************************** Filter controleer  **********************************");
        SessionFactory sf = hibernateTemplate.getSessionFactory();
        Session s = sf.openSession();
        Criteria ctr = s.createCriteria(com/aaqa/pojo/DischargeDetailsPopupPojo, "ddpp");
        ctr.createAlias("ddpp.patientEntity", "pa");
        ctr.createAlias("pa.personEntity", "pe");
        ctr.createAlias("pa.doctorEntity", "dc");
        ctr.createAlias("dc.person", "p");
        if(commonSearchPojo.getPeriod() != null && !commonSearchPojo.getPeriod().equals(""))
        {
            List dateList = PeriodCommonLogic.getPeriodDeatils(commonSearchPojo.getPeriod());
            if(dateList.size() == 2)
                ctr.add(Restrictions.between("ddpp.admitDate", dateList.get(0), dateList.get(1)));
            else
                ctr.add(Restrictions.eq("ddpp.admitDate", dateList.get(0)));
        }
        if(commonSearchPojo.getSearch() != null && !commonSearchPojo.getSearch().equals(""))
            if(commonSearchPojo.getSearch().intValue() == 1)
                ctr.add(Restrictions.eq("ddpp.pname", commonSearchPojo.getValue()));
            else
            if(commonSearchPojo.getSearch().intValue() == 2)
                ctr.add(Restrictions.eq("p.fname", commonSearchPojo.getValue()));
            else
            if(commonSearchPojo.getSearch().intValue() == 3)
            {
                System.out.println((new StringBuilder("The admit date is::::::::::::::::::::: ")).append(commonSearchPojo.getValue()).toString());
                ctr.add(Restrictions.eq("ddpp.admitDate", commonSearchPojo.getValue()));
            } else
            if(commonSearchPojo.getSearch().intValue() == 4)
                ctr.add(Restrictions.eq("ddpp.dischargeDate", commonSearchPojo.getValue()));
            else
            if(commonSearchPojo.getSearch().intValue() == 5)
                ctr.add(Restrictions.eq("ddpp.followUpDate", commonSearchPojo.getValue()));
        ProjectionList plist = Projections.projectionList();
        plist.add(Projections.property("ddpp.id"));
        plist.add(Projections.property("ddpp.pname"));
        plist.add(Projections.property("p.fname"));
        plist.add(Projections.property("ddpp.admitDate"));
        plist.add(Projections.property("ddpp.dischargeDate"));
        plist.add(Projections.property("ddpp.followUpDate"));
        ctr.setProjection(plist);
        List list = ctr.list();
        List tlist = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            DischargeSearchPojo dischargeSearchPojo = new DischargeSearchPojo();
            Integer id = (Integer)((Object[])list.get(i))[0];
            String name = (String)((Object[])list.get(i))[1];
            String doctorname = (String)((Object[])list.get(i))[2];
            Date admissionDate = (Date)((Object[])list.get(i))[3];
            Date dischargedate = (Date)((Object[])list.get(i))[4];
            Date followupDate = (Date)((Object[])list.get(i))[5];
            dischargeSearchPojo.setDisId(id);
            dischargeSearchPojo.setPatientName(name);
            dischargeSearchPojo.setDoctorName(doctorname);
            dischargeSearchPojo.setAdmissionDate(admissionDate);
            dischargeSearchPojo.setDischargeDate(dischargedate);
            dischargeSearchPojo.setFollowupDate(followupDate);
            tlist.add(dischargeSearchPojo);
        }

        System.out.println(tlist);
        s.close();
        return tlist;
    }

    public DischargeDetailsPopupPojo editDischargeDetails(Integer disId)
    {
        int id = disId.intValue();
        DischargeDetailsPopupPojo dPojo = null;
        List list = hibernateTemplate.find("select pa.id, ddpp.pname, ddpp.admitCode, ddpp.admitDate, ddpp.dischargeDate, ddpp.followUpDate, ddpp.finalDiagnosis, ddpp.conditionOfPatientDischarge, ddpp.hospitalNotes, ddpp.dischargeNotes, ddpp.criticalDetailsAtAdmission, ddpp.treatementGiven, ddpp.lab_investigation, ddpp.advice, ddpp.issueToBeFollowed, ddpp.id  from DischargeDetailsPopupPojo ddpp join ddpp.patientEntity pa join pa.personEntity pe join pa.doctorEntity dc join dc.person p where ddpp.id=?", Integer.valueOf(id));
        Integer dId;
        for(Iterator iterator = list.iterator(); iterator.hasNext(); dPojo.setId(dId))
        {
            Object objects[] = (Object[])iterator.next();
            dPojo = new DischargeDetailsPopupPojo();
            Integer pId = (Integer)objects[0];
            String pname = (String)objects[1];
            String admitCode = (String)objects[2];
            Date admitDate = (Date)objects[3];
            System.out.println((new StringBuilder("In Dao Admit date is: ")).append(admitDate).toString());
            Date dischargeDate = (Date)objects[4];
            System.out.println((new StringBuilder("In Dao Admit date is: ")).append(dischargeDate).toString());
            Date followUpDate = (Date)objects[5];
            String finalDiagnosis = (String)objects[6];
            String conditionOfPatientDischarge = (String)objects[7];
            String hospitalNotes = (String)objects[8];
            String dischargeNotes = (String)objects[9];
            String criticalDetailsAtAdmission = (String)objects[10];
            String treatementGiven = (String)objects[11];
            String lab_investigation = (String)objects[12];
            String advice = (String)objects[13];
            String issueToBeFollowed = (String)objects[14];
            dId = (Integer)objects[15];
            PatientEntity pa = new PatientEntity();
            pa.setId(pId);
            dPojo.setPatientEntity(pa);
            dPojo.setPname(pname);
            dPojo.setAdmitCode(admitCode);
            dPojo.setAdmitDate(admitDate);
            dPojo.setDischargeDate(dischargeDate);
            dPojo.setFollowUpDate(followUpDate);
            dPojo.setFinalDiagnosis(finalDiagnosis);
            dPojo.setConditionOfPatientDischarge(conditionOfPatientDischarge);
            dPojo.setHospitalNotes(hospitalNotes);
            dPojo.setDischargeNotes(dischargeNotes);
            dPojo.setCriticalDetailsAtAdmission(criticalDetailsAtAdmission);
            dPojo.setTreatementGiven(treatementGiven);
            dPojo.setLab_investigation(lab_investigation);
            dPojo.setAdvice(advice);
            dPojo.setIssueToBeFollowed(issueToBeFollowed);
        }

        return dPojo;
    }

    private HibernateTemplate hibernateTemplate;
}
