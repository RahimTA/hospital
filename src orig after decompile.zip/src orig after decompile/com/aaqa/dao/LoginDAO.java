// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LoginDAO.java

package com.aaqa.dao;

import com.aaqa.pojo.ForgotPasswordPojo;
import com.aaqa.pojo.LoginPojo;
import com.aqaa.com.entity.AddressEntity;
import java.io.PrintStream;
import java.sql.*;
import javax.sql.DataSource;

public class LoginDAO
{

    public LoginDAO()
    {
        ds = null;
    }

    public void setDs(DataSource ds)
    {
        this.ds = ds;
    }

    public LoginPojo login(LoginPojo pojo)
    {
        Connection con;
        PreparedStatement ps;
        LoginPojo pojo2;
        con = null;
        ps = null;
        ResultSet rs = null;
        pojo2 = null;
        try
        {
            con = ds.getConnection();
            ps = con.prepareStatement("select user,password,role,emailid from  login where user=? and password=?");
            int count = 1;
            ps.setString(count++, pojo.getUser());
            ps.setString(count++, pojo.getPassword());
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            {
                pojo2 = new LoginPojo();
                pojo2.setPassword(rs.getString("password"));
                pojo2.setUser(rs.getString("user"));
                pojo2.setRole(rs.getString("role"));
                pojo2.setEmailId(rs.getString("emailid"));
            }
            break MISSING_BLOCK_LABEL_223;
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        try
        {
            if(ps != null)
                ps.close();
            if(con != null)
                con.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        break MISSING_BLOCK_LABEL_253;
        Exception exception;
        exception;
        try
        {
            if(ps != null)
                ps.close();
            if(con != null)
                con.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        throw exception;
        try
        {
            if(ps != null)
                ps.close();
            if(con != null)
                con.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        return pojo2;
    }

    public AddressEntity area()
    {
        Connection con;
        PreparedStatement ps;
        AddressEntity aepojo;
        con = null;
        ps = null;
        ResultSet rs = null;
        aepojo = null;
        try
        {
            con = ds.getConnection();
            ps = con.prepareStatement("select add2 from address where id=?");
            ps.setInt(1, 10);
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            {
                aepojo = new AddressEntity();
                String add = rs.getString("Add2");
                System.out.println(add);
                aepojo.setAdd2(add);
            }
            break MISSING_BLOCK_LABEL_165;
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        try
        {
            if(ps != null)
                ps.close();
            if(con != null)
                con.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        break MISSING_BLOCK_LABEL_195;
        Exception exception;
        exception;
        try
        {
            if(ps != null)
                ps.close();
            if(con != null)
                con.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        throw exception;
        try
        {
            if(ps != null)
                ps.close();
            if(con != null)
                con.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        return aepojo;
    }

    public LoginPojo checkUser(ForgotPasswordPojo forgotpojo)
    {
        Connection con;
        PreparedStatement ps;
        LoginPojo pojo2;
        con = null;
        ps = null;
        ResultSet rs = null;
        pojo2 = null;
        try
        {
            con = ds.getConnection();
            ps = con.prepareStatement("select user,password,role,emailid from  login where user=? and emailid=?");
            int count = 1;
            ps.setString(count++, forgotpojo.getUsername());
            ps.setString(count++, forgotpojo.getEmail());
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            {
                pojo2 = new LoginPojo();
                pojo2.setEmailId(rs.getString("emailid"));
                pojo2.setPassword(rs.getString("password"));
            }
            break MISSING_BLOCK_LABEL_195;
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        try
        {
            if(ps != null)
                ps.close();
            if(con != null)
                con.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        break MISSING_BLOCK_LABEL_225;
        Exception exception;
        exception;
        try
        {
            if(ps != null)
                ps.close();
            if(con != null)
                con.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        throw exception;
        try
        {
            if(ps != null)
                ps.close();
            if(con != null)
                con.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        return pojo2;
    }

    private DataSource ds;
}
