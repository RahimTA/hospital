// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ConsentDAO.java

package com.aaqa.dao;

import com.aaqa.pojo.ConsentFormPopupPojo;
import com.aaqa.pojo.ConsentMasterPopupPojo;
import java.util.*;
import org.hibernate.*;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class ConsentDAO
{

    public ConsentDAO()
    {
    }

    public void setHibernatetemplate(HibernateTemplate hibernatetemplate)
    {
        this.hibernatetemplate = hibernatetemplate;
    }

    public void saveDetails(ConsentMasterPopupPojo cmpojo)
    {
        hibernatetemplate.saveOrUpdate(cmpojo);
    }

    public void saveformDetails(ConsentFormPopupPojo cfpojo)
    {
        hibernatetemplate.saveOrUpdate(cfpojo);
    }

    public List getConsantMaster(ConsentMasterPopupPojo consentmaster)
    {
        List list = null;
        SessionFactory sf = hibernatetemplate.getSessionFactory();
        Session s = sf.openSession();
        Criteria ctr = s.createCriteria(com/aaqa/pojo/ConsentMasterPopupPojo);
        if(consentmaster.getName() != null && !consentmaster.getName().trim().equals(""))
            ctr.add(Restrictions.eq("name", consentmaster.getName()));
        list = ctr.list();
        s.close();
        return list;
    }

    public List getConsantMasters()
    {
        String hql = "from ConsentMasterPopupPojo cm";
        return hibernatetemplate.find(hql);
    }

    public List getAllConsents(ConsentFormPopupPojo consentform)
    {
        List list = null;
        SessionFactory sf = hibernatetemplate.getSessionFactory();
        Session s = sf.openSession();
        Criteria ctr = s.createCriteria(com/aaqa/pojo/ConsentFormPopupPojo);
        if(consentform.getDate() != null && !consentform.getDate().equals(""))
            ctr.add(Restrictions.eq("date", consentform.getDate()));
        if(consentform.getPatientid() != null && !consentform.getPatientid().equals(""))
            ctr.add(Restrictions.eq("patientid", consentform.getPatientid()));
        if(consentform.getName() != null && !consentform.getName().trim().equals(""))
            ctr.add(Restrictions.eq("name", consentform.getName()));
        if(consentform.getConsentname() != null && !consentform.getConsentname().trim().equals(""))
            ctr.add(Restrictions.eq("consentname", consentform.getConsentname()));
        list = ctr.list();
        s.close();
        return list;
    }

    public List getConsantMasterDetails(ConsentMasterPopupPojo pojo)
    {
        List list = hibernatetemplate.find("select cm.name, cm.description,cm.id from ConsentMasterPopupPojo cm");
        List consentPojoList = new ArrayList();
        ConsentMasterPopupPojo cpojo;
        for(Iterator iterator = list.iterator(); iterator.hasNext(); consentPojoList.add(cpojo))
        {
            Object objects[] = (Object[])iterator.next();
            String name = (String)objects[0];
            String des = (String)objects[1];
            Integer cmid = (Integer)objects[2];
            cpojo = new ConsentMasterPopupPojo();
            cpojo.setName(name);
            cpojo.setDescription(des);
            cpojo.setId(cmid);
        }

        return consentPojoList;
    }

    public List getAllConsent(ConsentFormPopupPojo pojo)
    {
        List list = hibernatetemplate.find("select cf.date,cf.cmid,cf.name,cf.patientid,cf.consentname,cf.id from ConsentFormPopupPojo cf");
        List consentPojo = new ArrayList();
        ConsentFormPopupPojo cfpojo;
        for(Iterator iterator = list.iterator(); iterator.hasNext(); consentPojo.add(cfpojo))
        {
            Object objects[] = (Object[])iterator.next();
            Date date = (Date)objects[0];
            Integer cid = (Integer)objects[1];
            String name = (String)objects[2];
            Integer pid = (Integer)objects[3];
            String cname = (String)objects[4];
            Integer cfid = (Integer)objects[5];
            cfpojo = new ConsentFormPopupPojo();
            cfpojo.setDate(date);
            cfpojo.setCmid(cid);
            cfpojo.setName(name);
            cfpojo.setPatientid(pid);
            cfpojo.setConsentname(cname);
            cfpojo.setId(cfid);
        }

        return consentPojo;
    }

    public ConsentMasterPopupPojo editConsentMasterDetails(Integer id)
    {
        ConsentMasterPopupPojo cmPojo = null;
        List list = hibernatetemplate.find("select cm.name,cm.description,cm.id from ConsentMasterPopupPojo cm where cm.id=?", id);
        Integer cmid;
        for(Iterator iterator = list.iterator(); iterator.hasNext(); cmPojo.setId(cmid))
        {
            Object objects[] = (Object[])iterator.next();
            String cname = (String)objects[0];
            String des = (String)objects[1];
            cmid = (Integer)objects[2];
            cmPojo = new ConsentMasterPopupPojo();
            cmPojo.setName(cname);
            cmPojo.setDescription(des);
        }

        return cmPojo;
    }

    public ConsentFormPopupPojo editConsenDetails(Integer id)
    {
        ConsentFormPopupPojo cfPojo = null;
        List list = hibernatetemplate.find("select cf.date,cf.cmid,cf.name,cf.patientid,cf.consentname,cf.description,cf.id from ConsentFormPopupPojo cf where cf.id=?", id);
        Integer cfid;
        for(Iterator iterator = list.iterator(); iterator.hasNext(); cfPojo.setId(cfid))
        {
            Object objects[] = (Object[])iterator.next();
            Date date = (Date)objects[0];
            Integer cmid = (Integer)objects[1];
            String pname = (String)objects[2];
            Integer pid = (Integer)objects[3];
            String cname = (String)objects[4];
            String des = (String)objects[5];
            cfid = (Integer)objects[6];
            cfPojo = new ConsentFormPopupPojo();
            cfPojo.setDate(date);
            cfPojo.setCmid(cmid);
            cfPojo.setName(pname);
            cfPojo.setPatientid(pid);
            cfPojo.setConsentname(cname);
            cfPojo.setDescription(des);
        }

        return cfPojo;
    }

    public List getconsentMastersDetails()
    {
        String hql = "from ConsentMasterPopupPojo cm";
        return hibernatetemplate.find(hql);
    }

    private HibernateTemplate hibernatetemplate;
}
