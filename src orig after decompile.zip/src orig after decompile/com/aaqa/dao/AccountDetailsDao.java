// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AccountDetailsDao.java

package com.aaqa.dao;

import com.aaqa.pojo.AccountBillingDetailsPojo;
import com.aaqa.pojo.SelectPatientPojo;
import com.aqaa.com.entity.PersonEntity;
import java.util.ArrayList;
import java.util.List;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class AccountDetailsDao
{

    public AccountDetailsDao()
    {
    }

    public void saveAccountBillingDetails(AccountBillingDetailsPojo accountBillingDetailsPojo)
    {
        com.aqaa.com.entity.AccountBillingDetailsEntity abde = accountBillingDetailsPojo.getAbde();
        hibernateTemplate.save(abde);
    }

    public List getPatientDetailForTest()
    {
        String hql = "select pt.id, pe.fname, ct.phoneNo from PersonEntity pe join pe.patientEntity pt join pe.contactEntities ct";
        List list = hibernateTemplate.find(hql);
        List plist = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            SelectPatientPojo selectPatientPojo = new SelectPatientPojo();
            Integer id = (Integer)((Object[])list.get(i))[0];
            String name = (String)((Object[])list.get(i))[1];
            String contactno = (String)((Object[])list.get(i))[2];
            selectPatientPojo.setId(id);
            selectPatientPojo.setName(name);
            selectPatientPojo.setPhoneNo(contactno);
            plist.add(selectPatientPojo);
        }

        return plist;
    }

    public List displayDoctorsList()
    {
        List list = hibernateTemplate.find("select dct.id, pe.fname from DoctorEntity dct join dct.person pe");
        List doctorsList = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            PersonEntity doctor = new PersonEntity();
            Integer doctorId = (Integer)((Object[])list.get(i))[0];
            String doctorName = (String)((Object[])list.get(i))[1];
            doctor.setId(doctorId);
            doctor.setFname(doctorName);
            doctorsList.add(doctor);
        }

        return doctorsList;
    }

    public List getAccountBillingDetails()
    {
        List billingList = hibernateTemplate.find("from AccountBillingDetailsEntity");
        return billingList;
    }

    private HibernateTemplate hibernateTemplate;
}
