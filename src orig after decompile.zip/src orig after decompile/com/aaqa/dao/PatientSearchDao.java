// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PatientSearchDao.java

package com.aaqa.dao;

import com.aaqa.pojo.PatientSearchPojo;
import com.aqaa.com.entity.*;
import com.aqaa.util.AgeCalculation;
import java.util.*;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class PatientSearchDao
{

    public PatientSearchDao()
    {
    }

    public void setHibernatetemplate(HibernateTemplate hibernatetemplate)
    {
        this.hibernatetemplate = hibernatetemplate;
    }

    public List getPatientSearchDetails()
    {
        String hql = "select pa.id,pe.fname,pe.dob,pe.gender,pa.regisdate ,ad.city,pa.occupation  from PersonEntity pe join pe.patientEntity pa join pe.addressEntity ad";
        List list = hibernatetemplate.find(hql);
        List patientSearchList = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            PatientSearchPojo patientSearchPojo = new PatientSearchPojo();
            Integer id = (Integer)((Object[])list.get(i))[0];
            String name = (String)((Object[])list.get(i))[1];
            Date dob = (Date)((Object[])list.get(i))[2];
            int age = AgeCalculation.getPersonAge(dob);
            GenderMetaEntity gender = (GenderMetaEntity)((Object[])list.get(i))[3];
            Date regisdate = (Date)((Object[])list.get(i))[4];
            CityMetaEntity city = (CityMetaEntity)((Object[])list.get(i))[5];
            OcupationMeta occupation = (OcupationMeta)((Object[])list.get(i))[6];
            patientSearchPojo.setId(id);
            patientSearchPojo.setPatientName(name);
            patientSearchPojo.setAge(age);
            patientSearchPojo.setGender(gender.getDesc());
            patientSearchPojo.setRegistrationDate(regisdate);
            patientSearchPojo.setCity(city.getDesc());
            patientSearchPojo.setOccupation(occupation.getDesc());
            patientSearchList.add(patientSearchPojo);
        }

        return patientSearchList;
    }

    public PatientSearchPojo getPatientSearchDetailsById(Integer id1)
    {
        PatientSearchPojo patientSearchPojo = null;
        List list = hibernatetemplate.find("select pa.id,pe.fname,pe.dob,pe.gender,pa.regisdate ,ad.city,pa.occupation  from PersonEntity pe join pe.patientEntity pa join pe.addressEntity ad where pa.id=?", id1);
        List patientSearchList = new ArrayList();
        OcupationMeta occupation;
        for(Iterator iterator = list.iterator(); iterator.hasNext(); patientSearchPojo.setOccupation(occupation.getDesc()))
        {
            Object objects[] = (Object[])iterator.next();
            Integer id = (Integer)objects[0];
            String name = (String)objects[1];
            Date dob = (Date)objects[2];
            int age = AgeCalculation.getPersonAge(dob);
            GenderMetaEntity gender = (GenderMetaEntity)objects[3];
            Date regisdate = (Date)objects[4];
            CityMetaEntity city = (CityMetaEntity)objects[5];
            occupation = (OcupationMeta)objects[6];
            patientSearchPojo = new PatientSearchPojo();
            patientSearchPojo.setPatientId(id1);
            patientSearchPojo.setId(id1);
            patientSearchPojo.setPatientName(name);
            patientSearchPojo.setAge(age);
            patientSearchPojo.setGender(gender.getDesc());
            patientSearchPojo.setRegistrationDate(regisdate);
            patientSearchPojo.setCity(city.getDesc());
        }

        return patientSearchPojo;
    }

    private HibernateTemplate hibernatetemplate;
}
