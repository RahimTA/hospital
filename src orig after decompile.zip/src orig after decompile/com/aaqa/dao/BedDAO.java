// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BedDAO.java

package com.aaqa.dao;

import com.aqaa.com.entity.BedEntity;
import com.aqaa.com.entity.BedMetaEntity;
import java.util.*;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class BedDAO
{

    public BedDAO()
    {
    }

    public void setHibernatetemplate(HibernateTemplate hibernatetemplate)
    {
        this.hibernatetemplate = hibernatetemplate;
    }

    public List getAllBedDetails()
    {
        List list = hibernatetemplate.find("select bed.id,be.startDate,be.patientId from BedEntity be  join be.bedNo bed where endDate=null ");
        List bedList = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            BedEntity pojo = new BedEntity();
            BedMetaEntity bedMetaEntity = new BedMetaEntity();
            bedMetaEntity.setId((Integer)((Object[])list.get(i))[0]);
            pojo.setBedNo(bedMetaEntity);
            pojo.setStartDate((Date)((Object[])list.get(i))[1]);
            pojo.setPatientId((String)((Object[])list.get(i))[2]);
            bedList.add(pojo);
        }

        return bedList;
    }

    public List displayAvailableBeds()
    {
        List list = hibernatetemplate.find("select bed.id from BedEntity be  join be.bedNo bed where endDate=endDate");
        List bedList = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            BedEntity pojo = new BedEntity();
            BedMetaEntity bedMetaEntity = new BedMetaEntity();
            bedMetaEntity.setId((Integer)list.get(i));
            pojo.setBedNo(bedMetaEntity);
            bedList.add(pojo);
        }

        return bedList;
    }

    private HibernateTemplate hibernatetemplate;
}
