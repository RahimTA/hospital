// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   VisitDao.java

package com.aaqa.dao;

import com.aaqa.pojo.CommonSearchPojo;
import com.aaqa.pojo.VisitSearchPojo;
import com.aqaa.com.entity.*;
import com.aqaa.util.PeriodCommonLogic;
import java.util.*;
import org.hibernate.*;
import org.hibernate.criterion.*;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class VisitDao
{

    public VisitDao()
    {
    }

    public void setHibernatetemplate(HibernateTemplate hibernatetemplate)
    {
        this.hibernatetemplate = hibernatetemplate;
    }

    public void saveVisitDetails(VisitEntity visit)
    {
        hibernatetemplate.save(visit);
    }

    public void savevisitcomplaints(VisitComplaintsEntity visitComplaints)
    {
        hibernatetemplate.save(visitComplaints);
    }

    public void saveExternalMedication(MedicationEntity medicationEntity)
    {
        medicationEntity.setExternalorInternal("External");
        hibernatetemplate.save(medicationEntity);
    }

    public void saveInternalMedication(MedicationEntity medicationEntity)
    {
        medicationEntity.setExternalorInternal("Internal");
        hibernatetemplate.save(medicationEntity);
    }

    public List selectVisitPatientDetails()
    {
        List list = hibernatetemplate.find("select v.id,v.date,v.time,pr.fname,pr.dob,g.desc,c.phoneNo from VisitEntity v join v.patientId pt join pt.personEntity pr join pr.contactEntities c join pr.gender g");
        List visitsearchlist = new ArrayList();
        VisitSearchPojo pojo;
        for(Iterator iterator = list.iterator(); iterator.hasNext(); visitsearchlist.add(pojo))
        {
            Object objects[] = (Object[])iterator.next();
            Integer id = (Integer)objects[0];
            Date visitDate = (Date)objects[1];
            Date visit = (Date)objects[2];
            String visitTime = visit.toString();
            String patientName = (String)objects[3];
            Date dob1 = (Date)objects[4];
            String dob = dob1.toString();
            String gender = (String)objects[5];
            String city = (String)objects[6];
            String date1 = visitTime;
            pojo = new VisitSearchPojo();
            pojo.setVisitId(id);
            pojo.setVisitDate(visitDate);
            pojo.setVisitTime(visitTime);
            pojo.setPatientName(patientName);
            pojo.setDob(dob);
            pojo.setGender(gender);
            pojo.setCity(city);
        }

        return visitsearchlist;
    }

    public void getVisitEditDetails(String s)
    {
    }

    public List selectVisitDetailsFilter(CommonSearchPojo pojo)
    {
        Session session = hibernatetemplate.getSessionFactory().openSession();
        Criteria criteria = session.createCriteria(com/aqaa/com/entity/VisitEntity, "visit");
        criteria.createAlias("visit.patientId", "pt");
        criteria.createAlias("pt.doctorEntity", "doc");
        criteria.createAlias("doc.person", "dpr");
        criteria.createAlias("pt.personEntity", "pr");
        criteria.createAlias("pr.contactEntities", "c");
        criteria.createAlias("pr.gender", "g");
        if(pojo.getPeriod() != null && !pojo.getPeriod().equals(""))
        {
            List dateList = PeriodCommonLogic.getPeriodDeatils(pojo.getPeriod());
            if(dateList.size() == 2)
                criteria.add(Restrictions.between("visit.date", dateList.get(0), dateList.get(1)));
            else
                criteria.add(Restrictions.eq("visit.date", dateList.get(0)));
        }
        if(pojo.getSearch() != null && !pojo.getSearch().equals("") && pojo.getValue() != null && !pojo.getValue().equals(""))
            if(pojo.getSearch().intValue() == 1 || pojo.getSearch().equals(Integer.valueOf(1)))
                criteria.add(Restrictions.eq("visit.date", pojo.getValue()));
            else
            if(pojo.getSearch().intValue() == 2 || pojo.getSearch().equals(Integer.valueOf(2)))
                criteria.add(Restrictions.eq("visit.time", pojo.getValue()));
            else
            if(pojo.getSearch().intValue() == 3 || pojo.getSearch().equals(Integer.valueOf(3)))
                criteria.add(Restrictions.eq("pr.fname", pojo.getValue()));
            else
            if(pojo.getSearch().intValue() == 4 || pojo.getSearch().equals(Integer.valueOf(4)))
                criteria.add(Restrictions.eq("pr.dob", pojo.getValue()));
            else
            if(pojo.getSearch().intValue() == 5 || pojo.getSearch().equals(Integer.valueOf(5)))
                criteria.add(Restrictions.eq("g.desc", pojo.getValue()));
            else
            if(pojo.getSearch().intValue() == 5 || pojo.getSearch().equals(Integer.valueOf(5)))
                criteria.add(Restrictions.eq("c.phoneNo", pojo.getValue()));
            else
            if(pojo.getSearch().intValue() == 6 || pojo.getSearch().equals(Integer.valueOf(6)))
                criteria.add(Restrictions.eq("dpr.fname", pojo.getValue()));
        ProjectionList proList = Projections.projectionList();
        proList.add(Projections.property("visit.id"));
        proList.add(Projections.property("visit.date"));
        proList.add(Projections.property("visit.time"));
        proList.add(Projections.property("pr.fname"));
        proList.add(Projections.property("pr.dob"));
        proList.add(Projections.property("g.desc"));
        proList.add(Projections.property("c.phoneNo"));
        criteria.setProjection(proList);
        List list = criteria.list();
        List visitList = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            Integer visitId = (Integer)((Object[])list.get(i))[0];
            Date visitDate = (Date)((Object[])list.get(i))[1];
            Date visitTime1 = (Date)((Object[])list.get(i))[2];
            String visitTime = visitTime1.toString();
            String patientName = (String)((Object[])list.get(i))[3];
            Date dob1 = (Date)((Object[])list.get(i))[4];
            String dob = dob1.toString();
            String gender = (String)((Object[])list.get(i))[5];
            String city = (String)((Object[])list.get(i))[6];
            VisitSearchPojo visitPojo = new VisitSearchPojo();
            visitPojo.setVisitId(visitId);
            visitPojo.setVisitDate(visitDate);
            visitPojo.setVisitTime(visitTime);
            visitPojo.setPatientName(patientName);
            visitPojo.setDob(dob);
            visitPojo.setGender(gender);
            visitPojo.setCity(city);
            visitList.add(visitPojo);
        }

        session.close();
        return visitList;
    }

    private HibernateTemplate hibernatetemplate;
}
