// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AppointmentDAO.java

package com.aaqa.dao;

import com.aaqa.pojo.*;
import com.aqaa.com.entity.*;
import com.aqaa.util.PeriodCommonLogic;
import java.io.PrintStream;
import java.util.*;
import org.apache.log4j.Logger;
import org.hibernate.*;
import org.hibernate.criterion.*;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class AppointmentDAO
{

    public AppointmentDAO()
    {
        logger = Logger.getLogger(com/aaqa/dao/AppointmentDAO);
    }

    public void setHibernatetemplate(HibernateTemplate hibernatetemplate)
    {
        this.hibernatetemplate = hibernatetemplate;
    }

    public List displayDoctorsList()
    {
        List list = hibernatetemplate.find("select dct.id, pe.fname from DoctorEntity dct join dct.person pe");
        List doctorsList = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            PersonEntity doctor = new PersonEntity();
            Integer doctorId = (Integer)((Object[])list.get(i))[0];
            String doctorName = (String)((Object[])list.get(i))[1];
            System.out.println(doctorId);
            System.out.println(doctorName);
            doctor.setId(doctorId);
            doctor.setFname(doctorName);
            doctorsList.add(doctor);
        }

        return doctorsList;
    }

    public void saveAppointmentDetails(AppointmentPopupPojo pojo)
    {
        PatientEntity patientEntity = pojo.getPatientEntity();
        AppointmentEntity appointmentEntity = pojo.getAppointmentEntity();
        DoctorEntity doctorEntity = pojo.getDoctorEntity();
        appointmentEntity.setPatientEntity(patientEntity);
        appointmentEntity.setDoctorEntity(doctorEntity);
        hibernatetemplate.saveOrUpdate(appointmentEntity);
    }

    public List displayPeriodDeatials()
    {
        return hibernatetemplate.find("from PeriodEntity");
    }

    public List displayAppmtStatusDeatils()
    {
        return hibernatetemplate.find("from AppointmentStatusMetaEntity");
    }

    public List getAppointmentDetails(CommonSearchPojo pojo)
    {
        List list = hibernatetemplate.find("select appt.id, appt.date, pe.fname, appst.desc, per.fname from AppointmentEntity appt  join appt.patientEntity pt join pt.personEntity pe join appt.doctorEntity dt join dt.person per join appt.appointmentStatus appst");
        List apptPojoList = new ArrayList();
        AppointmentSearchPojo apptPojo;
        for(Iterator iterator = list.iterator(); iterator.hasNext(); apptPojoList.add(apptPojo))
        {
            Object objects[] = (Object[])iterator.next();
            Integer appId = (Integer)objects[0];
            Date appDate = (Date)objects[1];
            String patientName = (String)objects[2];
            String apptStatus = (String)objects[3];
            String doctorName = (String)objects[4];
            apptPojo = new AppointmentSearchPojo();
            apptPojo.setAppId(appId);
            apptPojo.setAppointmentDate(appDate);
            apptPojo.setPatientName(patientName);
            apptPojo.setAppStatus(apptStatus);
            apptPojo.setDoctorName(doctorName);
        }

        return apptPojoList;
    }

    public List getApptDeatailsByFilter(CommonSearchPojo pojo)
    {
        Session session = hibernatetemplate.getSessionFactory().openSession();
        Criteria criteria = session.createCriteria(com/aqaa/com/entity/AppointmentEntity, "appt");
        criteria.createAlias("appt.patientEntity", "pt");
        criteria.createAlias("pt.personEntity", "pe");
        criteria.createAlias("appt.doctorEntity", "dt");
        criteria.createAlias("dt.person", "per");
        criteria.createAlias("appt.appointmentStatus", "appst");
        if(pojo.getPeriod() != null && !pojo.getPeriod().equals(""))
        {
            List dateList = PeriodCommonLogic.getPeriodDeatils(pojo.getPeriod());
            if(dateList.size() == 2)
            {
                System.out.println((new StringBuilder()).append(dateList.get(0)).append("============").append(dateList.get(1)).toString());
                criteria.add(Restrictions.between("appt.date", dateList.get(0), dateList.get(1)));
            } else
            {
                System.out.println((new StringBuilder()).append(dateList.get(0)).append("============").toString());
                criteria.add(Restrictions.eq("appt.date", dateList.get(0)));
            }
        }
        if(pojo.getSearch() != null && !pojo.getSearch().equals(""))
            criteria.add(Restrictions.eq("dt.id", pojo.getSearch()));
        if(pojo.getSearch2() != null && !pojo.getSearch2().equals(""))
            criteria.add(Restrictions.eq("appst.id", pojo.getSearch2()));
        ProjectionList proList = Projections.projectionList();
        proList.add(Projections.property("appt.id"));
        proList.add(Projections.property("appt.date"));
        proList.add(Projections.property("pe.fname"));
        proList.add(Projections.property("appst.desc"));
        proList.add(Projections.property("per.fname"));
        criteria.setProjection(proList);
        List list = criteria.list();
        List appList = new ArrayList();
        for(int i = 0; i < list.size(); i++)
        {
            Integer id = (Integer)((Object[])list.get(i))[0];
            Date date = (Date)((Object[])list.get(i))[1];
            String ptName = (String)((Object[])list.get(i))[2];
            String apptStatus = (String)((Object[])list.get(i))[3];
            String doctorName = (String)((Object[])list.get(i))[4];
            AppointmentSearchPojo appPojo = new AppointmentSearchPojo();
            appPojo.setAppId(id);
            appPojo.setAppointmentDate(date);
            appPojo.setPatientName(ptName);
            appPojo.setAppStatus(apptStatus);
            appPojo.setDoctorName(doctorName);
            appList.add(appPojo);
        }

        session.close();
        return appList;
    }

    public AppointmentPopupPojo editAppointmentDetails(Integer id)
    {
        AppointmentPopupPojo apptPojo = null;
        List list = hibernatetemplate.find("select pt.id, apptst, aptfor, dt, appt.date, appt.id from AppointmentEntity appt join appt.patientEntity pt join appt.appointmentStatus apptst join appt.appointmentForEntity aptfor join appt.doctorEntity dt where appt.id=?", id);
        PatientEntity ptEntity;
        for(Iterator iterator = list.iterator(); iterator.hasNext(); apptPojo.setPatientEntity(ptEntity))
        {
            Object objects[] = (Object[])iterator.next();
            Integer ptId = (Integer)objects[0];
            AppointmentStatusMetaEntity apptStatusMetaEntity = (AppointmentStatusMetaEntity)objects[1];
            AppointmentForEntity apptForEntity = (AppointmentForEntity)objects[2];
            DoctorEntity doctorEntity = (DoctorEntity)objects[3];
            Date apptDate = (Date)objects[4];
            Integer apptId = (Integer)objects[5];
            apptPojo = new AppointmentPopupPojo();
            AppointmentEntity apptEntity = new AppointmentEntity();
            ptEntity = new PatientEntity();
            ptEntity.setId(ptId);
            apptEntity.setAppointmentForEntity(apptForEntity);
            apptEntity.setAppointmentStatus(apptStatusMetaEntity);
            logger.fatal((new StringBuilder("The date before call setDate()..::^^^^::")).append(apptDate).toString());
            apptEntity.setDate(apptDate);
            apptEntity.setId(apptId);
            apptPojo.setAppointmentEntity(apptEntity);
            apptPojo.setDoctorEntity(doctorEntity);
        }

        return apptPojo;
    }

    Logger logger;
    private HibernateTemplate hibernatetemplate;
}
