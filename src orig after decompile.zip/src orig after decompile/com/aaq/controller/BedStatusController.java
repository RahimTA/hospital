// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BedStatusController.java

package com.aaq.controller;

import com.aaqa.service.BedService;
import com.aqaa.com.entity.BedEntity;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;

public class BedStatusController
{

    public BedStatusController()
    {
    }

    public ModelAndView displayBedDetails(BedEntity bpojo, HttpServletRequest request)
    {
        java.util.List list = bservice.getBedDetails();
        request.getSession().setAttribute("list", list);
        return new ModelAndView("bedStatus", "pojo", new BedEntity());
    }

    public ModelAndView displayAvailableBeds(BedEntity bpojo, HttpServletRequest request)
    {
        java.util.List list = bservice.getAvailableBedDetails();
        request.getSession().setAttribute("list", list);
        return new ModelAndView("bedAvailable", "pojo", new BedEntity());
    }

    private BedService bservice;
}
