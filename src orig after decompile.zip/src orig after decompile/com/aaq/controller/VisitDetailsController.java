// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   VisitDetailsController.java

package com.aaq.controller;

import com.aaqa.pojo.*;
import com.aaqa.service.PatientDetailsService;
import com.aaqa.service.VisitDetailsService;
import com.aqaa.com.entity.*;
import java.io.PrintStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;

public class VisitDetailsController
{

    public VisitDetailsController()
    {
    }

    public ModelAndView displayPatientDetails(CommonSearchPojo pojo, HttpServletRequest request)
    {
        java.util.List visitsearchlist = visitDetailsService.selectVisitPatientDetails();
        request.setAttribute("visitlist", visitsearchlist);
        return new ModelAndView("visitDetails", "commonsearchpojo", new CommonSearchPojo());
    }

    public String displayvisistdetailstabpopup(HttpServletRequest request)
    {
        java.util.List doctor = visitDetailsService.getDoctor();
        request.getSession().setAttribute("visitdetailspopup", new VisitEntity());
        request.setAttribute("visitdetailspopup", new VisitEntity());
        request.setAttribute("visitcomplaints", new VisitComplaintsEntity());
        request.setAttribute("externalmedication", new ExternalMedicationPojo());
        request.setAttribute("internalmedication", new InternalMedicationPojo());
        request.setAttribute("doctor", doctor);
        return "displayvisistdetailspopup";
    }

    public String displayexternalmedicationpopup(HttpServletRequest request)
    {
        request.setAttribute("externalmedication", new ExternalMedicationPojo());
        return "displayexternalmedicationpopup";
    }

    public String displayinternalmedicationpopup(HttpServletRequest request)
    {
        request.setAttribute("internalmedication", new ExternalMedicationPojo());
        return "displayinternalmedicationpopup";
    }

    public String displaybilldetailspopup(HttpServletRequest request)
    {
        request.setAttribute("billdetails", new BillDetailsPojo());
        return "displaybilldetailspopup";
    }

    public String saveVisitDetails(VisitEntity visit, HttpServletRequest request)
    {
        System.out.println(visit.getPatientId());
        visitDetailsService.saveVisitDetails(visit);
        request.getSession().setAttribute("visitdetailspopup", visit);
        request.setAttribute("visitdetailspopup", visit);
        request.setAttribute("visitcomplaints", new VisitComplaintsEntity());
        return "displayvisistdetailspopup";
    }

    public ModelAndView displayVisitSelectpatientSubpopup(CommonSearchPojo pojo, HttpServletRequest request)
    {
        request.setAttribute("pojo", new CommonSearchPojo());
        java.util.List patientlist = patientService.searchPatient(pojo);
        request.getSession().setAttribute("patientlist", patientlist);
        return new ModelAndView("SelectPatientDetailsForVisit");
    }

    public String savevisitcomplaints(VisitComplaintsEntity visitComplaints, HttpServletRequest request)
    {
        visitDetailsService.savevisitcomplaints(visitComplaints);
        request.setAttribute("visitcomplaints", new VisitComplaintsEntity());
        return "displayvisistdetailspopup";
    }

    public String saveExternalMedication(HttpServletRequest request, MedicationEntity medicineEntity)
    {
        visitDetailsService.saveExternalMedication(medicineEntity);
        request.getSession().setAttribute("externalmedicationentity", medicineEntity);
        request.setAttribute("externalmedication", new ExternalMedicationPojo());
        return "displayexternalmedicationpopup";
    }

    public String saveinternalMedication(HttpServletRequest request, MedicationEntity medicineEntity)
    {
        visitDetailsService.saveInternalMedication(medicineEntity);
        request.getSession().setAttribute("internalmedicationentity", medicineEntity);
        request.setAttribute("externalmedication", new ExternalMedicationPojo());
        return "displayexternalmedicationpopup";
    }

    public String getVisitEditDetails(VisitComplaintsEntity visitComplaints, HttpServletRequest request)
    {
        visitDetailsService.savevisitcomplaints(visitComplaints);
        request.setAttribute("visitcomplaints", new VisitComplaintsEntity());
        return "displayvisistdetailspopup";
    }

    public ModelAndView selectVisitDetailsFilter(CommonSearchPojo pojo, HttpServletRequest request)
    {
        System.out.println((new StringBuilder()).append(pojo.getPeriod()).append(" ").append("search: ").append(pojo.getSearch()).toString());
        java.util.List visitList = visitDetailsService.selectVisitDetailsFilter(pojo);
        request.setAttribute("visitlist", visitList);
        return new ModelAndView("visitDetails", "commonsearchpojo", new CommonSearchPojo());
    }

    private VisitDetailsService visitDetailsService;
    private PatientDetailsService patientService;
}
