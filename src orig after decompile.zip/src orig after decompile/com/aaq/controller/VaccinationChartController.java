// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   VaccinationChartController.java

package com.aaq.controller;

import com.aaqa.pojo.CommonSearchPojo;
import org.springframework.web.servlet.ModelAndView;

public class VaccinationChartController
{

    public VaccinationChartController()
    {
    }

    public ModelAndView displayPatientDetails(CommonSearchPojo pojo)
    {
        return new ModelAndView("vaccinationChartDetails", "commonsearchpojo", new CommonSearchPojo());
    }

    public String displayVaccinationChartPopUp()
    {
        return "displayVaccinationChartPopUp";
    }

    public String displayVaccinationChartsubPopUp()
    {
        return "displayVaccinationChartsubPopUp";
    }
}
