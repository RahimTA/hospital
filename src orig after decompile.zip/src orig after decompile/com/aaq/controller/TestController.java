// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TestController.java

package com.aaq.controller;

import com.aaqa.pojo.*;
import com.aaqa.service.AppointmentService;
import com.aaqa.service.TestDetailsService;
import java.io.PrintStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

public class TestController
{

    public TestController()
    {
        logger = Logger.getLogger(com/aaq/controller/TestController);
    }

    public ModelAndView displayPatientDetails(CommonSearchPojo pojo, HttpServletRequest request)
    {
        java.util.List list = testDetailsService.getPatientName();
        request.getSession().setAttribute("list", list);
        java.util.List testlist = testDetailsService.getTestName();
        request.getSession().setAttribute("testlist", testlist);
        java.util.List periodList = appointmentService.displayPeriodDeatials();
        request.getSession().setAttribute("periodList", periodList);
        java.util.List tlist = testDetailsService.getTestDetails();
        request.getSession().setAttribute("tlist", tlist);
        return new ModelAndView("test", "commonsearchpojo", new CommonSearchPojo());
    }

    public ModelAndView displayTestDetailsPopUp(HttpServletRequest request, Test_TestDetails_Pojo testdetailsPojo)
    {
        return new ModelAndView("displayTestDetailsPopUp", "testdetailsPojo", new Test_TestDetails_Pojo());
    }

    public String selectPatientForTest()
    {
        System.out.println("select patient");
        return "selectPatientForTestDetails";
    }

    public ModelAndView selectPatientForTestToDisplay(HttpServletRequest request, SelectPatientPojo selectPatientPojo)
    {
        System.out.println();
        java.util.List plist = testDetailsService.getPatientDetailForTest();
        System.out.println(plist);
        request.setAttribute("plist", plist);
        return new ModelAndView("selectPatientForTestDetails", "selectPatientPojo", new SelectPatientPojo());
    }

    public ModelAndView getPatientDetailsById(HttpServletRequest request, SelectPatientPojo selectPatientPojo)
    {
        request.getSession().setAttribute("selectPatientPojo", new SelectPatientPojo());
        return new ModelAndView("displayTestDetailsPopUp", "testdetailsPojo", new Test_TestDetails_Pojo());
    }

    public ModelAndView saveTestDetails(Test_TestDetails_Pojo testdetailsPojo, BindingResult result, ModelMap model)
    {
        if(result.hasErrors())
        {
            System.out.println("testcontroller");
            return new ModelAndView("displayTestDetailsPopUp", "testdetailsPojo", testdetailsPojo);
        } else
        {
            testDetailsService.saveTestDetails(testdetailsPojo);
            return new ModelAndView("displayTestDetailsPopUp", "testdetailsPojo", new Test_TestDetails_Pojo());
        }
    }

    public ModelAndView searchPatientTest(CommonSearchPojo commonsearchpojo, HttpServletRequest request)
    {
        java.util.List tlist = testDetailsService.searchPatientTest(commonsearchpojo);
        request.getSession().setAttribute("tlist", tlist);
        System.out.println(tlist);
        return new ModelAndView("test", "commonsearchpojo", commonsearchpojo);
    }

    public ModelAndView getTestDetailsForUpdate(Test_TestDetails_Pojo testDetailspojo, HttpServletRequest request)
    {
        System.out.println("From TestController getTestDetailsForUpdate()..##");
        logger.debug("From TestController getTestDetailsForUpdate()..##");
        String id = request.getParameter("id1");
        logger.debug((new StringBuilder("From TestController getTestDetailsForUpdate()..## the ID is ::")).append(id).toString());
        if(id == null || id.equals(""))
            logger.fatal("this is at SpringException if block");
        Integer id1 = Integer.valueOf(Integer.parseInt(id));
        System.out.println(id1);
        Test_TestDetails_Pojo testDetailsPojo = testDetailsService.getTestDetailsForUpdate(id1);
        return new ModelAndView("displayTestDetailsPopUp", "testdetailsPojo", testDetailsPojo);
    }

    public ModelAndView getTestDetailsForException(HttpServletRequest request)
    {
        String id = request.getParameter("id1");
        if(id == null || id.equals(""))
            logger.fatal("this is at SpringException if block");
        return new ModelAndView("test", "commonsearchpojo", new CommonSearchPojo());
    }

    Logger logger;
    private TestDetailsService testDetailsService;
    private AppointmentService appointmentService;
}
