// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LoginController.java

package com.aaq.controller;

import com.aaqa.dao.LoginDAO;
import com.aaqa.mail.Mailer;
import com.aaqa.pojo.*;
import com.aaqa.service.AppointmentService;
import com.aaqa.service.PaginationService;
import java.io.PrintStream;
import java.util.*;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;

public class LoginController
{

    public LoginController()
    {
        loginDao = null;
        mail = null;
    }

    public void setLoginDao(LoginDAO loginDao)
    {
        this.loginDao = loginDao;
    }

    public void setMail(Mailer mail)
    {
        this.mail = mail;
    }

    public ModelAndView login(LoginPojo pojo, HttpServletRequest request)
    {
        LoginPojo pojo2 = loginDao.login(pojo);
        CommonSearchPojo commonSearchPojo = new CommonSearchPojo();
        List bigApptSearchList = appointmentService.getAppointmentDetails(commonSearchPojo);
        List doctorsList = appointmentService.displayDoctorsList();
        List periodList = appointmentService.displayPeriodDeatials();
        List appmtStatusList = appointmentService.displayAppmtStatusDeatils();
        if(bigApptSearchList.size() != 0)
        {
            request.getSession().setAttribute("bigApptSearchList", bigApptSearchList);
            paginationService.defaultPage(request);
        }
        request.setAttribute("doctorsList", doctorsList);
        request.getSession().setAttribute("periodList", periodList);
        request.setAttribute("appmtStatusList", appmtStatusList);
        return new ModelAndView("homePage", "commonsearchpojo", new CommonSearchPojo());
    }

    public ModelAndView logOut(HttpServletRequest request)
    {
        LoginPojo pojo = (LoginPojo)request.getSession().getAttribute("userPojo");
        String user = pojo.getUser();
        ArrayList actveusers = (ArrayList)((HttpSession)request).getServletContext().getAttribute("activeUsers");
        actveusers.remove(user);
        request.getSession().invalidate();
        return new ModelAndView("login", "pojo", new LoginPojo());
    }

    public String loginDisplay(LoginPojo pojo)
    {
        return "login";
    }

    private void commonLogic(List activeList, LoginPojo pojo, HttpServletRequest request, LoginPojo pojo2)
    {
        activeList.add(pojo.getUser());
        ((HttpSession)request).getServletContext().setAttribute("activeUsers", activeList);
        Random random = new Random();
        int otp = random.nextInt();
        request.getSession().setAttribute("sessionOtp", (new StringBuilder(String.valueOf(otp))).toString());
        System.out.println((new StringBuilder("sessionOtp::")).append(otp).toString());
    }

    public ModelAndView abouthms()
    {
        return new ModelAndView("abouthms");
    }

    public ModelAndView forgotpassword(String result, HttpServletRequest request)
    {
        System.out.println((new StringBuilder("res")).append(result).toString());
        request.setAttribute("reset", result);
        return new ModelAndView("forgotpassword", "forgotpojo", new ForgotPasswordPojo());
    }

    public ModelAndView checkUser(String result, ForgotPasswordPojo forgotpojo, HttpServletRequest request)
    {
        LoginPojo pojo = loginDao.checkUser(forgotpojo);
        if(pojo != null)
        {
            String name = "success";
            String password = pojo.getPassword();
            String To = pojo.getEmailId();
            System.out.println(To);
            request.setAttribute("result", name);
            if(result != null && result.equals("reset"))
            {
                Random random = new Random();
                int otp = random.nextInt();
                mail.send("rahimuddin.java@gmail.com", To, "Password", (new StringBuilder(String.valueOf(otp))).toString());
            } else
            {
                mail.send("rahimuddin.java@gmail.com", To, "Password", password);
            }
            return new ModelAndView("forgotpassword", "forgotpojo", new ForgotPasswordPojo());
        } else
        {
            String name = "fail";
            request.setAttribute("result", name);
            return new ModelAndView("forgotpassword", "forgotpojo", new ForgotPasswordPojo());
        }
    }

    private AppointmentService appointmentService;
    private PaginationService paginationService;
    private LoginDAO loginDao;
    private Mailer mail;
}
