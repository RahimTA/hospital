// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ConsentMasterController.java

package com.aaq.controller;

import com.aaqa.pojo.ConsentFormPopupPojo;
import com.aaqa.pojo.ConsentMasterPopupPojo;
import com.aaqa.service.ConsentService;
import javax.servlet.http.HttpServletRequest;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

public class ConsentMasterController
{

    public ConsentMasterController()
    {
    }

    public ModelAndView displayConsentMasters(ConsentMasterPopupPojo pojo, HttpServletRequest request)
    {
        java.util.List clist = consantService.getConsantMasterDetails(pojo);
        request.setAttribute("clist", clist);
        return new ModelAndView("cmaster", "consentmaster", new ConsentMasterPopupPojo());
    }

    public ModelAndView displayConsentMaster(ConsentMasterPopupPojo pojo, HttpServletRequest request)
    {
        java.util.List clist = consantService.getConsantMasterDetails(pojo);
        request.setAttribute("clist", clist);
        return new ModelAndView("cmaster", "consentmaster", new ConsentMasterPopupPojo());
    }

    public ModelAndView displayConsentForm(ConsentFormPopupPojo pojo, HttpServletRequest request)
    {
        java.util.List lists = consantService.getAllConsent(pojo);
        request.setAttribute("lists", lists);
        return new ModelAndView("cform", "consentform", new ConsentFormPopupPojo());
    }

    public ModelAndView displayConsentMasterPopup(ConsentMasterPopupPojo pojo)
    {
        return new ModelAndView("consentmasterpopup", "cmasterpopup", new ConsentMasterPopupPojo());
    }

    public ModelAndView displaypopupConsentFormPopup(ConsentFormPopupPojo pojo)
    {
        return new ModelAndView("consentformpopup", "cformpopup", new ConsentFormPopupPojo());
    }

    public ModelAndView saveConsentMaster(ConsentMasterPopupPojo cmasterpopup, BindingResult result, HttpServletRequest request)
    {
        if(result.hasErrors())
        {
            return new ModelAndView("consentmasterpopup", "cmasterpopup", cmasterpopup);
        } else
        {
            consantService.saveDetails(cmasterpopup);
            return new ModelAndView("consentmasterpopup", "cmasterpopup", cmasterpopup);
        }
    }

    public ModelAndView saveConsentForm(ConsentFormPopupPojo cformpopup, BindingResult result, HttpServletRequest request)
    {
        if(result.hasErrors())
        {
            return new ModelAndView("consentformpopup", "cformpopup", cformpopup);
        } else
        {
            consantService.saveformDetails(cformpopup);
            return new ModelAndView("consentformpopup", "cformpopup", cformpopup);
        }
    }

    public ModelAndView displayConsentMasterDetails(ConsentMasterPopupPojo consentmaster, HttpServletRequest request)
    {
        java.util.List clist = consantService.getConsantMaster(consentmaster);
        request.setAttribute("clist", clist);
        return new ModelAndView("cmaster", "consentmaster", new ConsentMasterPopupPojo());
    }

    public String consentMastersDetails(HttpServletRequest request)
    {
        java.util.List list = consantService.consentMastersDetails();
        request.setAttribute("list", list);
        return "subpopup";
    }

    public String displayConsentMasters(HttpServletRequest request)
    {
        java.util.List list = consantService.getConsantMasters();
        request.setAttribute("list", list);
        return "subpopup";
    }

    public ModelAndView getAllConsents(HttpServletRequest request, ConsentFormPopupPojo consentform)
    {
        java.util.List lists = consantService.getAllConsents(consentform);
        request.setAttribute("lists", lists);
        return new ModelAndView("cform", "consentform", new ConsentFormPopupPojo());
    }

    public ModelAndView editConsentMasterDetails(ConsentMasterPopupPojo cpojo, HttpServletRequest request)
    {
        Integer id = Integer.valueOf(Integer.parseInt(request.getParameter("consentid")));
        ConsentMasterPopupPojo pojo = consantService.editConsentMasterDetails(id);
        return new ModelAndView("consentmasterpopup", "cmasterpopup", pojo);
    }

    public ModelAndView editConsenDetails(ConsentFormPopupPojo cpojo, HttpServletRequest request)
    {
        Integer id1 = Integer.valueOf(Integer.parseInt(request.getParameter("consentid")));
        ConsentFormPopupPojo pojo = consantService.editConsenDetails(id1);
        return new ModelAndView("consentformpopup", "cformpopup", pojo);
    }

    private ConsentService consantService;
}
