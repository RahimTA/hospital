// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   OperativeNotesController.java

package com.aaq.controller;

import com.aaqa.pojo.*;
import com.aaqa.service.OperativeNotesService;
import javax.servlet.http.HttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

public class OperativeNotesController
{

    public OperativeNotesController()
    {
    }

    public ModelAndView displayPatientDetails(CommonSearchPojo pojo)
    {
        return new ModelAndView("operativenotes", "commonsearchpojo", new CommonSearchPojo());
    }

    public ModelAndView displayOperativeNotesPopup(OperativeNotesPojo operativeNotesPojo)
    {
        return new ModelAndView("operativeNotesPopup", "operativeNotesPojo", new OperativeNotesPojo());
    }

    public ModelAndView displayOperativeNotesPopup1(OperativeNotesPojo operativeNotesPojo)
    {
        return new ModelAndView("operativeNotesPopup1", "operativeNotesPojo", operativeNotesPojo);
    }

    public ModelAndView displayOperativeNotesPopup2(OperativeNotesPojo operativeNotesPojo)
    {
        return new ModelAndView("operativeNotesPopup2", "operativeNotesPojo", new OperativeNotesPojo());
    }

    public ModelAndView saveOperativeNotesgeDetailsPopoup(OperativeNotesPojo operativeNotesPojo, HttpServletRequest request)
    {
        request.setAttribute("dischargeDetailsPopupPojo", new DischargeDetailsPopupPojo());
        request.setAttribute("externalmedication", new ExternalMedicationPojo());
        operativeNotesService.saveOperativeNotesDetails(operativeNotesPojo);
        return new ModelAndView("operativeNotesPopup", "operativeNotesPojo", new OperativeNotesPojo());
    }

    private OperativeNotesService operativeNotesService;
}
